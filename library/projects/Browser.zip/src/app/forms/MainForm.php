<?php
namespace app\forms;

use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;

class MainForm extends AbstractForm
{

    /**
     * @event show 
     **/
    function doShow(UXWindowEvent $event)
    {    
        //При первом запуске откроем одну вкладку
        $this->openTab();        
    }

    /**
     * @event tabs.close 
     **/
    function doTabsClose(UXEvent $event)
    {    
        //Всегда будет открыта по крайней мере одна вкладка
        if($this->tabs->tabs->count == 0){
            $this->openTab();
        }
    }

    /**
     * @event tabs.change 
     **/
    function doTabsChange(UXEvent $event)
    {    
        //При смене вкладок меняем url и статус загрузки
        $browser = $this->getActiveBrowser();
        $this->browserUrl->text = $browser->location;
        $this->loadState->visible = $browser->state!='SUCCEEDED';
    }

    /**
     * @event forw.click 
     **/
    function doForwClick(UXMouseEvent $event)
    {    
        if($this->getActiveBrowser()->history->currentIndex == sizeof($this->getActiveBrowser()->history->getEntries())-1) return;
        $this->getActiveBrowser()->history->goForward();
    }

    /**
     * @event back.click 
     **/
    function doBackClick(UXMouseEvent $event)
    {    
        if($this->getActiveBrowser()->history->currentIndex == 0) return;
        $this->getActiveBrowser()->history->goBack();
    }

    /**
     * @event reload.click 
     **/
    function doReloadClick(UXMouseEvent $event)
    {    
        $this->getActiveBrowser()->reload();
    }

    /**
     * @event browserUrl.keyDown-Enter 
     **/
    function doBrowserUrlKeyDownEnter(UXKeyEvent $event)
    {    
        $this->getActiveBrowser()->load($this->checkUrl($this->browserUrl->text));
    }

    /**
     * @event newtab.click 
     **/
    function doNewtabClick(UXMouseEvent $event)
    {    
        $this->openTab();
        $this->tabs->selectLastTab();
    }




    /**
     * Возвращает элемент браузера из активной вкладки
     **/
    public function getActiveBrowser(){
        $tab = $this->getActiveTab();
        return $tab->content->engine;
    }

    public function getActiveTab(){
        return $this->tabs->tabs[$this->tabs->selectedIndex];
        //$this->tabs->selectedTab почему-то возвращает null
    }
    
    /**
     * Создание новой вкладки браузера
     **/     
    public function openTab($url = 'http://google.com'){
        $url = $this->checkUrl($url);
        $id = $this->getUnique();
        
        $tab = new UXTab();
        $tab->id = ('tab_' . $id);
        $tab->text = $url;

        $browser = new UXWebView;
        $browser->id = ('browser_' . $id);
        //$browser->engine->id = ('engine_' . $id);

        $browser->engine->watchState(function($self, $old, $new) use ($browser, $tab){
            
            if($this->isActive($browser->id)){
                $this->browserUrl->text = $self->location;
                $this->loadState->visible = $new!='SUCCEEDED';
            }

            $tab->text = (is_null($self->title)?substr($self->location,0,15):$self->title);
        });        

        
        $browser->engine->load($url);
        $tab->content = $browser; //*/
        
        $this->tabs->tabs[] = $tab;
    }

    /**
     * Проверяет, является ли переданный id браузера в активной вкладке
     **/
    public function isActive($elid){
        return $elid  ==  $this->getActiveTab()->content->id;
    }
    
    public function getUnique($pref = ''){
        return $pref . Time::Seconds() . rand(0,1000);
    }

    public function checkUrl($url){
        if(stripos($url,'http://')===false and stripos($url,'https://')===false){
            return 'http://'.$url;
        }
        return $url;
    }
}
