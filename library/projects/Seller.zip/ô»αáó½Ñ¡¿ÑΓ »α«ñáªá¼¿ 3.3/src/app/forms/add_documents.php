<?php
namespace app\forms;

use gui;
use httpclient;
use php\lib\str;
use php\gui\event\UXEvent;
use php\time\Time;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class add_documents extends AbstractForm
{

    /**
     * @event dialog_select_clients.action
     * Открываем окно выбора покупателя
     */
    function doDialog_select_clientsAction(UXEvent $e = null)
    {
        $select_dialog_clients = app()->getNewForm('select_clients');
        $select_dialog_clients->id = null;
        $select_dialog_clients->showAndWait();
        
        // Записываем выбранного покупателя в переменные и текстовое поле
        if (!empty($select_dialog_clients->id)) {
            $this->id_client = $select_dialog_clients->id;
            
            // Обновляем текстовые поля
            $this->name_client->text = $select_dialog_clients->company;
            $this->people->text = $select_dialog_clients->people;
            $this->people_position->text = $select_dialog_clients->people_position;
            $this->phone->text = $select_dialog_clients->phone;
            $this->city->text = $select_dialog_clients->city;
            $this->address->text = $select_dialog_clients->address;
        }
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event add_new_document.action 
     * Добавляем новый документ реализации в таблицу Documents
     */
    function doAdd_new_documentAction(UXEvent $e = null)
    {
        if (!empty($this->id_client)){
        
            // Подготавливаем данные
            $this->date_create = Time::now();
            $this->date_create = $this->date_create->toString('yyyy-MM-dd HH:mm:ss');
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'add_document',
                'id_user' => $this->get_this_user('user_id'),
                'id_client' => $this->id_client,
                'date_create' => $this->date_create, 
                'date_delivery' => $this->date_create
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();
                    app()->getMainForm()->toast("Данные успешно сохранены");
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
            
        } else {
            $this->toast("Не выбран покупатель");
        }
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * При открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->maxWidth = 360; 
        $this->maxHeight = 296;
        $this->minWidth = 360;
        $this->minHeight = 296;
    }

}
