<?php
namespace app\forms;

use gui;
use php\gui\event\UXEvent;
use php\gui\framework\AbstractForm;
use php\gui\event\UXKeyEvent; 
use php\gui\event\UXMouseEvent; 


class enter_count extends AbstractForm
{

    /**
     * @event enter_count.keyDown-Enter 
     * Сохраняем введенное значение в переменную окна
     */
    function doEnter_countKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doButtonAction();
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event edit.keyDown-Enter 
     * Сохраняем введенное значение в переменную окна
     */
    function doEditKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doButtonAction();
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action 
     * Сохраняем введенное значение в переменную окна
     */
    function doButtonAction(UXEvent $e = null)
    {    
        (int) $this->count = $this->enter_count->text;
        (int) $this->discount = $this->edit->text;        
        $this->hide();
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * При открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->maxWidth = 272; 
        $this->maxHeight = 105;
        $this->minWidth = 272;
        $this->minHeight = 105;
        
        // Устанавливаем скидку покупателя
        $this->enter_count->text = $this->count;
        $this->edit->text = $this->discount;
    }


}
