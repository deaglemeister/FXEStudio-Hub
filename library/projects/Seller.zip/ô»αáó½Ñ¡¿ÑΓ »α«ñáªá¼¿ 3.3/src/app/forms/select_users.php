<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXMouseEvent; 


class select_users extends AbstractForm
{

    /**
     * @event show 
     * При открытии окна - устанавливаем параметры
     */
    function doShow(UXWindowEvent $e = null)
    {    
        // Устанавливаем минимальные размеры окна
        $this->minWidth = 656; 
        $this->minHeight = 280;
        
        // ЗАгружаем список покупателей
        $this->loading_users($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_users.click-2x 
     * Выбираем пользователя и сохраняем в переменные
     */
    function doTable_usersClick2x(UXMouseEvent $e = null)
    {    
        if (!empty($this->table_users->selectedItem['id'])) {
            $this->id = $this->table_users->selectedItem['id'];
            $this->name = $this->table_users->selectedItem['name'];
            $this->hide();
        }
    }

}
