<?php
namespace app\forms;

use php\gui\UXAlert;
use std;
use app\forms\enter_count;
use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use php\gui\UXImage;
use Exception;
use php\lib\str;
use php\io\Stream;
use php\util\Locale;
use php\time\TimeFormat;
use php\gui\UXDialog;
use php\time\Time;
use php\lib\arr;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXKeyEvent;

class open_documents extends AbstractForm
{

    /**
     * @event show 
     * При открытии окна загружаем выбранный документ
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
        // Устанавливаем минимальные размеры окна
        $this->showPreloader();
        $this->hide_preloader = ['count' => 0];
        $this->minWidth = 704; 
        $this->minHeight = 460;
        
        // Если пользователь администратор - показываем
        // Кнопку распровести документ
        if ($this->get_this_user('user_permission') == 0) {
            $this->unset_document->visible = true;
        }
        
        // Если пользователь менеджер - скрываем
        // Кнопку проведения документа
        if ($this->get_this_user('user_permission') > 1) {
            $this->save_document->visible = false;
        }
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'open_document',
            'id' => $this->id_document
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                
                // Записываем номер документа  
                $document = $res['sql'];                 
                $this->code_document->text = 'И5Д - '.$document[0]['id'];
                $this->date_document = $document[0]['date_create'];
                
                // Выставляем дату в комбо
                $this->date_create->value=$this->format_date_combo($document[0]['date_create']);
                $this->date_edited->value=$this->format_date_combo($document[0]['date_edited']);
                $this->date_delivery->value=$this->format_date_combo($document[0]['date_delivery']);
                
                // Устанавливаем оставшиеся значения
                $this->uuid_document = $document[0]['uuid'];
                $this->id_client = $document[0]['id_client'];
                $this->company_client = $document[0]['company'];
                $this->company_mail = $document[0]['email'];
                $this->name_client->text = $document[0]['company'];
                $this->comment->text = $document[0]['comment'];
                $this->people->text = $document[0]['people'];
                $this->people_position->text = $document[0]['people_position'];
                $this->phone->text = $document[0]['phone'];
                $this->adressDelivery = $document[0]['city'] . " - " . $document[0]['address'];
                
                // Устанавливаем скидку покупателя для окна подбора товара
                $this->client_discount = $document[0]['discount'];
                
                // Проверяем доставку документа
                if ($document[0]['delivery'] == 1) {
                    $this->save_delivery->enabled = false;
                } else {
                    $this->save_delivery->enabled=true;
                }
                
                // Проверяем проведение документа
                $this->document_uploaded = $document[0]['uploaded'];
                if ($document[0]['uploaded'] == 1) {
                    $this->button->enabled = false;
                    $this->save_document->enabled = false;
                    $this->dialog_adds_product_to->enabled = false;
                    $this->dialog_select_clients->enabled = false;
                    $this->date_delivery->enabled = false;
                } else {
                    $this->save_delivery->enabled = false;
                }
                
                // Получаем данные о продукции в документе
                $this->loading_products_documents($this, $this->id_document);
                $this->text_paids_document->text = number_format($this->summ_paid_document) . " руб.";
                
                // Если документ полностью загрузился, убираем preloader
                $this->hide_preloader['count'] += 1;
                if ($this->hide_preloader['count'] == 2) {
                    $this->hidePreloader();
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dialog_select_clients.action 
     * Открываем окно выбора покупателя
     */
    function doDialog_select_clientsAction(UXEvent $e = null)
    {
        $select_dialog_clients = app()->getNewForm('select_clients');
        $select_dialog_clients->id = null;
        $select_dialog_clients->company = null;
        $select_dialog_clients->showAndWait();
        
        // Записываем выбранного покупателя в переменные и текстовое поле
        if (!empty($select_dialog_clients->id)) {
            $this->id_client = $select_dialog_clients->id;
            $this->company_client = $select_dialog_clients->company;
            
            // Обновляем текстовые поля
            $this->name_client->text = $this->company_client;
            $this->people->text = $select_dialog_clients->people;
            $this->people_position->text = $select_dialog_clients->people_position;
            $this->phone->text = $select_dialog_clients->phone;
        }
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event save_document.action 
     * Сохраняем и проводим документ реализации и помечаем заказ как проведенный
     */
    function doSave_documentAction(UXEvent $e = null)
    {    
        
        // Собираем массив uuid продукции и количество для снятия с остатков
        $debit_bal = arr::toArray($this->table_products_document->items);
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'approve_document',
            'id' => $this->id_document,
            'debit' => $debit_bal
        ], function(HttpResponse $response) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $this->hide();
                app()->getForm('Window')->toast("Данные успешно сохранены.");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
            
        });
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event unset_document.action 
     * Распроводим открытый документ реализации.
     * При удалении документа из таблицы Documents 
     * Будет удалена вся продукция содержащаяся в нём
     * Тоесть будут удалены позиции из таблицы Sales -
     * Это связяно с тем, что каждая запись Sales связана ключём foreign-key
     * По ID документа.
     */
    function doUnset_documentAction(UXEvent $e = null)
    {    
        if (!empty($this->id_document)) {
        
            
            // Выводим диалог подтверждения
            $dialog = new UXAlert('CONFIRMATION');
            $dialog->title = 'Подтвердите действие.';
            $dialog->headerText = 'Вы действительно хотите распровести документ ?';
            $dialog->setButtonTypes(['Да', 'Нет']);
            
            // Проверяем, что выбрал пользователь
            if ($dialog->showAndWait() == 'Да') {
            
                // Выполняем отправку данных на сервер
                $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                    'key' => $this->ini->get('key'),
                    'action' => 'delete_document',
                    'id' => $this->id_document
                ], function(HttpResponse $response) {
                    
                    // Выводим сообщения о статусе запроса
                    $res = $response->body();
                    
                    // Если успешное обновление данных
                    if ($res['status'] == 'success') {
                        $this->hide();
                        app()->getForm('Window')->toast("Данные успешно сохранены.");
                    } else {
                        // В противном случае выводим ошибку ответ от сервера
                        if ($res['status'] === NULL) {
                            $this->toast("Интернет отсутствует или сервер не отвечает...");
                        } else {
                            $this->toast($res['status']);
                        }
                    }
                
                });
            
            }
            
            
        }
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dialog_adds_product_to.action 
     * Открываем окно подбора продукции
     */
    function doDialog_adds_product_toAction(UXEvent $e = null)
    {
        $select_dialog_products = app()->getNewForm('add_products_document');
        $select_dialog_products->id_document = $this->id_document;
        $select_dialog_products->date_document = $this->date_document;
        $select_dialog_products->client_discount = $this->client_discount;
        $select_dialog_products->showAndWait();
        $this->loading_products_documents($this, $this->uuid_document);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event print_document.action 
     * Создаем товарную накладную и открываем окно просмотра печати
     */
    function doPrint_documentAction(UXEvent $e = null)
    {
            
            // Создаем папку для документов при ее отсутствии
            $dir = new File(fs::abs('./documents'));
            $dir->mkdirs();
            
            // Создаем поток для записи в файл
            $file = fs::abs('./documents/'.$this->code_document->text.'.html');
            unlink($file); // Удаляем файл с таким именем
            $stream = new FileStream($file, 'a+');
            
            // Создаем параметр QR Кода
            $qrCode = $this->ini->get('server') . "/status.php?uuid=" . $this->uuid_document; 
            var_dump($qrCode);
            
            // Создаем файл именем номера накладной
            $stream->write("
                <!DOCTYPE HTML>
                <html>
                <head>
                <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
                <title>Товарная накладная: ".$this->code_document->text."</title>
                
                <style>
                    html {
                        padding: 0px;
                        font: 12px/16px arial, sans-serif;
                    }
                    
                    body {
                        padding: 0px;
                        font-size: 12px;
                        color: #000;
                    }
                    
                    .margin-bottom-row {
                        margin-bottom: 10px! Important;
                    }
                    .margin-bottom-header {
                        margin-bottom: 15px! Important;
                    }
                    
                    .text-center {
                        text-align: center;
                    }
                    .text-left {
                        text-align: left;
                    }
                    .text-right {
                        text-align: right;
                    }
                    .text-small {
                        font-size: 90%;
                    }
                    .strong {
                        font-weight: 700;
                    }
                    .normal {
                        font-weight: normal;
                    }
                    
                    
                    /*--------------------------------------------------------------*/
                    table {
                        width: 100%;
                        display: table;
                        border-radius: 2px;
                        padding: 1px;
                    }
                    table th {
                        font-weight: 600;
                        text-align: inherit;
                        padding: 6px 11px;
                        word-break: normal;
                        white-space: nowrap;
                    }
                    table tr {
                        display: table-row;
                        cursor: default;
                    }
                    table tr:nth-child(2n+1) {
                        background: none;
                    } 
                    table tr td {
                        padding: 0px 0px;
                        display: table-cell;
                        vertical-align: middle;
                        word-break: normal;
                        white-space: nowrap;
                    }
                    table tr td.full-width {
                        width: 100%;
                    }
                    
                    table.list {
                        border-collapse: collapse;
                    }
                    
                    table.list tr td {
                        padding: 1px 10px;
                        border: 1px solid #000;
                        display: table-cell;
                        vertical-align: middle;
                        word-break: normal;
                        white-space: nowrap;
                    }
                    /*--------------------------------------------------------------*/
                    
                    
                    
                    .summ_num:first-letter {
                        text-transform: uppercase;
                    }
                    
                    .mp-print {
                        float: right;
                    }
                    
                    .qr_code {
                        position: relative;
                        vertical-align: middle;
                        float: right;
                        margin-right: -9px;
                        width: 90px;
                        height: 90px;
                    }
                </style>
                
                </head>
                <body>
                
                
                    <table class='margin-bottom-header'>
                        <tr>
                            <td> 
                                <span class='strong'>Продавец:</span> ".$this->ini->get('company')."</br>
                                <span class='strong'>Грузополучатель:</span> ".$this->name_client->text."</br>
                                <span class='strong'>Адрес доставки:</span> ".$this->adressDelivery."</br>
                                <span class='strong'>Контактное лицо:</span> ".$this->people->text."</br>
                                <span class='strong'>Должность:</span> ".$this->people_position->text."</br>
                                <span class='strong'>Контактный телефон:</span> ".$this->phone->text."</br>
                            </td>
                            <td>");
                            
                            // Проверяем включена ли опция отображения QR-Кода
                            if ($this->ini->get('qrCode')) {
                               $stream->write("<img class='qr_code' src='https://api.develnext.org/data/v1/qr-code/generate?text=".$qrCode."&size=90' />");
                            }
                            
            $stream->write("</td>
                        </tr>
                    </table>
                    
                    
                    <table class='margin-bottom-header'>
                        <tr>
                            <td class='text-right'>
                                <span style='margin-right: 10px;' class='strong'>Товарная накладная</span>
                            </td>
                            <td>
                                <table class='list' style='width: 100px;'>
                                    <tr>
                                        <td>Номер документа</td>
                                        <td>Дата составления</td>
                                    </tr>
                                    <tr>
                                        <td class='strong'>".$this->code_document->text."</td>
                                        <td>".$this->date_create->value."</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    
                    
                        <table class='list margin-bottom-header'>
                        <tr>
                            <td>№</td>
                            <td>Артикул</td>
                            <td class='full-width'>Наименование</td>
                            <td>Количество</td>
                            <td>Цена</td>
                            <td>Сумма</td>
                        </tr>
            
        "); 
        
        // Записываем построчно каждую позицию в таблицу
        $i = 0;
        foreach ($this->table_products_document->items as $item) {
            $i++;
            $stream->write("<tr>");
            $stream->write("<td>".$i."</td>"); 
            $stream->write("<td>".$item['code']."</td>"); 
            $stream->write("<td>".$item['name']."</td>");
            $stream->write("<td>".$item['count']."</td>");
            $stream->write("<td>".$item['price']."</td>");
            $stream->write("<td>".$item['product_summ']."</td>");
            $stream->write("</tr>");
        }
        
        // Закрываем поток записи в файл
        $stream->write("
                    </table>            
                    
                    <table class='margin-bottom-header'>
                        <tr>
                            <td class='text-left'>
                                <span class='strong'>Сумма документа прописью: </span> <div class='summ_num'>".$this->num2str($this->document_summ)."</div>
                            </td>
                            <td class='text-right'>
                                <span class='strong'>Сумма документа: </span></br> ".number_format($this->document_summ)." руб.
                            </td>
                        </tr>
                    </table>
                    
                    <table>
                        <tr>
                            <td class='text-left'>
                                <span class='strong'>Исполнитель</span> ____________________</br>
                                М.П.
                            </td>
                            <td class='text-right'>
                                <div class='mp-print text-left'>
                                    <span class='strong'>Заказчик</span> ____________________</br>
                                    М.П.
                                </div>
                            </td>
                        </tr>
                    </table>
                    
                    
                </body>
            </html>
            "); 
            
            $stream->close();
        
            // Открываем окно предпросмотра печати документа
            $window_print = app()->getNewForm('window_print');
            $window_print->file = $file;
            $window_print->showAndWait();
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event save_delivery.action 
     * Помечаем документ как доставленный
     */
    function doSave_deliveryAction(UXEvent $e = null)
    {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'update_delivery_documents',
            'id' => $this->id_document,
            'delivery' => 1
        ], function(HttpResponse $response) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $this->save_delivery->enabled = false;
                $this->toast("Данные успешно сохранены.");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
            
        });
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event save_pay.action 
     * Добавляем платеж по документу
     */
    function doSave_payAction(UXEvent $e = null)
    {
        
        // Открываем окно ввода и устанавливаем ему переменные
        $add_pay_document = app()->getNewForm('add_pay_document');
        $add_pay_document->code_document = $this->code_document->text;
        $add_pay_document->full_summ_closed = ($this->document_summ - $this->summ_paid_document);
        $add_pay_document->pay_summ = null;
        $add_pay_document->pay_comment = null;
        $add_pay_document->showAndWait();
        
        $this->pay_summ = $add_pay_document->pay_summ;
        $this->pay_comment = $add_pay_document->pay_comment;
        $this->var_date_paid = Time::now();
        $this->var_date_paid = $this->var_date_paid->toString('yyyy-MM-dd HH:mm:ss');
        
        // Проверяем введенные данные на соответствие
        try {
        
            // Проверяем введеную сумму 
            if (empty($this->pay_summ)) {
                throw new Exception('Не заполнена сумма платежа.');
            }
            
            // Проверяем сумму до полной оплаты и введенную сумму
            // Дабы не было переплаты по документу
            if ($add_pay_document->pay_summ <= ($this->document_summ - $this->summ_paid_document)) {} else {
                throw new Exception('Введенная сумма больше, чем сумма, до полной оплаты документа.');
            }
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'add_pay',
                'id_document' => $this->id_document,
                'id_user' => $this->get_this_user('user_id'),
                'summ' => $this->pay_summ,
                'comment' => $this->pay_comment
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                
                    // Проверяем сумму (платежа + платежей) с суммой документа - 
                    // Если они полностью совпадают то
                    // Документ отмечаем как оплаченный
                    if (($this->pay_summ + $this->summ_paid_document) === $this->document_summ) {
                        $this->save_pay->enabled = false;
                        $this->dialog_adds_product_to->enabled = false;
                        $this->panel_pay_doc->classes->add("lighting-acc");
                    } else {
                        // Bключаем кнопку
                        $this->save_pay->enabled = true;
                    }
                    
                    // Обновляем сумму оплаты в окне
                    $this->summ_paid_document = ($this->pay_summ + $this->summ_paid_document);
                    $this->text_paids_document->text = number_format($this->summ_paid_document) . " руб.";
                    $this->toast("Платёж по документу сохранен.");
                    
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
            
        } catch(Exception $e) {
            $this->toast($e->getMessage()); 
        }
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------


    /**
     * @event button.action 
     * Сохраняем и закрываем документ реализации и помечаем заказ как не проведенный
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $comment = $this->comment->text;
        
        // Устанавливаем нужный формат даты доставки для SQLite
        $timeFormat = new TimeFormat('dd.MM.yyyy');
        $time = $timeFormat->parse($this->date_delivery->value);
        $date_delivery = $time->toString('yyyy-MM-dd 00:00:00', Locale::RUSSIAN());
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'update_document',
            'id' => $this->id_document,
            'id_client' => $this->id_client,
            'comment' => $comment,
            'date_delivery' => $date_delivery
        ], function(HttpResponse $response) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $this->hide();
                app()->getForm('Window')->toast("Данные успешно сохранены.");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
            
        });
    }








    /**
     * @event table_products_document.keyDown-Delete 
     */
    function doTable_products_documentKeyDownDelete(UXKeyEvent $e = null)
    {
        
        if (!empty($this->table_products_document->selectedItem['id']) and $this->document_uploaded == 0) {
            
            // Выполняем запрос на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'delete_products_documents',
                'id' => $this->table_products_document->selectedItem['id']
            ], function(HttpResponse $response) {
                
                // Сверяем полученные данные
                $res = $response->body();
                if ($res['status'] == 'success') {
                    $this->loading_products_documents($this, $this->id_document);
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
            
        }
    }

    /**
     * @event table_products_document.keyDown-Enter 
     */
    function doTable_products_documentKeyDownEnter(UXKeyEvent $e = null)
    {
        if (!empty($this->table_products_document->selectedItem['id']) and $this->document_uploaded == 0) {
            $enter_count = app()->getNewForm('enter_count');
            (int) $enter_count->count = $this->table_products_document->selectedItem['count'];
            (int) $enter_count->discount = $this->table_products_document->selectedItem['discount'];
            $enter_count->showAndWait();
            
            // Проверяем введеное значение
            if ($enter_count->count !== 0 and $enter_count->discount >= 0) {
            
                // Выполняем запрос на сервер
                $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                    'key' => $this->ini->get('key'),
                    'action' => 'update_products_documents',
                    'id' => $this->table_products_document->selectedItem['id'],
                    'count' => $enter_count->count,
                    'discount' => $enter_count->discount
                ], function(HttpResponse $response) use ($form) {
                    
                    // Сверяем полученные данные
                    $res = $response->body();
                    if ($res['status'] == 'success') {
                        $this->loading_products_documents($this);
                    } else {
                        // В противном случае выводим ошибку ответ от сервера
                        if ($res['status'] === NULL) {
                            $this->toast("Интернет отсутствует или сервер не отвечает...");
                        } else {
                            $this->toast($res['status']);
                        }
                    }
                    
                });
                
            }
            
        }
    }

    /**
     * @event table_products_document.click-2x 
     */
    function doTable_products_documentClick2x(UXMouseEvent $e = null)
    {
        $this->doTable_products_documentKeyDownEnter();
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------



}
