<?php
namespace app\forms;

use php\gui\event\UXEvent;
use php\time\Time;
use Exception;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXKeyEvent; 


class add_pay_document extends AbstractForm
{

    /**
     * @event show 
     * При открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {    
    
        $this->maxWidth = 456; 
        $this->maxHeight = 262;
        $this->minWidth = 456;
        $this->minHeight = 262; 
        
        $this->text_num_document->text = $this->code_document;
        $this->text_full_summ_closed->text = number_format($this->full_summ_closed) . " руб.";
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action 
     * При нажатии кнопки внести платёж
     */
    function doButtonAction(UXEvent $e = null)
    {   
    
        $this->pay_summ = $this->input_pay_summ->text;
        $this->pay_comment = $this->input_pay_comment->text;
        $this->hide();
            
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event input_pay_summ.keyUp 
     */
    function doInput_pay_summKeyUp(UXKeyEvent $e = null)
    {    
        $this->label3->text = number_format(intval($this->input_pay_summ->text)) . ' руб.';
    }
    

}
