<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXWindowEvent; 


class select_type_report extends AbstractForm
{


    /**
     * @event show 
     * При открытии окна задаем варианты типов отчета
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->combobox->items->add("Продукция");
        $this->combobox->items->add("Покупатели");
        $this->combobox->items->add("Пользователи");
        $this->combobox->selectedIndex = 0;
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action 
     * Сохраняем и закрываем окно выбора типа отчета
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->type_report = $this->combobox->selectedIndex;
        $this->type_name = $this->combobox->value;
        $this->hide();
    }

    

}
