<?php
namespace app\forms;

use php\gui\UXImage;
use php\gui\UXImageView;
use php\gui\UXMenuItem;
use php\gui\UXContextMenu;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXWindowEvent; 


class select_tree_item extends AbstractForm
{

    /**
     * @event tree.click-2x 
     * Выбираем категорию и закрываем окно
     */
    function doTreeClick2x(UXMouseEvent $e = null)
    {
        
        // получаем первый выделенный элемент
        if ($this->tree->selectedItems[0]) {
            if ($this->tree->selectedItems[0]->value->id) {
                $this->select_cat_id = $this->tree->selectedItems[0]->value->id;
                $this->hide();
            }
            
        }
                
    }

    /**
     * @event show 
     * При открытии формы
     */
    function doShow(UXWindowEvent $e = null)
    {    
        // Загружаем категории в дерево
        // выделяем категорию товара
        $this->loading_category_items($this, $this->select_cat_id);
    }
    

}
