<?php
namespace app\forms;

use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use php\gui\UXAlert;
use Exception;
use php\gui\framework\event\ClickEventAdapter;
use std, gui, framework, app;
use php\gui\event\UXMouseEvent; 
use php\time\Time;
use php\gui\event\UXWindowEvent;
use php\lib\arr;


class open_vendors extends AbstractForm {


    /**
     * @event save_vendor.action 
     * Сохраняем изменения в карточке поставщика
     */
    function doSave_vendorAction(UXEvent $event = null)
    {
        
        // Проверяем данные на соответствие
        try {
         
            // Устанавливаем значения
            $this->var_company = $this->company->text;
            $this->var_city = $this->city->text;
            $this->var_address = $this->address->text;
            $this->var_people = $this->people->text;
            $this->var_people_position = $this->people_position->text;
            $this->var_phone = $this->phone->text;
            $this->var_email = $this->email->text;
            $this->var_inn = $this->inn->text;
            $this->var_ogrn = $this->ogrn->text;
            $this->var_bank_name = $this->bank_name->text;
            $this->var_bank_account = $this->bank_account->text;
            $this->var_comment = $this->textArea->text;
           
            // Проверка на название
            if (empty($this->var_company)) {
                throw new Exception('Нет названия поставщика.');
            }
            
            // Проверка на город
            if (empty($this->var_city)) {
                throw new Exception('Не введен город.');
            }
            
            // Проверка на адресс
            if (empty($this->var_address)) {
                throw new Exception('Не введен адрес.');
            }
            
            // Проверка на контактное лицо
            if (empty($this->var_people)) {
                throw new Exception('Введите контактное лицо.');
            }
            
            // Проверка на должность лица
            if (empty($this->var_people_position)) {
                throw new Exception('Введите должность лица.');
            }
            
            // Проверка на контактный телефон
            if (empty($this->var_phone)) {
                throw new Exception('Номер телефона обязателен.');
            }
            
            // Проверка на контактный телефон
            if (!is_numeric($this->var_phone)) {
                throw new Exception('Номером телефона, должны быть только числа.');
            }
            
            // Проверка на контактный телефон
            if (empty($this->var_email)) {
                throw new Exception('Электронный адрес обязателен.');
            }
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'update_vendor',
                'id' => $this->id_vendor,
                'company' => $this->var_company,
                'city' => $this->var_city, 
                'address' => $this->var_address,
                'people' => $this->var_people, 
                'people_position' => $this->var_people_position,
                'phone' => $this->var_phone,
                'email' => $this->var_email,
                'inn' => $this->var_inn,
                'ogrn' => $this->var_ogrn, 
                'bank_name' => $this->var_bank_name,
                'bank_account' => $this->var_bank_account,
                'comment' => $this->var_comment
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();
                    app()->getForm('Window')->toast("Данные успешно сохранены.");
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });         
        
        } catch(Exception $e) {
            $this->toast($e->getMessage());
        }
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * Загрузка информации о поставщике при открытии окна
     */
    function doShow(UXWindowEvent $event = null) {
    
        $this->maxWidth = 768; 
        $this->maxHeight = 327;
        $this->minWidth = 768;
        $this->minHeight = 327;
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'open_vendor',
            'id' => $this->id_vendor,
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                
                $vendor = $res['sql'];
                $this->company->text = $vendor[0]['company'];
                $this->city->text = $vendor[0]['city'];
                $this->address->text = $vendor[0]['address'];
                $this->people->text = $vendor[0]['people'];
                $this->people_position->text = $vendor[0]['people_position'];
                $this->phone->text = $vendor[0]['phone'];
                $this->email->text = $vendor[0]['email'];
                $this->inn->text = $vendor[0]['inn'];
                $this->ogrn->text = $vendor[0]['ogrn'];
                $this->bank_name->text = $vendor[0]['bank_name'];
                $this->bank_account->text = $vendor[0]['bank_account'];
                $this->textArea->text = $vendor[0]['comment'];
                
                // Проверяем поставщика на блокировку
                if ($vendor[0]['block']) {
                    $this->tmp_block = 0;
                    $this->block_vendors->graphic = new UXImageView(new UXImage('res://.data/img/tick-button.png'));
                } else {
                    $this->tmp_block = 1;
                    $this->block_vendors->graphic = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event block_vendors.action 
     * Блокируем поставщика, при нажатии
     * Поставщик не удаляется полностью - это нарушит связь в таблице
     * Он помечается как block = 1
     */
    function doBlock_vendorsAction(UXEvent $e = null)
    {    
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'block_vendor',
            'id' => $this->id_vendor,
            'block' => $this->tmp_block
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                $this->hide();
                app()->getForm('Window')->toast("Данные успешно сохранены.");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
        
    }
    

}
