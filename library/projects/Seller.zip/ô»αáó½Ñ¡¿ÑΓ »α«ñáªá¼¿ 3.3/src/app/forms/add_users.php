<?php
namespace app\forms;

use gui;
use httpclient;
use std;
use php\gui\event\UXEvent;
use Exception;
use php\time\Time;
use php\gui\event\UXMouseEvent;
use php\gui\framework\AbstractForm;

class add_users extends AbstractForm
{

    /**
     * @event add_user.action 
     * Добавляем пользователя в таблицу Users
     */
    function doAdd_userAction(UXEvent $e = null)
    {    
           
        // Проверяем данные на соответствие
        try {
        
            $this->first_name->classes->remove("lighting-obj-err");
            $this->last_name->classes->remove("lighting-obj-err");
            $this->mail->classes->remove("lighting-obj-err");
            $this->edit->classes->remove("lighting-obj-err");
            $this->password->classes->remove("lighting-obj-err");
            $this->retry_password->classes->remove("lighting-obj-err");
         
            // Устанавливаем значения
            $first_name = $this->first_name->text;
            $last_name = $this->last_name->text;
            $mail = strtolower($this->mail->text);
            $phone = $this->edit->text;
            $password = $this->password->text;
            $retry_password = $this->retry_password->text;
            $permission = ($this->permission->selectedIndex);
            $salt = null;
           
            // Проверка на имя
            if (empty($first_name)) {
                $this->first_name->classes->add("lighting-obj-err");
                throw new Exception('Введите имя.');
            }
            
            // Проверка на фамилию
            if (empty($last_name)) {
                $this->last_name->classes->add("lighting-obj-err");
                throw new Exception('Введите фамилию.');
            }
            
            // Проверка на почту
            if (empty($mail)) {
                $this->mail->classes->add("lighting-obj-err");
                throw new Exception('Введите e-mail адрес.');
            }
            
            // Проверка на телефон
            if (empty($phone)) {
                $this->edit->classes->add("lighting-obj-err");
                throw new Exception('Введите телефон.');
            }
            
            // Проверка на пароль пользователя
            if (!empty($password)) {
            
                // Проверка на повторный пароль пользователя
                if (empty($retry_password)) {
                    $this->retry_password->classes->add("lighting-obj-err");
                    throw new Exception('Введите пароль повторно');
                } else {
                    if ($password != $retry_password) {
                        $this->password->classes->add("lighting-obj-err");
                        $this->retry_password->classes->add("lighting-obj-err");
                        throw new Exception('Пароли не совпадают');
                    }
                    
                    // Устанавливаем данные
                    $salt = microtime();
                    $password = str::hash($password . $salt, 'SHA-256');
                    
                }
                
            }
            
            // Проверка на уровень доступа
            if ($permission != -1) {} else {
                throw new Exception('Не выбран уровень доступа.');
            }
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'add_user',
                'first_name' => $first_name,
                'last_name' => $last_name,
                'mail' => $mail,
                'phone' => $phone, 
                'salt' => $salt,
                'password' => $password,
                'permission' => $permission
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();                    
                    app()->getForm('Settings')->toast('Пользователь зарегистрирован!');
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
            
        } catch(Exception $e) {
            $this->toast($e->getMessage());
        }
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * При открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->maxWidth = 303; 
        $this->maxHeight = 359;
        $this->minWidth = 303;
        $this->minHeight = 359;
    }





}
