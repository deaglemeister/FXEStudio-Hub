<?php
namespace app\forms;

use app\modules\ItemValue;
use php\gui\UXTreeItem;
use php\gui\UXImage;
use php\gui\UXImageView;
use framework;
use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use Exception;
use php\lib\arr;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;
use php\gui\event\UXWindowEvent; 


class open_products extends AbstractForm 
{


    /**
     * @event show 
     * Загружаем данные выбранной продукции
     */
    function doShow(UXWindowEvent $e = null)
    {
    
        $this->maxWidth = 664; 
        $this->maxHeight = 376;
        $this->minWidth = 664;
        $this->minHeight = 376;
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'open_product',
            'id' => $this->id_product,
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                
                $product = $res['sql'];
                $this->id_vendor = $product[0]['id_vendor'];
                $this->name->text = $product[0]['name'];
                $this->code->text = $product[0]['id'];
                $this->vendor_code->text = $product[0]['vendor_code'];
                $this->name_vendor->text = $product[0]['company'];
                $this->price->text = $product[0]['price'];
                $this->count->text = $product[0]['count'];
                $this->percent->text = $product[0]['percent'];
                $this->in_the_package->text = $product[0]['in_the_package'];
                $this->info->text = $product[0]['info'];
                $this->doPercentKeyUp();
                $this->category = $product[0]['category'];
                
                // Загружаем категории в дерево
                // выделяем категорию товара
                $this->loading_category_items($this, $this->category);
                
                // Проверяем продукцию на архив
                if ($product[0]['archive']) {
                    $this->tmp_archive = 0;
                    $this->archive_product->graphic = new UXImageView(new UXImage('res://.data/img/tick-button.png'));
                } else {
                    $this->tmp_archive = 1;
                    $this->archive_product->graphic = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
                                                     
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dialog_select_vendors.action
     * Открываем диалог выбора поставщика
     */
    function doDialog_select_vendorsAction(UXEvent $e = null)
    {
        $select_dialog_vendors = app()->getNewForm('select_vendors');
        $select_dialog_vendors->id = null;
        $select_dialog_vendors->company = null;
        $select_dialog_vendors->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле
        if (!empty($select_dialog_vendors->id)) {
            $this->id_vendor = $select_dialog_vendors->id;
            $this->company_vendor = $select_dialog_vendors->company;
            $this->name_vendor->text = $this->company_vendor;
        } else {
            $this->id_vendor = "";
            $this->name_vendor->text = "";
        }
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event save_product.action 
     * Сохраняем изменения продукции
     */
    function doSave_productAction(UXEvent $e = null)
    {
        
        // Проверяем данные на соответствие
        try {
            
            // Устанавливаем значения
            $this->var_name = $this->name->text;
            $this->var_vendor_code = $this->vendor_code->text;
            $this->var_price = $this->price->text;
            $this->var_count = $this->count->text;
            $this->var_percent = $this->percent->text;
            $this->var_in_the_package = $this->in_the_package->text;
            $this->var_info = $this->info->text;
           
            // Проверка на название
            if (empty($this->var_name)) {
                throw new Exception('Нет названия продукции.');
            }
            
            // Проверка на код поставщика
            if (empty($this->var_vendor_code)) {
                throw new Exception('Не введен код поставщика.');
            }
            
            // Проверка на выбранного поставщика
            if (empty($this->id_vendor)) {
                throw new Exception('Поставщик не выбран.');
            }
            
            // Проверка на цену
            if (empty($this->var_price)) {
                throw new Exception('Введите цену.');
            }
                    
            // Проверка на цену
            if (!is_numeric($this->var_price)) {
                throw new Exception('Цена должна быть числом.');
            }
            
            // Проверка на количество
            if (!is_numeric($this->var_count)) {
                throw new Exception('Цена должна быть числом.');
            }
        
            // Проверка на наценку
            if (!is_numeric($this->var_percent)) {
                throw new Exception('Наценка должна быть числом.');
            }
            
            // Проверка на количество в упаковке
            if (empty($this->var_in_the_package)) {
                throw new Exception('Введите количество в упаковке.');
            }
        
            // Проверка на количество в упаковке
            if (!is_numeric($this->var_in_the_package)) {
                throw new Exception('Количество в упаковке должно быть числом.');
            }
            
            // Проверка на выбранную категорию
            if (empty($this->category)) {
                throw new Exception('Выберите категорию товара.');
            }
            
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'update_product',
                'id' => $this->id_product,
                'id_vendor' => $this->id_vendor,
                'name' => $this->var_name,
                'vendor_code' => $this->var_vendor_code, 
                'price' => $this->var_price,
                'count' => $this->var_count,
                'percent' => $this->var_percent, 
                'in_the_package' => $this->var_in_the_package,
                'category' => $this->category,
                'info' => $this->var_info
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();
                    app()->getForm('Window')->toast("Данные успешно сохранены.");
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
        
        } catch(Exception $e) {
            $this->toast($e->getMessage()); 
        }
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event archive_product.action 
     * Отправить продукцию в архив
     * Продукция не удаляется полностью - это нарушит связь в таблице
     * Она помечается как archive = 1
     */
    function doArchive_productAction(UXEvent $e = null)
    {
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'archive_product',
            'id' => $this->id_product,
            'archive' => $this->tmp_archive
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                $this->hide();
                app()->getForm('Window')->toast("Данные успешно сохранены.");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event percent.keyUp 
     * Подсчитываем базовую цену продукта
     */
    function doPercentKeyUp(UXKeyEvent $e = null)
    {    
        $this->label9->text = number_format(intval(($this->price->text * (100 + $this->percent->text) / 100))) . " руб.";
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event price.keyUp 
     * Подсчитываем базовую цену продукта
     */
    function doPriceKeyUp(UXKeyEvent $e = null)
    {    
        $this->doPercentKeyUp();
    }

    /**
     * @event count.keyUp 
     */
    function doCountKeyUp(UXKeyEvent $e = null)
    {
        $this->doPercentKeyUp();
    }

    /**
     * @event tree.click-Left 
     */
    function doTreeClickLeft(UXMouseEvent $e = null)
    {    
        // получаем первый выделенный элемент
        if ($this->tree->selectedItems[0]) {
            if ($this->tree->selectedItems[0]->value->id) {
                $this->category = $this->tree->selectedItems[0]->value->id;
            }
            
        }
    }

    

}
