<?php
namespace app\forms;

use std;
use bundle\http\HttpResponse;
use php\lib\arr;
use php\gui\event\UXEvent;
use php\lib\fs;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXMouseEvent; 


class Settings extends AbstractForm
{

    /**
     * @event show 
     * Загружаем список пользователей при открытии окна и 
     * Устанавливаем настройки
     */
    function doShow(UXWindowEvent $e = null)
    {    
    
        $this->maxWidth = 624; 
        $this->maxHeight = 335;
        $this->minWidth = 624;
        $this->minHeight = 335;
        
        // Если в файле настроек присутствуют записи сервера и ключа
        $server = $this->ini->get('server');
        $key = $this->ini->get('key');
        if (empty($server) or empty($key)) {
                       
            $this->SettingTab->tabs[0]->disable = true;
            $this->SettingTab->selectedIndex = 1;
            $this->buttonAlt->visible = false;
             
        } else {
        
            // Если пользователь администратор, то делаем доступной таб 
            // Управления пользователями.
            // Если пользователь администратор, то делаем доступной кнопку
            // Генерации нового ключа сервера. Внимание - при изменении ключа сервера 
            // Во всех клиентах (копий программы) необходимо его изменить.
            $userPermission = $this->get_this_user('user_permission');
            if ($userPermission === "0") {
                $this->SettingTab->tabs[0]->disable = false;
                $this->SettingTab->selectedIndex = 0;
                $this->buttonAlt->visible = true;  
                $this->loading_users($this);
            } else {
                $this->SettingTab->tabs[0]->disable = true;
                $this->SettingTab->selectedIndex = 1;
                $this->buttonAlt->visible = false; 
            }
        
        }
        
        // Устанавливаем значения
        $this->server_url_path->text = $this->ini->get('server');
        $this->edit->text = $this->ini->get('key'); 
        $this->editAlt->text = $this->ini->get('company');
        $this->checkbox->selected = $this->ini->get('qrCode');
        
    }

    
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------   
    

    /**
     * @event button.action 
     * Открываем окно нового пользователя
     */
    function doButtonAction(UXEvent $e = null)
    {    
        app()->showFormAndWait('add_users');
        $this->loading_users($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event save_server_url_path.action 
     * Сохраняем данные в файл настроек
     */
    function doSave_server_url_pathAction(UXEvent $e = null)
    {
        $this->ini->set('server', $this->server_url_path->text);
        $this->ini->set('key', $this->edit->text);
        $this->ini->set('company', $this->editAlt->text);
        $this->ini->set('qrCode', $this->checkbox->selected);
        $this->toast('Данные успешно сохранены!');
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_users.click-2x 
     * открываем выбранного пользователя
     */
    function doTable_usersClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_users->selectedItem['id'])) {
            $open_users = app()->getNewForm('open_users');
            $open_users->id_user = $this->table_users->selectedItem['id'];
            $open_users->showAndWait();
            $this->indexTblusers = $this->table_users->selectedIndex;
            $this->loading_users($this);
        }
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event buttonAlt.action 
     * Создаем новый ключ сервера
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $this->edit->text = str::uuid();
        $this->toast("Скопируйте новый ключ сервера!");
    }



}
