<?php
namespace app\forms;

use php\gui\event\UXWindowEvent;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class select_clients extends AbstractForm
{

    /**
     * @event show 
     * Загружаем покупателей при открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {        
        // Устанавливаем минимальные размеры окна
        $this->minWidth = 656; 
        $this->minHeight = 280;
        
        // ЗАгружаем список покупателей
        $this->loading_clients($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_clients.click-2x 
     * Выбираем покупателя при двойном клике на таблице
     */
    function doTable_clientsClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_clients->selectedItem['id'])) {
            $this->id = $this->table_clients->selectedItem['id'];
            $this->company = $this->table_clients->selectedItem['company'];
            $this->people = $this->table_clients->selectedItem['people'];
            $this->people_position = $this->table_clients->selectedItem['people_position'];
            $this->phone = $this->table_clients->selectedItem['phone'];
            $this->city = $this->table_clients->selectedItem['city'];
            $this->address = $this->table_clients->selectedItem['address'];
            $this->hide();
        }
    }
    
    

}
