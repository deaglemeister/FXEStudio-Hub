<?php
namespace app\forms;

use php\io\FileStream;
use php\lib\fs;
use php\io\File;
use bundle\http\HttpResponse;
use php\time\Time;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXWindowEvent;
use php\gui\event\UXMouseEvent; 


class ordering_provider extends AbstractForm
{


    // Устанавливаем массив параметров для фильтрации документов
    var $filter_documents = [
        'client_id' => "",
        'start_date' => "", 
        'end_date' => ""
    ];

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dialog_select_vendors.action 
     * Открываем окно выбора поставщика
     */
    function doDialog_select_vendorsAction(UXEvent $e = null)
    {
        
        $select_dialog_vendors = app()->getNewForm('select_vendors');
        $select_dialog_vendors->id = null;
        $select_dialog_vendors->company = null;
        $select_dialog_vendors->email = null;
        $select_dialog_vendors->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле.
        if (!empty($select_dialog_vendors->id)) {
            $this->id_vendor = $select_dialog_vendors->id;
            $this->email_vendor = $select_dialog_vendors->email;
            $this->company_vendor = $select_dialog_vendors->company;
            $this->name_vendor->text = $this->company_vendor;
        } else {
            $this->name_vendor->text = "";
            $this->id_vendor = "";
        }
            
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * При открытии окна делаем настройки
     */
    function doShow(UXWindowEvent $e = null)
    {    
    
        // Устанавливаем дату в поля сортировки заказов
        $this_date = Time::now();
        $this->dateEdit->value = $this_date->toString('01.MM.yyyy');
        $this->dateEditAlt->value = $this_date->toString('dd.MM.yyyy');
        
        $this->loading_documents($this);
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button3.action 
     * Загружаем документы за выбранный период
     */
    function doButton3Action(UXEvent $e = null)
    {    
        $this->loading_documents($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dateEdit.action 
     */
    function doDateEditAction(UXEvent $e = null)
    {    
        $this->filter_documents['start_date'] = $this->dateEdit->value;
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dateEditAlt.action 
     */
    function doDateEditAltAction(UXEvent $e = null)
    {    
        $this->filter_documents['end_date'] = $this->dateEditAlt->value;
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action 
     * Формируем заказ выбранному поставщику
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
        // Проверяем выбран ли поставщик
        if (empty($this->id_vendor)) {
            $this->toast("Выберите поставщика.");
        } else {
            
            
            // Show preloader
            $this->showPreloader();
            
            // Выполняем запрос на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'ordering_provider',
                'start_date' => $this->filter_documents['start_date'],
                'end_date' => $this->filter_documents['end_date'],
                'vendor_id' => $this->id_vendor
            ], function(HttpResponse $response) use ($form) {
                
                // Сверяем полученные данные
                $res = $response->body();
                if ($res['status'] == 'success') {
                
                
                    // Создаем папку для документов при ее отсутствии
                    $dir = new File(fs::abs('./documents'));
                    $dir->mkdirs();
                    
                    // Создаем поток для записи в файл
                    $file = fs::abs('./documents/ordering.html');
                    unlink($file); // Удаляем файл с таким именем
                    $stream = new FileStream($file, 'a+'); 
                    
                    // Создаем файл именем номера накладной
                    $stream->write("
                        <!DOCTYPE HTML>
                        <html>
                        <head>
                        <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
                        <title>Заказ поставщику</title>
                    
                        <style>
                            html {
                                padding: 0px;
                                font: 12px/16px arial, sans-serif;
                            }
                            
                            body {
                                padding: 00px;
                                font-size: 12px;
                                color: #000;
                            }
                            
                            .margin-bottom-row {
                                margin-bottom: 10px! Important;
                            }
                            .margin-bottom-header {
                                margin-bottom: 15px! Important;
                            }
                            
                            .text-center {
                                text-align: center;
                            }
                            .text-left {
                                text-align: left;
                            }
                            .text-right {
                                text-align: right;
                            }
                            .text-small {
                                font-size: 90%;
                            }
                            .strong {
                                font-weight: 700;
                            }
                            .normal {
                                font-weight: normal;
                            }
                            
                            
                            /*--------------------------------------------------------------*/
                            table {
                                width: 100%;
                                display: table;
                                border-radius: 2px;
                                padding: 1px;
                            }
                            table th {
                                font-weight: 600;
                                text-align: inherit;
                                padding: 6px 11px;
                                word-break: normal;
                                white-space: nowrap;
                            }
                            table tr {
                                display: table-row;
                                cursor: default;
                            }
                            table tr:nth-child(2n+1) {
                                background: none;
                            } 
                            table tr td {
                                padding: 0px 0px;
                                display: table-cell;
                                vertical-align: middle;
                                word-break: normal;
                                white-space: nowrap;
                            }
                            table tr td.full-width {
                                width: 100%;
                            }
                            
                            table.list {
                                border-collapse: collapse;
                            }
                            
                            table.list tr td {
                                padding: 1px 10px;
                                border: 1px solid #000;
                                display: table-cell;
                                vertical-align: middle;
                                word-break: normal;
                                white-space: nowrap;
                            }
                            /*--------------------------------------------------------------*/
                            
                            
                            
                            .summ_num:first-letter {
                                text-transform: uppercase;
                            }
                            
                            .mp-print {
                                float: right;
                            }
                            
                            .qr_code {
                                position: relative;
                                vertical-align: middle;
                                float: right;
                                margin-right: -9px;
                                width: 90px;
                                height: 90px;
                            }
                        </style>
                        
                        </head>
                        <body>
                        
                        
                            <div class='margin-bottom-header'>
                                <p><span class='strong'>Заказчик:</span> ".$this->ini->get('company')."</br>
                                    <span class='strong'>Поставщик:</span> ".$this->name_vendor->text."
                                </p>
                            </div>
                            
                            <table class='list margin-bottom-header'>
                                <tr>
                                    <td>№</td>
                                    <td>Артикул</td>
                                    <td class='full-width'>Наименование</td>
                                    <td>Количество</td>
                                    <td>Цена</td>
                                    <td>Сумма</td>
                                </tr>
                        
                    "); 
                    
                    // Очищаем таблицу и выводим данные
                    $i = 1;
                    $summ_document = 0;
                    foreach ($res['sql'] as $row) {
                        $product = $row;
                        
                        // Подготавливаем данные к выводу
                        $product['summ'] = ($product['price'] * $product['all_count']) . " руб.";
                        
                        $stream->write("<tr>");
                        $stream->write("<td>".$i."</td>"); 
                        $stream->write("<td>".$product['vendor_code']."</td>"); 
                        $stream->write("<td>".$product['name']."</td>");
                        $stream->write("<td>".number_format($product['all_count'])."</td>");
                        $stream->write("<td>".number_format($product['price'])."</td>");
                        $stream->write("<td>".number_format($product['summ'])."</td>");
                        $stream->write("</tr>");
                        $i++;
                        $summ_document = ($summ_document + $product['summ']);                    
                    }
                    
                    // Закрываем поток записи в файл
                    $stream->write("
                                </table>              
                            
                            <table class='margin-bottom-header'>
                                <tr>
                                    <td class='text-left'>
                                        <span class='strong'>Сумма документа прописью: </span> <div class='summ_num'>".$this->num2str($summ_document)."</div>
                                    </td>
                                    <td class='text-right'>
                                        <span class='strong'>Сумма документа: </span></br> ".number_format($summ_document)." руб.
                                    </td>
                                </tr>
                            </table>
                            
                            <table>
                                <tr>
                                    <td class='text-left'>
                                        <span class='strong'>Исполнитель</span> ____________________</br>
                                        М.П.
                                    </td>
                                    <td class='text-right'>
                                        <div class='mp-print text-left'>
                                            <span class='strong'>Заказчик</span> ____________________</br>
                                            М.П.
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            
                            
                        </body>
                    </html>
                    "); 
                    
                    $stream->close();
                
                    // Открываем окно предпросмотра печати документа
                    $window_print = app()->getNewForm('window_print');
                    $window_print->file = $file;
                    $window_print->showAndWait();
                    
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
                // Hide preloader
                $this->hidePreloader();
            
            });
            
            
        }
              
        
    }
    

}
