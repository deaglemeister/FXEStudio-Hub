<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXWindowEvent; 


class select_vendors extends AbstractForm
{



    /**
     * @event show 
     * Загружаем поставщиков при открытии окна
     */
    function doShow(UXWindowEvent $e = null)
    {        
        // Устанавливаем минимальные размеры окна
        $this->minWidth = 656; 
        $this->minHeight = 280;
        
        // Загружаем список поставщиков
        $this->loading_vendors($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_vendors.click-2x 
     * Выбираем поставщика при двойном клике на таблице
     */
    function doTable_vendorsClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_vendors->selectedItem['id'])) {
            $this->id = $this->table_vendors->selectedItem['id'];
            $this->company = $this->table_vendors->selectedItem['company'];
            $this->email = $this->table_vendors->selectedItem['email'];
            $this->hide();
        }
    }



}
