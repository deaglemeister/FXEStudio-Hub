<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\event\UXEvent; 


class window_print extends AbstractForm
{

    /**
     * @event show 
     * При открытии окна - загружаем переданный параметром файл
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->browser->engine->load("file:///".$this->file);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action 
     * Отправляем документ на печать
     */
    function doButtonAction(UXEvent $e = null)
    {    
        //execute('cmd /c rundll32.exe C:\WINDOWS\SYSTEM32\MSHTML.DLL,PrintHTML "file:///'.$this->file.'"');
        $this->printer->print($this->browser);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event buttonAlt.action 
     * Открываем документ в браузере по умолчанию
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        open($this->file);
    }


}
