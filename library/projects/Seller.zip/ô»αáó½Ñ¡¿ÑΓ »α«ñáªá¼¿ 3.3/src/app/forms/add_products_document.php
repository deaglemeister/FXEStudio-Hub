<?php
namespace app\forms;

use php\gui\UXImage;
use php\gui\UXImageView;
use php\gui\UXMenuItem;
use php\gui\UXContextMenu;
use std;
use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use php\lib\arr;
use php\gui\UXDialog;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXKeyEvent; 


class add_products_document extends AbstractForm
{

    // Устанавливаем массив параметров для фильтрации продукции
    $filter_products = [
        'vendor_id' => "",
        'search' => ""
    ];

    /**
     * @event show 
     * Загружаем продукцию при открытии окна.
     */
    function doShow(UXWindowEvent $e = null)
    {
        // Устанавливаем минимальные размеры окна
        $this->minWidth = 656; 
        $this->minHeight = 296;
        
        // Загружаем список продукции
        $this->loading_category_items($this, null);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event dialog_select_vendors.action 
     * Открываем диалог выбора поставщика.
     */
    function doDialog_select_vendorsAction(UXEvent $e = null)
    {
    
        $select_dialog_vendors = app()->getNewForm('select_vendors');
        $select_dialog_vendors->id = null;
        $select_dialog_vendors->company = null;
        $select_dialog_vendors->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле.
        if (!empty($select_dialog_vendors->id)) {
            $this->id_vendor = $select_dialog_vendors->id;
            $this->company_vendor = $select_dialog_vendors->company;
            $this->name_vendor->text = $this->company_vendor;
            $this->filter_products['vendor_id'] = $this->id_vendor;
        } else {
            $this->filter_products['vendor_id'] = "";
            $this->name_vendor->text = "";
        }
            
        // Загружаем продукцию в таблицу в соответствии выбранного поставщика.
        $this->loading_products($this);
            
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_products.keyDown-Enter 
     * Добавляем продукцию при нажатии ENTER и помечаем заказ как не выгруженный
     */
    function doTable_productsKeyDownEnter(UXEvent $e = null)
    {    
        if (!empty($this->table_products->selectedItem['id'])) {
            $enter_count = app()->getNewForm('enter_count');
            (int) $enter_count->count = null;
            (int) $enter_count->discount = $this->client_discount;
            $enter_count->showAndWait();
            
            // Проверяем введеное значение
            if ($enter_count->count !== 0 and $enter_count->discount >= 0) {
                
                // Получаем базовую цену продукта
                $id_product = $this->table_products->selectedItem['id'];
                $price_base_int = $this->table_products->selectedItem['price_base_int'];
                
                // Выполняем отправку данных на сервер
                $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                    'key' => $this->ini->get('key'),
                    'action' => 'add_products_document',
                    'id_user' => $this->get_this_user('user_id'),
                    'id_document' => $this->id_document,
                    'id_product' => $id_product, 
                    'price' => $price_base_int,
                    'count' => $enter_count->count,
                    'discount' => $enter_count->discount
                ], function(HttpResponse $response) {
                    
                    // Выводим сообщения о статусе запроса
                    $res = $response->body();
                    
                    // Если успешное обновление данных
                    if ($res['status'] == 'success') {
                        $this->toast("Данные сохранены.");
                    } else {
                        // В противном случае выводим ошибку ответ от сервера
                        if ($res['status'] === NULL) {
                            $this->toast("Интернет отсутствует или сервер не отвечает...");
                        } else {
                            $this->toast($res['status']);
                        }
                    }
                    
                });
                
            }
            
        }
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event table_products.click-2x 
     * Добавление продукции в документ реализации при двойном клике (вызываем функцию по ENTER).
     */
    function doTable_productsClick2x(UXMouseEvent $e = null)
    {    
        $this->doTable_productsKeyDownEnter();
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    


    /**
     * @event search_product.action 
     * Поиск продукции
     */
    function doSearch_productAction(UXEvent $e = null)
    {
        $this->filter_products['search'] = $this->text_search_product->text;
        $this->loading_products($this);
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event text_search_product.keyDown-Enter 
     * Поиск продукции при нажатии ЕНТЕР
     */
    function doText_search_productKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doSearch_productAction();
    }

    /**
     * @event tree.click 
     */
    function doTreeClick(UXMouseEvent $e = null)
    {
        // получаем первый выделенный элемент
        if ($this->tree->selectedItems[0]) {
            if ($this->tree->selectedItems[0]->value->id) {
                $this->filter_products['category'] = $this->tree->selectedItems[0]->value->id;
            }
        }
        
        // Проверяем нажатия кнопок мыши
        if ($e->button == "PRIMARY") {
            // Загружаем продукцию
            $this->loading_products($this);
        }         
    }



}
