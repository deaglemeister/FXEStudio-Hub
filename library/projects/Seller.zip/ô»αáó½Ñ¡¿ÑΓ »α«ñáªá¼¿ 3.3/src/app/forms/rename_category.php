<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class rename_category extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        if ($this->edit->text != "") {
            $this->name = $this->edit->text;
            $this->hide();
        } else {
            $this->toast("Введите название");
        }
    }

}
