<?php
namespace app\forms;

use app\modules\Blowfish;
use php\io\IOException;
use gui;
use httpclient;
use std;
use php\gui\event\UXEvent;
use php\lib\fs;
use bundle\http\HttpResponse;
use php\lang\System;
use Exception;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\event\UXMouseEvent;


class Login extends AbstractForm
{
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // При открытии окна авторизации
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event show 
     * При открытии окна авторизации проверяем 
     * INI файл настроек, если его нет, создаем
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
        $this->maxWidth = 272;
        $this->maxHeight = 239;
        $this->minWidth = 272;
        $this->minHeight = 239;
        
        // Получаем логин последнего пользователя
        $this->email->text = $this->ini->get('login');
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Получаем введенные данные пользователем
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event login.action 
     * Получаем введенные данные пользователем
     */
    function doLoginAction(UXEvent $e = null)
    {
        
        try {
        
            // Проверяем на наличие ini файла настроек,
            // Если он отсутствует - открываем окно настроек приложения
            // С ограничениями
            $server = $this->ini->get('server');
            $key = $this->ini->get('key');
            if (empty($server) or empty($key)) {
                throw new Exception('Установите настройки программы');
            }
            
            $this->email->classes->remove("lighting-obj-err");
            $this->password->classes->remove("lighting-obj-err");
            
            // Получаем введенные данные
            $mail = strtolower($this->email->text);
            $pass = $this->password->text;

            //Проверяем логин            
            if (empty($mail)) {
                $this->email->classes->add("lighting-obj-err");
                throw new Exception('Введите логин');
            }
            
            // Проверяем пароль
            if (empty($pass)) {
                $this->password->classes->add("lighting-obj-err");
                throw new Exception('Введите пароль');
            }       
                    
            // Выполняем запрос на сервер
            $request = $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'login',
                'mail' => $mail,
                'password' => $pass
            ], function(HttpResponse $response) {
            
                // Сверяем полученные данные
                $res = $response->body();
                if ($res['status'] == 'success') {
                
                    // Записываем данные пользователя в массив
                    app()->module('DataBase')->_session_user['user_id'] = $res['user_id'];
                    app()->module('DataBase')->_session_user['user_mail'] = $res['user_mail'];
                    app()->module('DataBase')->_session_user['user_permission'] = $res['user_permission'];
                    app()->module('DataBase')->_session_user['first_name'] = $res['first_name'];
                    app()->module('DataBase')->_session_user['last_name'] = $res['last_name'];
                    
                    // Записываем в файл настроек логин пользователя
                    $this->ini->set('login', $res['user_mail']);
                    
                    // Открываем главное окно программы
                    $this->hide();
                    app()->showFormAndWait('Window');
                    
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
            
            });
            
        } catch(Exception $e) {
            $this->toast($e->getMessage());
        }
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // При нажатии ЕНТЕР в поле пароля
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    
        
     /**
     * @event password.keyDown-Enter 
     * При нажатии ЕНТЕР в поле пароля
     */
    function doPasswordKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doLoginAction();
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // При закрытии формы
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event close 
     * При закрытии формы проверяем на завершение авторизации
     * Если не завершена то закрываем приложение
     */
    function doClose(UXWindowEvent $e = null)
    {    
        if ($this->success != true) {
            app()->shutdown(); 
            System::halt(0);
        }
    }


    /**
     * @event button.action 
     * Открыть настройки при клике в окне логина и пароля
     */
    function doButtonAction(UXEvent $e = null)
    {    
        app()->showFormAndWait('Settings');
    }

    

}
