<?php
namespace app\forms;

use bundle\http\HttpResponse;
use gui;
use std;
use php\gui\UXAlert;
use php\lib\fs;
use app\modules\DataBase;
use php\lang\System;
use php\gui\UXFileChooser;
use php\time\Time;
use php\lib\arr;
use php\lib\items;
use php\gui\UXDialog;
use php\gui\UXTab;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXEvent;
use php\gui\event\UXWindowEvent;
use php\gui\event\UXKeyEvent; 


class Window extends AbstractForm {
        
    /**
     * @event show
     * Проверяем уровень доступа пользователя, 
     * Подгрузка таблиц происходит по выбору Таба в панели
     */
    function doShow(UXWindowEvent $event = null)
    {
    
        // Приветствие
        $this->labelAlt->text = $this->get_this_user('first_name') . " " . $this->get_this_user('last_name');
        
        // Устанавливаем значения для программы
        $this->minWidth = 1064; 
        $this->minHeight = 518;
        $this_date = Time::now();
        
        // Проверяем настройки программы
        if ($this->ini->get('start_fullscreen') == 1) {
            $this->iconified = false;
            $this->maximize();
        }
        
        // Устанавливаем дату в поля Документы
        $this->start_date_documents->value=$this_date->toString('01.MM.yyyy');
        $this->end_date_documents->value=$this_date->toString('dd.MM.yyyy');
        
        // Устанавливаем дату в поля Денежные средства
        $this->start_date_paid->value=$this_date->toString('01.MM.yyyy');
        $this->end_date_paid->value=$this_date->toString('dd.MM.yyyy');
        
        // Устанавливаем дату в поля Отчеты
        $this->dateEdit->value=$this_date->toString('01.MM.yyyy');
        $this->dateEditAlt->value=$this_date->toString('dd.MM.yyyy');
        
        // Если пользователь администратор
        if ($this->get_this_user('user_permission') == 0) {
            $this->loading_vendors($this);
        }
        
        // Если пользователь оператор
        if ($this->get_this_user('user_permission') == 1) {
            $this->WindowTab->tabs[0]->disable = true;
            $this->WindowTab->tabs[1]->disable = true;
            $this->WindowTab->tabs[4]->disable = true;
            $this->WindowTab->tabs[5]->disable = true;
            $this->WindowTab->selectedIndex = 3;
        }
        
        // Если пользователь менеджер
        if ($this->get_this_user('user_permission') == 2) {
            $this->WindowTab->tabs[0]->disable = true;
            $this->WindowTab->tabs[1]->disable = true;
            $this->WindowTab->tabs[2]->disable = true;
            $this->WindowTab->tabs[4]->disable = true;
            $this->WindowTab->tabs[5]->disable = true;
            $this->WindowTab->selectedIndex = 3;
        }
        
    }

    /**
     * @event WindowTab.change
     * Переход по табам и загрузка соответствующих функций
     */
    function doWindowTabChange(UXEvent $event = null)
    {    
        
        $id_tab = $this->WindowTab->selectedIndex;
        $name_tab = $this->WindowTab->tabs[$id_tab]->text; // Не используется
        
        // Если выбраны поставщики
        if ($id_tab == 0) {
            $this->loading_vendors($this);
        }
        
        // Если выбраны товары / услуги
        if ($id_tab == 1) {
            $this->loading_category_items($this, null);
        }
        
        // Если выбраны покупатели
        if ($id_tab == 2) {
            $this->loading_clients($this);
        }
        
        // Если выбраны документы
        if ($id_tab == 3) {
            $this->loading_documents($this);
        }
        
        // Если выбраны денежные средства
        if ($id_tab == 4) {
            $this->loading_paids($this);
        }
        
        // Если выбраны отчеты
        if ($id_tab == 5) {
            $this->loading_statistics($this);
        }
        
    }
    
    
    // Устанавливаем массив параметров для фильтрации поставщиков
    var $filter_vendors = [
            'block' => "",
            'search' => ""
        ];
                          
    /**
     * @event search_vendor.action 
     * Поиск по поставщикам
     */
    function doSearch_vendorAction(UXEvent $event = null)
    {    
        $this->filter_vendors['search'] = $this->text_search_vendor->text;
        $this->loading_vendors($this);
    }
    
    /**
     * @event text_search_vendor.keyDown-Enter 
     * При нажатии ЕНТЕР в поле для поиска
     */
    function doText_search_vendorKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doSearch_vendorAction();
    }

    /**
     * @event table_vendors.click-2x 
     * Открытие окна поставщика для редактирования
     */
    function doTable_vendorsClick2x(UXMouseEvent $event = null)
    {   
        if (!empty($this->table_vendors->selectedItem['id'])) {
            $open_vendors = app()->getNewForm('open_vendors');
            $open_vendors->id_vendor = $this->table_vendors->selectedItem['id'];
            $open_vendors->showAndWait();
            $this->indexTblvendors = $this->table_vendors->selectedIndex;
            $this->loading_vendors($this);
        }
    }
    
    /**
     * @event new_vendor_dialog.action 
     * Открытие окна новая карточка поставщика
     */
    function doNew_vendor_dialogAction(UXEvent $event = null)
    {    
        app()->showFormAndWait('add_vendors');
        $this->loading_vendors($this);
    }

    /**
     * @event toggle_block_vendors.click-Left 
     * Загружаем заблокированных поставщиков
     */
    function doToggle_block_vendorsClickLeft(UXMouseEvent $e = null)
    {    
        $this->filter_vendors['block'] = $this->toggle_block_vendors->selected;
        $this->loading_vendors($this);
    }
    
    
    // Устанавливаем массив параметров для фильтрации покупателей
    var $filter_clients = [
            'block' => "",
            'search' => ""
        ];
                          

    // Устанавливаем массив параметров для фильтрации продукции
    var $filter_products = [
            'category' => "",
            'vendor_id' => "",
            'archive' => "",
            'search' => ""
        ];
   
    /**
     * @event search_product.action 
     * Поиск по продукции
     */
    function doSearch_productAction(UXEvent $event = null)
    {    
        $this->filter_products['search'] = $this->text_search_product->text;
        $this->loading_products($this);
    }
    
    /**
     * @event text_search_product.keyDown-Enter 
     * При нажатии ЕНТЕР в поле поиска продукции
     */
    function doText_search_productKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->doSearch_productAction();
    }
    
    /**
     * @event dialog_select_vendors.action 
     * Фильтруем поставщика в продукции
     */
    function doDialog_select_vendorsAction(UXEvent $e = null)
    {
        $select_dialog_vendors = app()->getNewForm('select_vendors');
        $select_dialog_vendors->id = null;
        $select_dialog_vendors->company = null;
        $select_dialog_vendors->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле
        if (!empty($select_dialog_vendors->id)) {
            $this->filter_products['vendor_id'] = $select_dialog_vendors->id;
            $this->name_vendor->text = $select_dialog_vendors->company;
            $this->name_vendor->classes->add("lighting-obj-acc");
            $this->loading_products($this);
        } else {
            $this->filter_products['vendor_id'] = "";
            $this->name_vendor->text = "";
            $this->name_vendor->classes->remove("lighting-obj-acc");
            $this->loading_products($this);
        }
    }

    /**
     * @event table_products.click-2x 
     * Открытие окна редактирорвание продукции
     */
    function doTable_productsClick2x(UXMouseEvent $e = null)
    {    
        if (!empty($this->table_products->selectedItem['id'])) {
            $open_products = app()->getNewForm('open_products');
            $open_products->id_product = $this->table_products->selectedItem['id'];
            $open_products->showAndWait();
            $this->indexTblproducts = $this->table_products->selectedIndex;
            $this->loading_products($this);
        }
    }

    /**
     * @event new_product_dialog.action 
     * Открытие окна новая карточка продукции
     */
    function doNew_product_dialogAction(UXEvent $event = null)
    {    
        app()->showFormAndWait('add_products');
        $this->loading_products($this);
    }

    /**
     * @event toggle_archive_products.click-Left 
     * Загружаем архивные позиции
     */
    function doToggle_archive_productsClickLeft(UXMouseEvent $e = null)
    {    
        $this->filter_products['archive'] = $this->toggle_archive_products->selected;
        $this->loading_products($this);
    }
    

    // Устанавливаем массив параметров для фильтрации документов
    var $filter_documents = [
            'client_id' => "",
            'start_date' => "", 
            'end_date' => ""
        ];
   
    
     // Устанавливаем массив параметров для фильтрации поставщиков
    var $filter_cash = [
            'start_date' => "",
            'end_date' => "",
            'client' => "",
            'grouping' => 0
        ];


    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $ordering_provider = app()->getNewForm('ordering_provider');
        $ordering_provider->showAndWait();
    }

    /**
     * @event editAlt.click-Left 
     */
    function doEditAltClickLeft(UXMouseEvent $e = null)
    {
        $select_dialog_clients = app()->getNewForm('select_clients');
        $select_dialog_clients->id = null;
        $select_dialog_clients->company = null;
        $select_dialog_clients->showAndWait();
        
        // Записываем выбранного покупателя в переменные и текстовое поле
        if (!empty($select_dialog_clients->id)) {
            $this->filter_reports['client_id'] = $select_dialog_clients->id;
            $this->editAlt->text = $select_dialog_clients->company;
            $this->editAlt->classes->add("lighting-obj-acc");
        } else {
            $this->filter_reports['client_id'] = "";
            $this->editAlt->text = "";
            $this->editAlt->classes->remove("lighting-obj-acc");
        }
    }

    /**
     * @event edit3.click-Left 
     */
    function doEdit3ClickLeft(UXMouseEvent $e = null)
    {
        $select_dialog_vendors = app()->getNewForm('select_vendors');
        $select_dialog_vendors->id = null;
        $select_dialog_vendors->company = null;
        $select_dialog_vendors->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле
        if (!empty($select_dialog_vendors->id)) {
            $this->filter_reports['vendor_id'] = $select_dialog_vendors->id;
            $this->edit3->text = $select_dialog_vendors->company;
            $this->edit3->classes->add("lighting-obj-acc");
        } else {
            $this->filter_reports['vendor_id'] = "";
            $this->edit3->text = "";
            $this->edit3->classes->remove("lighting-obj-acc");
        }
    }

    /**
     * @event edit4.click-Left 
     */
    function doEdit4ClickLeft(UXMouseEvent $e = null)
    {
        $select_dialog_users = app()->getNewForm('select_users');
        $select_dialog_users->id = null;
        $select_dialog_users->name = null;
        $select_dialog_users->showAndWait();
        
        // Записываем выбранного поставщика в переменные и текстовое поле
        if (!empty($select_dialog_users->id)) {
            $this->filter_reports['user_id'] = $select_dialog_users->id;
            $this->edit4->text = $select_dialog_users->name;
            $this->edit4->classes->add("lighting-obj-acc");
        } else {
            $this->filter_reports['user_id'] = "";
            $this->edit4->text = "";
            $this->edit4->classes->remove("lighting-obj-acc");
        }
    }

    /**
     * @event dateEdit.action 
     */
    function doDateEditAction(UXEvent $e = null)
    {
        $this->filter_reports['start_date'] = $this->dateEdit->value;
    }

    /**
     * @event dateEditAlt.action 
     */
    function doDateEditAltAction(UXEvent $e = null)
    {
        $this->filter_reports['end_date'] = $this->dateEditAlt->value;
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        $select_type_report = app()->getNewForm('select_type_report');
        $select_type_report->type_report = null;
        $select_type_report->type_name = null;
        $select_type_report->showAndWait();
        
        // Проверяем на выбранный тип отчета
        if ($select_type_report->type_report !== null) {
            $this->filter_reports['type_report'] = $select_type_report->type_report;
            $this->type_name = $select_type_report->type_name;
            $this->loading_reports($this);
        }        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        
        $select_dialog_clients = app()->getNewForm('select_clients');
        $select_dialog_clients->id = null;
        $select_dialog_clients->company = null;
        $select_dialog_clients->showAndWait();
        
        // Записываем выбранного покупателя в переменные и текстовое поле
        if (!empty($select_dialog_clients->id)) {
            $this->filter_cash['client'] = $select_dialog_clients->id;
            $this->edit->text = $select_dialog_clients->company;
            $this->edit->classes->add("lighting-obj-acc");
            $this->loading_paids($this);
        } else {
            $this->filter_cash['client'] = "";
            $this->edit->text = "";
            $this->edit->classes->remove("lighting-obj-acc");
            $this->loading_paids($this);
        }
    }

    /**
     * @event checkbox.click-Left 
     */
    function doCheckboxClickLeft(UXMouseEvent $e = null)
    {
        $this->filter_cash['grouping'] = (int) $this->checkbox->selected;
        $this->loading_paids($this);
    }

    /**
     * @event start_date_paid.action 
     */
    function doStart_date_paidAction(UXEvent $e = null)
    {
        $this->filter_cash['start_date'] = $this->start_date_paid->value;
    }

    /**
     * @event end_date_paid.action 
     */
    function doEnd_date_paidAction(UXEvent $e = null)
    {
        $this->filter_cash['end_date'] = $this->end_date_paid->value;
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $this->loading_paids($this);
    }

    /**
     * @event table_paids.click-2x 
     */
    function doTable_paidsClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_paids->selectedItem['id'])) {
            
            // Проверка на группировку списка
            if (!$this->filter_cash['grouping']) {
                $open_pay = app()->getNewForm('open_pay');
                $open_pay->id_pay = $this->table_paids->selectedItem['id'];
                $open_pay->showAndWait();
                $this->indexTblpaids = $this->table_paids->selectedIndex;
                $this->loading_paids($this);
            } else {
                $this->toast('Необходимо отключить группировку.');
            }
        }
    }

    /**
     * @event add_documents.action 
     */
    function doAdd_documentsAction(UXEvent $e = null)
    {
        app()->showFormAndWait('add_documents');
        $this->loading_documents($this);
    }

    /**
     * @event dialog_select_clients.action 
     */
    function doDialog_select_clientsAction(UXEvent $e = null)
    {
        
        $select_dialog_clients = app()->getNewForm('select_clients');
        $select_dialog_clients->id = null;
        $select_dialog_clients->company = null;
        $select_dialog_clients->showAndWait();
        
        // Записываем выбранного покупателя в переменные и текстовое поле
        if (!empty($select_dialog_clients->id)) {
            $this->filter_documents['client_id'] = $select_dialog_clients->id;
            $this->name_client->text = $select_dialog_clients->company;
            $this->name_client->classes->add("lighting-obj-acc");
            $this->loading_documents($this);
        } else {
            $this->filter_documents['client_id'] = "";
            $this->name_client->text = "";
            $this->name_client->classes->remove("lighting-obj-acc");
            $this->loading_documents($this);
        }
    }

    /**
     * @event start_date_documents.action 
     */
    function doStart_date_documentsAction(UXEvent $e = null)
    {
        $this->filter_documents['start_date'] = $this->start_date_documents->value;
    }

    /**
     * @event end_date_documents.action 
     */
    function doEnd_date_documentsAction(UXEvent $e = null)
    {
        $this->filter_documents['end_date'] = $this->end_date_documents->value;
    }

    /**
     * @event go_filter_documents.action 
     */
    function doGo_filter_documentsAction(UXEvent $e = null)
    {
        $this->loading_documents($this);
    }

    /**
     * @event table_documents.click-2x 
     */
    function doTable_documentsClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_documents->selectedItem['id'])) {
            $open_documents = app()->getNewForm('open_documents');
            $open_documents->id_document = $this->table_documents->selectedItem['id'];
            $open_documents->summ_paid_document = $this->table_documents->selectedItem['summ_paid_document'];
            $open_documents->showAndWait();
            $this->indexTbldocuments = $this->table_documents->selectedIndex;
            $this->loading_documents($this);
        }
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        app()->showFormAndWait('add_clients');
        $this->loading_clients($this);
    }

    /**
     * @event toggle_block_clients.click-Left 
     */
    function doToggle_block_clientsClickLeft(UXMouseEvent $e = null)
    {
        $this->filter_clients['block'] = $this->toggle_block_clients->selected;
        $this->loading_clients($this);
    }

    /**
     * @event text_search_client.keyDown-Enter 
     */
    function doText_search_clientKeyDownEnter(UXKeyEvent $e = null)
    {
        $this->doSearch_clientAction();
    }

    /**
     * @event search_client.action 
     */
    function doSearch_clientAction(UXEvent $e = null)
    {
        $this->filter_clients['search'] = $this->text_search_client->text;
        $this->loading_clients($this);
    }

    /**
     * @event table_clients.click-2x 
     * Открываем карточку клиента
     */
    function doTable_clientsClick2x(UXMouseEvent $e = null)
    {
        if (!empty($this->table_clients->selectedItem['id'])) {
            $open_clients = app()->getNewForm('open_clients');
            $open_clients->id_client = $this->table_clients->selectedItem['id'];
            $open_clients->showAndWait();
            $this->indexTblclients = $this->table_clients->selectedIndex;
            $this->loading_clients($this);
        }
    }

    /**
     * @event button7.action 
     * Удалям категорию
     */
    function doButton7Action(UXEvent $e = null)
    {
        if ($this->tree->selectedItems[0]) {
            
            $index_cat = $this->tree->selectedIndexes[0];
            $id_cat = $this->tree->selectedItems[0]->value->id;
            $name_cat = $this->tree->selectedItems[0]->value->text;
            
            // Выводим диалог подтверждения
            $dialog = new UXAlert('CONFIRMATION');
            $dialog->title = 'Подтвердите действие.';
            $dialog->headerText = 'Вы действительно хотите удалить категорию: '. $name_cat .' ?';
            $dialog->setButtonTypes(['Да', 'Нет']);
            
            // Проверяем, что выбрал пользователь
            if ($dialog->showAndWait() == 'Да') {
            
                // Выполняем запрос на сервер
                $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                    'key' => $this->ini->get('key'),
                    'action' => 'delete_category',
                    'id' => $id_cat,
                ], function(HttpResponse $response) use ($index_cat) {
                    
                    // Сверяем полученные данные
                    $res = $response->body();
                    if ($res['status'] == 'success') {
                        $this->loading_category_items($this, $this->filter_products['category']);
                    } else {
                        // В противном случае выводим ошибку ответ от сервера
                        if ($res['status'] === NULL) {
                            $this->toast("Интернет отсутствует или сервер не отвечает...");
                        } else {
                            $this->toast($res['status']);
                        }
                    }
                
                });
                
            }
            
        } else {
            $this->toast("Выберите категорию");
        }
    }

    /**
     * @event button5.action 
     * Открываем окно создания или редактирования папки
     */
    function doButton5Action(UXEvent $e = null)
    {    
        // Проверяем на выбор родительской категории
        $add_edit_category_item = app()->getNewForm('add_edit_category_item');
        if ($this->tree->selectedItems[0]) {
            $add_edit_category_item->id_parent = $this->tree->selectedItems[0]->value->id;
        } else {
            $add_edit_category_item->id_parent = null;
        }
        $add_edit_category_item->showAndWait();
        $this->loading_category_items($this, $this->filter_products['category']);
    }

    /**
     * @event tree.click 
     * Загружаем продукцию по выбранной категории
     * или показываем контекстное меню
     */
    function doTreeClick(UXMouseEvent $e = null)
    {
    
        
        // получаем первый выделенный элемент
        if ($this->tree->selectedItems[0]) {
            if ($this->tree->selectedItems[0]->value->id) {
                $this->filter_products['category'] = $this->tree->selectedItems[0]->value->id;
                $this->checkboxAlt->selected = false;
            }
        }
        
        // Проверяем нажатия кнопок мыши
        if ($e->button == "PRIMARY") {
            
            // Загружаем продукцию
            $this->loading_products($this);
            
        } else {
        
            // Добавляем контекстное меню для диалогов
            $tree = $this->tree;
            $tree->contextMenu = new UXContextMenu;
            
            // Кнопка создания папки
            $new = new UXMenuItem('Добавить категорию');
            $new->graphic = new UXImageView(new UXImage('res://.data/img/plus-button.png'));
            $new->on('action', function() use ($this) {
                $this->doButton5Action();
            });
            
            // Кнопка удаления папки
            $delete = new UXMenuItem('Удалить категорию');
            $delete->graphic = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
            $delete->on('action', function() use ($this) {
                $this->doButton7Action();
            });
            
            // Кнопка перемещения папки
            $follow = new UXMenuItem('Переместить категорию');
            $follow->graphic = new UXImageView(new UXImage('res://.data/img/folder-import.png'));
            $follow->on('action', function() use ($this) {
            
                $select_tree_item = app()->getNewForm('select_tree_item');
                $select_tree_item->select_cat_id = null;
                $select_tree_item->showAndWait();
                
                // Проверяем выбрана ли категория
                if (!empty($this->filter_products['category'])) {
                    $this->move_category($this, $this->filter_products['category'], $select_tree_item->select_cat_id);
                }
                
            });
            
            // Кнопка переименования папки
            $rename = new UXMenuItem('Переименовать категорию');
            $rename->graphic = new UXImageView(new UXImage('res://.data/img/folder-rename.png'));
            $rename->on('action', function() use ($this) {
                
                $rename_category = app()->getNewForm('rename_category');
                $rename_category->name = null;
                $rename_category->showAndWait();
                
                // Проверяем выбрана ли категория
                if (!empty($this->filter_products['category']) or !empty($rename_category->name)) {
                    $this->rename_category($this, $this->filter_products['category'], $rename_category->name);
                }
                
            });
            
            // Отображаем меню
            $tree->contextMenu->items->add($new);
            $tree->contextMenu->items->add($delete);
            $tree->contextMenu->items->add($follow);
            $tree->contextMenu->items->add($rename);
            $e->screenX = $e->screenX-25;
            $e->screenY = $e->screenY-25;
            $tree->contextMenu->show($this, $e->screenX, $e->screenY);
            
        }
                
    }

    /**
     * @event button8.action 
     * Открываем настройки программы
     */
    function doButton8Action(UXEvent $e = null)
    {    
        app()->showFormAndWait('Settings');
    }


    /**
     * @event checkboxAlt.click-Left 
     * Указываем выборку товара без категории
     */
    function doCheckboxAltClickLeft(UXMouseEvent $e = null)
    {
        // Проверяем на выделение чекбокса
        if ($this->checkboxAlt->selected) {
            $this->filter_products['category'] = null;
        } else {
            $this->filter_products['category'] = $this->tree->selectedItems[0]->value->id;
        }
        $this->loading_products($this);
    }


    
    
}
