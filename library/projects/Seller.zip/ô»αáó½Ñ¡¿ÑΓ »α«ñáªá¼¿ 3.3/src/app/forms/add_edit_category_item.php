<?php
namespace app\forms;

use php\lib\str;
use Exception;
use bundle\http\HttpResponse;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class add_edit_category_item extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
        // Проверяем данные на соответствие
        try {
         
            // Устанавливаем значения
            $name = $this->edit->text;
           
            // Проверка на имя
            if (empty($name)) {
                throw new Exception('Введите название.');
            }
            
            // Проверка на параметр
            if ($this->checkbox->selected) {
                $this->id_parent = null;
            }
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'add_edit_category_item',
                'p_id' => $this->id_parent,
                'name' => $name
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();                    
                    app()->getForm('Window')->toast('Категория создана!');
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
            
        } catch(Exception $e) {
            $this->toast($e->getMessage());
        }
            
            
    }

}
