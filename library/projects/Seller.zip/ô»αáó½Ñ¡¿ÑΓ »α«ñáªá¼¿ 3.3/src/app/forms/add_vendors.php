<?php
namespace app\forms;

use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use Exception;
use php\gui\framework\event\ClickEventAdapter;
use std, gui, framework, app;
use php\gui\event\UXMouseEvent; 
use php\time\Time;
use php\gui\event\UXWindowEvent; 


class add_vendors extends AbstractForm {


    /**
     * @event show
     * При появлении окна
     */
    function doShow(UXWindowEvent $event = null) {
    
        $this->maxWidth = 768; 
        $this->maxHeight = 327;
        $this->minWidth = 768;
        $this->minHeight = 327;
        $this->add_vendor->enabled = true;
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event add_vendor.action
     * Функция добавления поставщика
     */
    function doAdd_vendorAction(UXEvent $event = null) {
    
        // Проверяем данные на соответствие
        try {
         
            // Устанавливаем значения
            $this->var_company = $this->company->text;
            $this->var_city = $this->city->text;
            $this->var_address = $this->address->text;
            $this->var_people = $this->people->text;
            $this->var_people_position = $this->people_position->text;
            $this->var_phone = $this->phone->text;
            $this->var_email = $this->email->text;
            $this->var_inn = $this->inn->text;
            $this->var_ogrn = $this->ogrn->text;
            $this->var_bank_name = $this->bank_name->text;
            $this->var_bank_account = $this->bank_account->text;
            $this->var_comment = $this->textArea->text;
            $this->var_date_register = Time::now();
            $this->var_date_register = $this->var_date_register->toString('yyyy-MM-dd HH:mm:ss');
           
            // Проверка на название
            if (empty($this->var_company)) {
                throw new Exception('Нет названия поставщика.');
            }
            
            // Проверка на город
            if (empty($this->var_city)) {
                throw new Exception('Не введен город.');
            }
            
            // Проверка на адресс
            if (empty($this->var_address)) {
                throw new Exception('Не введен адрес.');
            }
            
            // Проверка на контактное лицо
            if (empty($this->var_people)) {
                throw new Exception('Введите контактное лицо.');
            }
            
            // Проверка на должность лица
            if (empty($this->var_people_position)) {
                throw new Exception('Введите должность лица.');
            }
            
            // Проверка на контактный телефон
            if (empty($this->var_phone)) {
                throw new Exception('Номер телефона обязателен.');
            }
            
            // Проверка на контактный телефон
            if (!is_numeric($this->var_phone)) {
                throw new Exception('Номером телефона, должны быть только числа.');
            }
            
            // Проверка на контактный телефон
            if (empty($this->var_email)) {
                throw new Exception('Электронный адрес обязателен.');
            }
            
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'add_vendor',
                'id_user' => $this->get_this_user('user_id'),
                'company' => $this->var_company,
                'city' => $this->var_city, 
                'address' => $this->var_address,
                'people' => $this->var_people, 
                'people_position' => $this->var_people_position,
                'phone' => $this->var_phone,
                'email' => $this->var_email,
                'inn' => $this->var_inn,
                'ogrn' => $this->var_ogrn, 
                'bank_name' => $this->var_bank_name,
                'bank_account' => $this->var_bank_account,
                'comment' => $this->var_comment
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->add_vendor->enabled = false;
                    $this->hide();
                    app()->getForm('Window')->toast("Данные успешно сохранены.");
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
                
            });
    
        } catch(Exception $e) {
            $this->toast($e->getMessage()); 
        }
        
    }


}    
