<?php
namespace app\forms;

use bundle\http\HttpResponse;
use php\gui\event\UXEvent;
use Exception;
use php\gui\framework\event\ClickEventAdapter;
use std, gui, framework, app;
use php\gui\event\UXMouseEvent; 
use php\time\Time;
use php\gui\event\UXWindowEvent;
use php\lib\arr;


class open_pay extends AbstractForm
{

    /**
     * @event show 
     * При открытии окна загружаем информацию о платеже
     */
    function doShow(UXWindowEvent $e = null)
    {    
    
        $this->maxWidth = 456; 
        $this->maxHeight = 262;
        $this->minWidth = 456;
        $this->minHeight = 262; 
        
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'open_pay',
            'id' => $this->id_pay,
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                $pay = $res['sql'];
                $this->label3->text = 'И5Д - ' . $pay[0]['document_num'];
                $this->client->text = $pay[0]['company'] . " (" . $pay[0]['city'] . ")";
                $this->input_pay_summ->text = $pay[0]['summ'];
                $this->input_pay_comment->text = $pay[0]['comment'];
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });        
        
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event button.action
     * Сохраняем изменения в платеже
     */
    function doButtonAction(UXEvent $e = null)
    {
    
        $this->pay_summ = $this->input_pay_summ->text;
        $this->pay_comment = $this->input_pay_comment->text;
        
        // Проверяем введенные данные на соответствие
        try {
    
            // Проверяем введеную сумму 
            if (empty($this->pay_summ)) {
                throw new Exception('Введите корректную сумму платежа.');
            }
        
            // Выполняем отправку данных на сервер
            $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
                'key' => $this->ini->get('key'),
                'action' => 'update_pay',
                'id' => $this->id_pay,
                'summ' => $this->pay_summ,
                'comment' => $this->pay_comment                
            ], function(HttpResponse $response) {
                
                // Выводим сообщения о статусе запроса
                $res = $response->body();
                
                // Если успешное обновление данных
                if ($res['status'] == 'success') {
                    $this->hide();
                    app()->getForm('Window')->toast("Данные платежа обновлены!");
                } else {
                    // В противном случае выводим ошибку ответ от сервера
                    if ($res['status'] === NULL) {
                        $this->toast("Интернет отсутствует или сервер не отвечает...");
                    } else {
                        $this->toast($res['status']);
                    }
                }
            
            });        
        
        } catch(Exception $e) {
            $this->toast($e->getMessage()); 
        }
            
    }

    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /**
     * @event buttonAlt.action 
     * Удаляем платежный документ
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
    
        // Выполняем отправку данных на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'delete_pay',
            'id' => $this->id_pay
        ], function(HttpResponse $response) {
            
            // Выводим сообщения о статусе запроса
            $res = $response->body();
            
            // Если успешное обновление данных
            if ($res['status'] == 'success') {
                $this->hide();
                app()->getForm('Window')->toast("Платёж удалён!");
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $this->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $this->toast($res['status']);
                }
            }
        
        });
    }

}
