<?php
namespace app\modules;

use php\gui\UXMenuItem;
use php\gui\UXContextMenu;
use php\gui\UXImage;
use php\gui\UXImageView;
use php\gui\UXTreeItem;
use php\gui\framework\AbstractModule;
use app\modules\ItemValue;


class tree_make extends AbstractModule
{


    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки категорий продукции и услуг
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    
    // Создаем переменную items дерева
    var $tree_items = [];

    // Настраиваем дерево и вызываем рекурсию
    function refreshTree($category, $form, $focus)
    {
        $tree = $form->tree;
        $tree->root = new UXTreeItem(new ItemValue(0, "Товары и услуги"));
        $tree->root->graphic = new UXImageView(new UXImage('res://.data/img/database.png'));
        $tree->root->expanded = true;
        $this->refreshTreeItem($category, $tree->root);
        
        // Если передан параметр выделения категории
        if (!empty($focus)) {
            $form->tree->selectedItems = [$this->tree_items[$focus]];
        }
        
    }
    
    // Рекурсивная функция обработки массива
    function refreshTreeItem($category, UXTreeItem $item) 
    {
        foreach ($category as $cat) {
            $subItem = new UXTreeItem(new ItemValue($cat['id'], (string) $cat['name']));
            $subItem->expanded = true;
            if (is_array($cat['childs'])) {
                $this->refreshTreeItem($cat['childs'], $subItem);
            }
            $subItem->graphic = new UXImageView(new UXImage('res://.data/img/folder2.png'));
            $item->children->add($subItem);
            $this->tree_items[$cat['id']] = $subItem;
        }
    }    


}