<?php
namespace app\modules;

use php\io\FileStream;
use php\lib\fs;
use php\io\File;
use php\gui\UXImage;
use php\gui\UXImageView;
use bundle\http\HttpResponse;
use php\gui\framework\AbstractForm;
use php\gui\framework\AbstractModule;


class Format_reports extends AbstractModule
{


    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки отчетов
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки отчетов */
    function loading_reports(AbstractForm $form) {
    
        // Show preloader
        $form->showPreloader();
        
        // Выполняем запрос на сервер
        app()->module("DataBase")->httpClient->postAsync(app()->module("DataBase")->ini->get('server') . '/cloud/db.php', [
            'key' => app()->module("DataBase")->ini->get('key'),
            'action' => 'loading_reports',
            'type_report' => $form->filter_reports['type_report'],
            'start_date' => $form->filter_reports['start_date'],
            'end_date' => $form->filter_reports['end_date'],
            'vendor_id' => $form->filter_reports['vendor_id'],
            'client_id' => $form->filter_reports['client_id'],
            'user_id' => $form->filter_reports['user_id']
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                
                // Создаем папку для документов при ее отсутствии
                $dir = new File(fs::abs('./documents'));
                $dir->mkdirs();
                
                // Создаем поток для записи в файл
                $form->file = fs::abs('./documents/reports.html');
                unlink($form->file); // Удаляем файл с таким именем
                $stream = new FileStream($form->file, 'a+');
                
                // Создаем файл именем номера накладной
                $stream->write("
                    <!DOCTYPE HTML>
                    <html>
                    <head>
                    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
                    <title>Сформированный отчёт</title>
                
                    <style>
                        html {
                            padding: 0px;
                            font: 12px/16px arial, sans-serif;
                        }
                        
                        body {
                            padding: 0px;
                            font-size: 12px;
                            color: #000;
                        }
                        
                        .margin-bottom-row {
                            margin-bottom: 10px! Important;
                        }
                        .margin-bottom-header {
                            margin-bottom: 15px! Important;
                        }
                        
                        .text-center {
                            text-align: center;
                        }
                        .text-left {
                            text-align: left;
                        }
                        .text-right {
                            text-align: right;
                        }
                        .text-small {
                            font-size: 90%;
                        }
                        .strong {
                            font-weight: 700;
                        }
                        .normal {
                            font-weight: normal;
                        }
                        
                        
                        /*--------------------------------------------------------------*/
                        table {
                            width: 100%;
                            display: table;
                            border-radius: 2px;
                            padding: 1px;
                        }
                        table th {
                            font-weight: 600;
                            text-align: inherit;
                            padding: 6px 11px;
                            word-break: normal;
                            white-space: nowrap;
                        }
                        table tr {
                            display: table-row;
                            cursor: default;
                        }
                        table tr:nth-child(2n+1) {
                            background: none;
                        } 
                        table tr td {
                            padding: 0px 0px;
                            display: table-cell;
                            vertical-align: middle;
                            word-break: normal;
                            white-space: nowrap;
                        }
                        table tr td.full-width {
                            width: 100%;
                        }
                        
                        table.list {
                            border-collapse: collapse;
                        }
                        
                        table.list tr td {
                            padding: 1px 10px;
                            border: 1px solid #000;
                            display: table-cell;
                            vertical-align: middle;
                            word-break: normal;
                            white-space: nowrap;
                        }
                        /*--------------------------------------------------------------*/
                        
                        
                        
                        .summ_num:first-letter {
                            text-transform: uppercase;
                        }
                        
                        .mp-print {
                            float: right;
                        }
                        
                        .qr_code {
                            position: relative;
                            vertical-align: middle;
                            float: right;
                            margin-right: -9px;
                            width: 90px;
                            height: 90px;
                        }
                    </style>
                
                    </head>
                    <body>
                    
                    
                        <div class='margin-bottom-header'>
                            <h4 class='text-center'>Сформированный отчёт за период: <span class='strong'>".$form->dateEdit->value."</span> по <span class='strong'>".$form->dateEditAlt->value."</span></h4>
                            <p>
                                <span class='strong'>Покупатель:</span> ".$form->editAlt->text."</br>
                                <span class='strong'>Поставщик:</span> ".$form->edit3->text."</br>
                                <span class='strong'>Пользователь:</span> ".$form->edit4->text."
                            </p>
                        </div>
            "); 

            //-------------------------------------------------------------------------------------------------------
            // Если выбран тип отчета - Продукция
            //-------------------------------------------------------------------------------------------------------
            if ($form->filter_reports['type_report'] == 0) {
                    
                $stream->write("
                <table class='list margin-bottom-header'>
                    <tr>
                        <td>№</td>
                        <td>Артикул</td>
                        <td class='full-width'>Наименование</td>
                        <td>Количество шт.</td>
                        <td>Цена</td>
                        <td>Сумма</td>
                    </tr>
            
                "); 
                
                // Очищаем таблицу и выводим данные
                $i = 1;
                $summ_report = 0;
                foreach ($res['sql'] as $row) {
                    $reports = $row;                    
                    $stream->write("<tr>");
                    $stream->write("<td>".$i."</td>"); 
                    $stream->write("<td>".$reports['vendor_code']."</td>"); 
                    $stream->write("<td>".$reports['name']."</td>");
                    $stream->write("<td>".number_format($reports['all_count_products'])."</td>");
                    $stream->write("<td>".number_format($reports['price'])."</td>");
                    $stream->write("<td>".number_format($reports['product_summ'])."</td>");
                    $stream->write("</tr>");
                    $i++;
                    $summ_report = ($summ_report + $reports['product_summ']);                    
                }
                    
                
             }
             
             //-------------------------------------------------------------------------------------------------------
             // Если выбран тип отчета - Покупатели
             //-------------------------------------------------------------------------------------------------------
             if ($form->filter_reports['type_report'] == 1) {
                    
                $stream->write("
                <table class='list margin-bottom-header'>
                    <tr>
                        <td>№</td>
                        <td class='full-width'>Покупатель</td>
                        <td>Количество шт.</td>
                        <td>Сумма</td>
                    </tr>
            
                "); 
                
                // Очищаем таблицу и выводим данные
                $i = 1;
                $summ_report = 0;
                foreach ($res['sql'] as $row) {
                    $reports = $row;                    
                    $stream->write("<tr>");
                    $stream->write("<td>".$i."</td>"); 
                    $stream->write("<td>".$reports['Client_company']."</td>");
                    $stream->write("<td>".number_format($reports['all_count_products'])."</td>");
                    $stream->write("<td>".number_format($reports['product_summ'])."</td>");
                    $stream->write("</tr>");
                    $i++;
                    $summ_report = ($summ_report + $reports['product_summ']);                      
                }
                    
                
             }
             
             //-------------------------------------------------------------------------------------------------------
             // Если выбран тип отчета - Пользователи
             //-------------------------------------------------------------------------------------------------------
             if ($form->filter_reports['type_report'] == 2) {
                
                $stream->write("
                <table class='list margin-bottom-header'>
                    <tr>
                        <td>№</td>
                        <td class='full-width'>Пользователь</td>
                        <td>Количество шт.</td>
                        <td>Сумма</td>
                    </tr>
            
                "); 
                
                // Очищаем таблицу и выводим данные
                $i = 1;
                $summ_report = 0;
                foreach ($res['sql'] as $row) {
                    $reports = $row;                    
                    $stream->write("<tr>");
                    $stream->write("<td>".$i."</td>"); 
                    $stream->write("<td>".$reports['first_name']." ".$reports['last_name']."</td>");
                    $stream->write("<td>".number_format($reports['all_count_products'])."</td>");
                    $stream->write("<td>".number_format($reports['product_summ'])."</td>");
                    $stream->write("</tr>");
                    $i++;
                    $summ_report = ($summ_report + $reports['product_summ']);                    
                }
                    
                
             }
             
             //-------------------------------------------------------------------------------------------------------
             
                 
                // Закрываем поток записи в файл
                $stream->write("
                        </table>      
                        
                        <table>
                            <tr>
                                <td class='text-left'>
                                    <span class='strong'>Сумма отчёта прописью: </span> <div class='summ_num'>".app()->module('num2str')->num2str($summ_report)."</div>
                                </td>
                                <td class='text-right'>
                                    <span class='strong'>Сумма отчёта: </span></br> ".number_format($summ_report)." руб.
                                </td>
                            </tr>
                        </table>                        
                        
                    </body>
                </html>
                "); 
                
                $stream->close();                    
            
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
            
            // Hide preloader
            $form->hidePreloader();
            
            // Открываем окно предпросмотра печати документа
            $window_print = app()->getNewForm('window_print');
            $window_print->file = $form->file;
            $window_print->showAndWait();
    
        });
        
    }



}