<?php
namespace app\modules;

use App;
use php\io\IOException;
use Exception;
use framework;
use gui;
use bundle\http\HttpResponse;
use php\util\Locale;
use php\lib\num;
use php\lib\str;
use php\gui\text\UXFont;
use php\gui\framework\AbstractForm;
use app\modules\DataBase;
use php\time\TimeFormat;
use php\gui\framework\DataUtils;
use php\lib\arr;
use php\time\Time;
use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent;


class DataBase extends AbstractModule
{

     
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Создаем массив пользовательских данных
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    
   
    // Создаем массив пользовательских данных
    var $_session_user = [
            'user_id' => "",
            'user_permission' => "", 
            'user_mail' => "", 
            'first_name' => "",
            'last_name' => ""
        ];
        
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция возвращает выбранное поле массива авторизованного пользователя
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    
   
    /* Это используется например для добавления поставщика, покупателя, докумена реализации в БД, 
       Туда записывается uid пользователя который это сделал
    */
    function get_this_user($field) {
        return $this->_session_user[$field];
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки поставщиков
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки поставщиков */
    function loading_vendors(AbstractForm $form) {
    
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_vendors',
            'search' => $form->filter_vendors['search'],
            'block' => $form->filter_vendors['block'] 
        ], function(HttpResponse $response) use ($form) {
        
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                // Проверяем кол. загруженных строк
                if (count($res['sql']) > 0) {
                
                    // Очищаем таблицу и выводим данные
                    $index = $form->table_vendors->selectedIndex;
                    $form->table_vendors->items->clear();
                    foreach ($res['sql'] as $row) {
                        $vendor = $row;
                        $vendor['img'] = new UXImageView(new UXImage('res://.data/img/card-address.png'));
                        $vendor['destination'] = $vendor['city'] . ' - ' . $vendor['address'];
                        $vendor['contacts'] = $vendor['people'] . ' - ' . $vendor['people_position'];
                        
                        // Устанавливаем формат даты для вывода
                        $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss'); 
                        $time = $timeFormat->parse($vendor['date_register']); 
                        $vendor['date_register'] = $time->toString('dd MMMM yyyy', Locale::RUSSIAN());
                        
                        // Добавляем строку в таблицу
                        $form->table_vendors->items->add($vendor);
                    }
                    
                    // Выделяем индекс
                    $form->table_vendors->selectedIndex = $index;
                
                } else {
                    $form->table_vendors->items->clear();
                    $form->toast("Ничего не найдено");
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки категорий продукции и услуг
    //----------------------------------------------------------------------------------------------------------------------------------------------------
      
    
    /* Функция загрузки категорий продукции и услуг */
    function loading_category_items(AbstractForm $form, $focus) {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_category_items'
        ], function(HttpResponse $response) use ($form, $focus) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $category =  $res['sql'];
                app()->module('tree_make')->refreshTree($category, $form, $focus);
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция перемещения категории
    //----------------------------------------------------------------------------------------------------------------------------------------------------
      
    
    /* Функция перемещения категории */
    function move_category(AbstractForm $form, $category_id, $category_select) {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'category_id' => $category_id,
            'category_select' => $category_select,
            'action' => 'move_category'
        ], function(HttpResponse $response) use ($form, $category_id) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $this->loading_category_items($form, $category_id);
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
    
        
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция переименования категории
    //----------------------------------------------------------------------------------------------------------------------------------------------------
      
    
    /* Функция переименования категории */
    function rename_category(AbstractForm $form, $category_id, $name) {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'category_id' => $category_id,
            'name' => $name,
            'action' => 'rename_category'
        ], function(HttpResponse $response) use ($form, $category_id) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                $this->loading_category_items($form, $category_id);
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
        
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки продукции
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки продукции */
    function loading_products(AbstractForm $form) {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_products',
            'category' => $form->filter_products['category'],
            'vendor' => $form->filter_products['vendor_id'],
            'search' => $form->filter_products['search'],
            'archive' => $form->filter_products['archive']
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
                
                // Проверяем кол. загруженных строк
                if (count($res['sql']) > 0) {
                
                    // Очищаем таблицу и выводим данные
                    $index = $form->table_products->selectedIndex;
                    $form->table_products->items->clear();
                    
                    foreach ($res['sql'] as $row) {
                        $product = $row;
                        $product['img'] = new UXImageView(new UXImage('res://.data/img/price-tag.png'));
                        $product['price_int'] = $product['price'];
                        $product['price'] = number_format($product['price']);
                        $product['price_base_int'] = $product['price_base'];
                        $product['price_base'] = number_format($product['price_base']);
                        $product['summ'] = number_format($product['price_base_int']*$product['count']);
                        
                        // Добавляем строку в таблицу
                        $form->table_products->items->add($product);
                    }
                    
                    // Выделяем индекс
                    $form->table_products->selectedIndex = $index;
                    
                } else {
                    $form->table_products->items->clear();
                    $form->toast("Ничего не найдено");
                }
            
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки покупателей
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки покупателей */
    function loading_clients(AbstractForm $form) {
    
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_clients',
            'search' => $form->filter_clients['search'],
            'block' => $form->filter_clients['block']
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                // Проверяем кол. загруженных строк
                if (count($res['sql']) > 0) {
                
                    // Очищаем таблицу и выводим данный
                    $index = $form->table_clients->selectedIndex;
                    $form->table_clients->items->clear();
                    foreach ($res['sql'] as $row) {
                        $client = $row;
                        $client['img'] = new UXImageView(new UXImage('res://.data/img/card-address.png'));
                        $client['destination'] = $client['city'] . ' - ' . $client['address'];
                        $client['contacts'] = $client['people'] . ' - ' . $client['people_position'];
                        
                        // Устанавливаем формат даты для вывода
                        $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss'); 
                        $time = $timeFormat->parse($client['date_register']); 
                        $client['date_register'] = $time->toString('dd MMMM yyyy', Locale::RUSSIAN());
                        
                        // Добавляем строку в таблицу
                        $form->table_clients->items->add($client);
                    }
                    
                    // Выделяем индекс
                    $form->table_clients->selectedIndex = $index;
                
                } else {
                    $form->table_clients->items->clear();
                    $form->toast("Ничего не найдено");
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
    
        });
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки документов
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки документов */
    function loading_documents(AbstractForm $form) {
        
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_documents',
            'start_date' => $form->filter_documents['start_date'],
            'end_date' => $form->filter_documents['end_date'],
            'client' => $form->filter_documents['client_id']
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                // Проверяем кол. загруженных строк
                if (count($res['sql']) > 0) {
                
                    // Очищаем таблицу и выводим данный
                    $index = $form->table_documents->selectedIndex;
                    $form->table_documents->items->clear();
                    foreach ($res['sql'] as $row) {
                        $document = $row;
                        
                        // Проверяем на проведенность документа
                        if ($document['uploaded'] == 1) {
                            $document['uploaded'] = new UXImageView(new UXImage('res://.data/img/blue-document-bookmark.png'));
                        } else {
                            $document['uploaded'] = new UXImageView(new UXImage('res://.data/img/blue-document-invoice.png'));
                        }
                        
                        // Проверяем на доставку
                        if ($document['delivery'] == 1) {
                            $document['delivery'] = new UXImageView(new UXImage('res://.data/img/tick-button.png'));
                        } else {
                            $document['delivery'] = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
                        }
                        
                        // Проверяем на оплату
                        $summ = intval($document['document_summ']);
                        $paids = intval($document['summ_paid_document']);
                        if ($summ != $paids or $summ == 0) {
                            $document['paid'] = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
                        } else {
                            $document['paid'] = new UXImageView(new UXImage('res://.data/img/tick-button.png'));
                        }
                        
                        // Подготавливаем данные к выводу
                        $document['img'] = new UXImageView(new UXImage('res://.data/img/blue-document-invoice.png'));
                        $document['company'] = $document['company'] . ' (' . $document['city'] . ')';
                        $document['agent'] = $document['first_name'] . ' ' . $document['last_name'];
                        $document['document_summ'] = number_format($document['document_summ']);
                        $document['summ_paid'] = number_format($document['summ_paid_document']);
                        $document['document_profit'] = number_format($document['document_profit']);
                        $document['count_products'] = number_format($document['count_products']);
                        $document['count_positions'] = number_format($document['count_positions']);
                        
                        // Устанавливаем формат даты для вывода
                        $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss'); 
                        $time = $timeFormat->parse($document['date_create']); 
                        $document['date_create'] = $time->toString('dd MMMM yyyy - HH:mm', Locale::RUSSIAN());
                        
                        // Добавляем строку в таблицу
                        $form->table_documents->items->add($document);                    
                        
                    }
                    
                    // Выделяем индекс
                    $form->table_documents->selectedIndex = $index;
                    
                } else {
                    $form->table_documents->items->clear();
                    $form->toast("Ничего не найдено");
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
        
        });    
                           
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки продукции в документе
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки продукции в документе */
    function loading_products_documents(AbstractForm $form) {
    
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_products_documents',
            'id' => $form->id_document,
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
    
                // Записываем в таблицу
                $index = $form->table_products_document->selectedIndex;
                $form->table_products_document->items->clear();
                $summ_document = 0;
                foreach ($res['sql'] as $row) {
                    $sales = $row;
                    $sales['img'] = new UXImageView(new UXImage('res://.data/img/price-tag.png'));
                    $sales['price'] = number_format($sales['price']);
                    $sales['count'] = number_format($sales['count']);
                    $summ_document = ($summ_document + $sales['product_summ']);
                    $sales['product_summ'] = number_format($sales['product_summ']);
                    
                    // Добавляем строку в таблицу
                    $form->table_products_document->items->add($sales);
                }
                
                // Если существует на форме сумма документа - пишем сумму
                if ($form->text_summ_document) {
                    $form->document_summ = $summ_document;
                    $form->text_summ_document->text = number_format($summ_document) . " руб.";
                }
                
                // Выполняем действия при значеннии оплаты 
                if ($form->summ_paid_document == $form->document_summ && $form->document_summ != "0") {
                    $form->panel_pay_doc->classes->add("lighting-acc");
                    $form->save_pay->enabled = false;
                } else {
                    $form->panel_pay_doc->classes->add("lighting-err");
                    $form->save_pay->enabled = true;
                }
                
                // Если документ полностью загрузился, убираем preloader
                $form->hide_preloader['count'] += 1;
                if ($form->hide_preloader['count'] == 2) {
                    $form->hidePreloader();
                }
                
                // Выделяем индекс
                $form->table_products_document->selectedIndex = $index;
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
        
        });
        
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки денежных средств
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки денежных средств */
    function loading_paids(AbstractForm $form) {
                
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_cash',
            'start_date' => $form->filter_cash['start_date'],
            'end_date' => $form->filter_cash['end_date'],
            'client' => $form->filter_cash['client'],
            'grouping' => $form->filter_cash['grouping']
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                // Проверяем кол. загруженных строк
                if (count($res['sql']) > 0) {
        
                    // Записываем в таблицу
                    $index = $form->table_paids->selectedIndex;
                    $form->table_paids->items->clear();
                    foreach ($res['sql'] as $row) {
                        $paid = $row;
                        $paid['img'] = new UXImageView(new UXImage('res://.data/img/money-bag-dollar.png'));
                        $paid['user'] = $paid['first_name'] . ' ' . $paid['last_name'];
                        $paid['client'] = $paid['client'] . ' (' . $paid['client_city'] . ')';
                        
                        // Устанавливаем выбор суммы
                        if ($form->filter_cash['grouping']) {
                            $paid['summ'] = number_format($paid['summ_group']);
                        } else {
                            $paid['summ'] = number_format($paid['summ']);
                        }
                        
                        // Устанавливаем формат даты для вывода
                        $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss');
                        $time = $timeFormat->parse($paid['date_document']);
                        $paid['date_document'] = $time->toString('dd MMMM yyyy', Locale::RUSSIAN());
                        $time = $timeFormat->parse($paid['date_paid']);
                        $paid['date_paid'] = $time->toString('dd MMMM yyyy - HH:mm', Locale::RUSSIAN());
                        
                        // Добавляем строку в таблицу
                        $form->table_paids->items->add($paid);
                    }
                    
                    // Выделяем индекс
                    $form->table_paids->selectedIndex = $index;
                    
                } else {
                    $form->table_paids->items->clear();
                    $form->toast("Ничего не найдено");
                }
                
                  
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
        
        }); 
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки пользователей
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки пользователей */
    function loading_users(AbstractForm $form) {
    
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_users'
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                // Записываем в таблицу
                $index = $form->table_users->selectedIndex;
                $form->table_users->items->clear();
        
                //Массив уровня доступа пользователей
                $user_permission = [
                    '0' => "Администратор", 
                    '1' => "Оператор", 
                    '2' => "Менеджер"
                ];
                
                foreach ($res['sql'] as $row) {
                    $user = $row;
                    $user['img'] = new UXImageView(new UXImage('res://.data/img/user2.png'));
                    $user['name'] = $user['first_name'] . " " . $user['last_name'];
                    
                    // Устанавливаем формат уровня доступа для вывода
                    $user['permission'] = $user_permission[$user['permission']];
                    
                    // Устанавливаем формат даты для вывода
                    $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss'); 
                    $time = $timeFormat->parse($user['date_register']); 
                    $user['date_register'] = $time->toString('dd MMMM yyyy', Locale::RUSSIAN());
                    
                    // Проверяем на блокировку - пишем обратные значения (смотреть таблицу)
                    if ($user['block'] == 1) {
                        $user['block'] = new UXImageView(new UXImage('res://.data/img/cross-button.png'));
                    } else {
                        $user['block'] = new UXImageView(new UXImage('res://.data/img/tick-button.png'));
                    }
                    
                    // Добавляем строку в таблицу
                    $form->table_users->items->add($user);
                }
                
                // Выделяем индекс
                $form->table_users->selectedIndex = $index;
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
        
        });
                                
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    // Функция загрузки статистики организации
    //----------------------------------------------------------------------------------------------------------------------------------------------------
    

    /* Функция загрузки статистики организации */
    function loading_statistics(AbstractForm $form) {
    
        // Выполняем запрос на сервер
        $this->httpClient->postAsync($this->ini->get('server') . '/cloud/db.php', [
            'key' => $this->ini->get('key'),
            'action' => 'loading_statistics'
        ], function(HttpResponse $response) use ($form) {
            
            // Сверяем полученные данные
            $res = $response->body();
            if ($res['status'] == 'success') {
            
                foreach ($res['sql'] as $row) {
                    $static = $row;
                    $form->label3->text = number_format($static['summ_sklad']) . " руб.";
                    $form->label4->text = number_format($static['sales_to_day']) . " руб.";
                    $form->label5->text = number_format($static['sales_to_month']) . " руб.";
                    $form->label15->text = number_format($static['month_profit']) . " руб.";
                    $form->label6->text = $static['akb_client'];
                    $form->label11->text = number_format($static['summ_cash_to_day']) . " руб.";
                }
                
                // Если есть склад и есть продажи выделяем текст в цвет акцента
                if ($static['summ_sklad'] > 0) {
                    $form->label3->classesString = "font-accent";
                    //$form->panelAlt->classesString = "bars bars-accent";
                } else {
                    $form->label3->classesString = "font-warning";
                }
                if ($static['sales_to_day'] > 0) {
                    $form->label4->classesString = "font-accent";
                    //$form->panel3->classesString = "bars bars-accent";
                } else {
                    $form->label4->classesString = "font-warning";
                }
                if ($static['sales_to_month'] > 0) {
                    $form->label5->classesString = "font-accent";
                    //$form->panel4->classesString = "bars bars-accent";
                } else {
                    $form->label5->classesString = "font-warning";
                }
                if ($static['month_profit'] > 0) {
                    $form->label15->classesString = "font-accent";
                    //$form->panel4->classesString = "bars bars-accent";
                } else {
                    $form->label15->classesString = "font-warning";
                }
                
            } else {
                // В противном случае выводим ошибку ответ от сервера
                if ($res['status'] === NULL) {
                    $form->toast("Интернет отсутствует или сервер не отвечает...");
                } else {
                    $form->toast($res['status']);
                }
            }
        
        });
                                
    }
        
      
}


