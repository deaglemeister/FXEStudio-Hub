<?php
namespace app\modules;

use php\util\Locale;
use php\time\TimeFormat;
use php\gui\framework\AbstractModule;


class format_vars extends AbstractModule
{


    // функция перевода параметра date/time в формат для editDate
    function format_date_combo($date) {
        if (!empty($date)) {
            $timeFormat = new TimeFormat('yyyy-MM-dd HH:mm:ss'); 
            $time = $timeFormat->parse($date); 
            $date = $time->toString('dd.MM.yyyy', Locale::RUSSIAN());
            return $date;  
        }
        
    }


}