<!DOCTYPE HTML>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
	<title>Торговая компания</title>
	<link rel="icon" href="img/favicon.png" sizes="16x16" type="image/png">

	<!-- Загружаем стили -->
	<link href="http://91.246.116.73/css/normalize.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="http://91.246.116.73/css/flexboxgrid.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="http://91.246.116.73/css/style.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">	
</head>
<body>
		<div class="main">
			<div class="row center-xs">
				<div class="col-xs-12">
					<div class="box">
						<p class="whitegray">
						
                        
							<?php
							// BO&MA v3
							setlocale(LC_TIME, 'ru_RU.UTF-8');


							//---------------------------------------------------------------------------------------------------------------------------------------------------------------
							// Показываем статистику по товарной накладной
							//---------------------------------------------------------------------------------------------------------------------------------------------------------------


								// Проверяем данные на соответствие
								try {

									// Устанавливаем значения
									$uuid = $_GET['uuid'];
									
									// Проверка на id заказа
									if (empty($uuid)) {
										throw new Exception();
									}
									
									// Подключаемся к базе данных
									if (file_exists('cloud/db.db3')) {
										$dbh = new PDO('sqlite:cloud/db.db3');
										$dbh->exec("PRAGMA foreign_keys = ON;");
										$dbh->exec("PRAGMA SQLITE_OPEN_NOMUTEX;");
									} else {
										throw new Exception();
									}
									
									// Выполняем запрос к серверу
									$sth = $dbh->prepare('SELECT D.*,
															   U.first_name,
															   U.last_name,
															   C.company,
															   C.people,
															   C.people_position,
															   C.phone,
															   C.city,
															   C.address,
															   C.email,
															   (
																   SELECT SUM( ( (price - (price * discount) / 100) * count) ) 
																	 FROM Sales
																	WHERE id_document = D.id
															   )
															   AS summ_document,
															   (
																   SELECT SUM(summ) 
																	 FROM Cash
																	WHERE id_document = D.id
															   )
															   AS summ_paid_document
														  FROM Documents AS D
															   INNER JOIN
															   Users AS U ON D.id_user = U.id
															   INNER JOIN
															   Clients AS C ON D.id_client = C.id
														 WHERE D.uuid = ?;');
									$sth->execute(array($uuid)); 

									// Выводим сообщение
									$result = $sth->fetchAll();
									
									// Проверяем количество строк ответа
									if (count($result) !== 1) {
										include('err/501.php');
										exit();
									}
									
									echo '
										<h3>'.$result[0]['company'].'</h3>
										<p class="wells bg-whitegray whitegray">Уточняйте информацию в компании!</p>
										<span class="strong">Адрес:</span> '.$result[0]['city'].', '.$result[0]['address'].'</br>
										<span class="strong">Номер документа:</span> И5Д-'.$result[0]['id'].'</br>
										<span class="strong">Сумма документа:</span> '.number_format($result[0]['summ_document']).' руб.</br>
									';
									
									// Проверяем документ на оплату
									if (empty($result[0]['summ_paid_document'])) {
										echo '<span class="strong">Оплата:</span> не произведена.</br>';
									} else {
										echo '<span class="strong">Оплата:</span> '.number_format($result[0]['summ_paid_document']).' руб.</br>';
									}
									
									// Проверяем документ на доставку
									if ($result[0]['delivery'] == 1) {
										echo '<span class="strong">Получение:</span> вручено</br>';
									} else {
										echo '<span class="strong">Получение:</span> не произведено.</br>';
									}

								} catch(Exception $e) {

									// Выводим сообщение
									include('err/501.php');
									exit();
								
								}


								// Закрываем соединение с базой
								$dbh = null;

								
							?>

						</p>
					</div>
				</div>
			</div>
										
		</div>

</body>
</html>