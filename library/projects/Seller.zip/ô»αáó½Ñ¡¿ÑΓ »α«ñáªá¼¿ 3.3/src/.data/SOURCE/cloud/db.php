<?php
// BO&MA v3
session_start();
setlocale(LC_TIME, 'ru_RU.UTF-8');
$action = $_POST['action'];
$key = $_POST['key'];


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Проверяем клиента на правильный ключ к серверу
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


if (empty($key) or empty($action)) {
	include('../err/403.php');
	exit();
} elseif ($key !== "b7e4587a-ede4-474d-8c5f-7d4309d8ac58") {
	$message = ['status' => 'Клиент передал неверный ключ'];
	echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
	exit();
}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Функция генерации uuid
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


function gen_uuid() {
	return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
		mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
		mt_rand( 0, 0xffff ),
		mt_rand( 0, 0x0fff ) | 0x4000,
		mt_rand( 0, 0x3fff ) | 0x8000,
		mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
	);
}


try {
	// Подключаемся к базе данных
	if (file_exists('db.db3')) {
		$dbh = new PDO('sqlite:db.db3');
		$dbh->exec("PRAGMA foreign_keys = ON;");
		$dbh->exec("PRAGMA SQLITE_OPEN_NOMUTEX;");
	} else {
		throw new Exception('Ошибка базы данных');
	}
} catch(Exception $e) {
	// Выводим сообщение
	$message = ['status' => $e->getMessage()];
	echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Авторизация пользователя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


switch ($action) {
case 'login':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$mail = $_POST['mail'];
		$password = $_POST['password'];

		if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {} else {
			throw new Exception('Вы указали неверный e-mail');
		}
		if (empty($password)) {
			throw new Exception('Введите пароль');
		}

		$sth = $dbh->prepare("SELECT * FROM Users WHERE mail = ?;");
		$sth->execute(array($mail));
					
		// Обработка полученных данных
		$result = $sth->fetchAll();
		if (count($result) == 1) {
			foreach ($result as $row) {

				// Генерируем хэш пароля из соли и сверяем данные
				$hash_password = hash('sha256', $password . $row['salt']);
				
				// Сверяем почту
				if($mail != $row['mail']){
					throw new Exception('Логин не совпадает');
				}
				
				// Сверяем хеш пароля
				if ($hash_password != $row['password']) {
					throw new Exception('Пароль не совпадает');
				}
				
				// Сверяем на блокировку пользователя
				if ($row['block'] == 1) {
					throw new Exception('Доступ заблокирован');
				}

				// Обновляем соль и хэш пароля
				$id = $row['id'];
				$newsalt = microtime();
				$newpass = hash('sha256', $password . $newsalt);
				$last_login = date("Y-m-d H:i:s");
				$stmt = $dbh->prepare('UPDATE Users SET password=:password, salt=:salt, last_login=:last_login WHERE id=:id');
				$stmt->execute(array(':password'=>$newpass, ':salt'=>$newsalt, ':last_login'=>$last_login, ':id'=>$id));

				// Заносим значения в массив
				$_session_user = [
					'status' => 'success',
					'user_id' => $row['id'],
					'user_mail' => $row['mail'],
					'user_permission' => $row['permission'],
					'first_name' => $row['first_name'],
					'last_name' => $row['last_name']
				];

				// Выводим сообщение
				echo json_encode($_session_user);

			}
		} else {
			throw new Exception('Пользователь не найден');
		}

		

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка пользователей
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_users':


	// Проверяем данные на соответствие
	try {

		// Подготавливаем запрос в базу данных
		$query = $dbh->query('SELECT * FROM Users;'); 

		// Выводим сообщение
		$result = $query->fetchAll();
		$message = [
			'status' => 'success',
			'sql' => $result
		];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем пользователя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_user':


	// Проверяем данные на соответствие
	try {
	
		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Users WHERE id = ?');
		$sth->execute(array($id));

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
			'status' => 'success',
			'sql' => $result
		];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление пользователя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_user':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$permission = (int) $_POST['permission'];
		$mail = $_POST['mail'];
		$phone = $_POST['phone'];
		$password = $_POST['password'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$salt = $_POST['salt'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Проверка на почту
		if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
			throw new Exception('Вы указали неверный e-mail.');
		}

		// Проверка на изменения пароля
		if (empty($salt)) {
			$stmt = $dbh->prepare('UPDATE Users SET permission=:permission, mail=:mail, phone=:phone, first_name=:first_name, last_name=:last_name WHERE id=:id;');
			$stmt->execute(array(':permission'=>$permission, ':mail'=>$mail, ':phone'=>$phone, ':first_name'=>$first_name, ':last_name'=>$last_name, ':id'=>$id));		 	 
		} else {
			$stmt = $dbh->prepare('UPDATE Users SET permission=:permission, mail=:mail, phone=:phone, password=:password, salt=:salt, first_name=:first_name, last_name=:last_name WHERE id=:id;');
			$stmt->execute(array(':permission'=>$permission, ':mail'=>$mail, ':phone'=>$phone, ':password'=>$password, ':salt'=>$salt, ':first_name'=>$first_name, ':last_name'=>$last_name, ':id'=>$id));	
		}
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Регистрация пользователя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_user':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$date_register = date("Y-m-d H:i:s");
		$mail = $_POST['mail'];
		$permission = (int) $_POST['permission'];
		$phone = $_POST['phone'];
		$password = $_POST['password'];
		$salt = $_POST['salt'];
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];

		// Проверка на почту
		if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
			throw new Exception('Вы указали неверный e-mail');
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Users WHERE mail = ?;');
		$sth->execute(array($mail));

		// Обработка полученных данных
		$result = $sth->fetchAll();
		if (count($result) > 0) {
			throw new Exception('Такой пользователь существует');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Users (permission, mail, phone, password, salt, first_name, last_name, last_login, date_register) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
		$stmt->execute(array($permission, $mail, $phone, $password, $salt, $first_name, $last_name, $date_register, $date_register));
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Блокировки пользователя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'block_user':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$block = (int) $_POST['block'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на блок
		if ($block !== 1) {
			$block = 0;
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Users SET block=:block WHERE id=:id;');
		$stmt->execute(array(':block'=>$block, ':id'=>$id));	 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}

	
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка поставщиков
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_vendors':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$search = $_POST['search'];
		$block = (int) $_POST['block'];

		// Если существует на форме input поиска - то прочитываем его
		if (!empty($search)) {
			$str = $search;
			$search = ' AND (company LIKE "%' . $str . '%" OR phone LIKE "%' . $str . '%" OR inn LIKE "%' . $str . '%")';
		} else {
			$search = '';
		}

		// Если существует на форме checbox - блокированные, то прочитываем его
		if ($block !== 1) {
			$block = 0;
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Vendors WHERE block = ? ' . $search . ';');
		$sth->execute(array($block));

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
			'status' => 'success',
			'sql' => $result
		];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем поставщика
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_vendor':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Vendors WHERE id = ?');
		$sth->execute(array($id));	 

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление поставщика
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_vendor':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$company = $_POST['company'];
		$city = $_POST['city'];
		$address = $_POST['address'];
		$people = $_POST['people'];
		$people_position = $_POST['people_position'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$inn = $_POST['inn'];
		$ogrn = $_POST['ogrn'];
		$bank_name = $_POST['bank_name'];
		$bank_account = $_POST['bank_account'];
		$comment = $_POST['comment'];
		
		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Vendors SET company=:company, city=:city, address=:address, people=:people, people_position=:people_position, phone=:phone, email=:email, inn=:inn, ogrn=:ogrn, bank_name=:bank_name, bank_account=:bank_account, comment=:comment WHERE id=:id;');
		$stmt->execute(array(':company'=>$company, ':city'=>$city, ':address'=>$address, ':people'=>$people, ':people_position'=>$people_position, ':phone'=>$phone, ':email'=>$email, ':inn'=>$inn, ':ogrn'=>$ogrn, ':bank_name'=>$bank_name, ':bank_account'=>$bank_account, ':comment'=>$comment, ':id'=>$id));
	
				
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Блокировка поставщика
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'block_vendor':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$block = (int) $_POST['block'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на блок
		if ($block !== 1) {
			$block = 0;
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Vendors SET block=:block WHERE id=:id;');
		$stmt->execute(array(':block'=>$block, ':id'=>$id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Добавление поставщика
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_vendor':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$date_register = date("Y-m-d H:i:s");
		$id_user = (int) $_POST['id_user'];
		$company = $_POST['company'];
		$city = $_POST['city'];
		$address = $_POST['address'];
		$people = $_POST['people'];
		$people_position = $_POST['people_position'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$inn = $_POST['inn'];
		$ogrn = $_POST['ogrn'];
		$bank_name = $_POST['bank_name'];
		$bank_account = $_POST['bank_account'];
		$comment = $_POST['comment'];

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Vendors (id_user, company, city, address, people, people_position, phone, email, inn, ogrn, bank_name, bank_account, comment, date_register) VALUES (:id_user, :company, :city, :address, :people, :people_position, :phone, :email, :inn, :ogrn, :bank_name, :bank_account, :comment, :date_register);');
		$stmt->execute(array(':id_user'=>$id_user, ':company'=>$company, ':city'=>$city, ':address'=>$address, ':people'=>$people, ':people_position'=>$people_position, ':phone'=>$phone, ':email'=>$email, ':inn'=>$inn, ':ogrn'=>$ogrn, ':bank_name'=>$bank_name, ':bank_account'=>$bank_account, ':comment'=>$comment, ':date_register'=>$date_register));
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка категорий продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_category_items':


	// Проверяем данные на соответствие
	try {

		// Подготавливаем запрос в базу данных
		$query = $dbh->query('SELECT * FROM Category_items;'); 
		
		//Формируем массив разделов, ключом будет id родительской категории
		$result = $query->fetchAll(PDO::FETCH_ASSOC);

		//В Цикле формируем многомерный массив - дерево каталогов
		function buildTreeArray($arItems, $section_id = 'p_id', $element_id = 'id') {
			$childs = array();
			if(!is_array($arItems) || empty($arItems)) {
				return array();
			}
			foreach($arItems as &$item) {
				if(!$item[$section_id]) {
					$item[$section_id] = 0;
				}
				$childs[$item[$section_id]][] = &$item;
			}
			unset($item);
			foreach($arItems as &$item) {
				if (isset($childs[$item[$element_id]])) {
					$item['childs'] = $childs[$item[$element_id]];
				}
			}
			return $childs[0];
		}
		
		// Выводим сообщение
		$message = [
					'status' => 'success',
					'sql' => buildTreeArray($result)
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Добавление категории продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_edit_category_item':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$name = $_POST['name'];
		$p_id = (int) $_POST['p_id'];
		
		// Если родительская категория пустая, значит создаем в корне
		if (empty($p_id)) {
			$p_id = null;
		}

		// Подготавливаем запрос в базу данных	
		$stmt = $dbh->prepare('INSERT INTO Category_items (p_id, name) VALUES (?, ?)');
		$stmt->execute(array($p_id, $name));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Удаляем категорию
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'delete_category':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare("SELECT COUNT(id) AS count FROM Category_items WHERE p_id = ?;");
		$sth->execute(array($id));
					
		// Обработка полученных данных
		$result = $sth->fetchAll();
		if ($result[0]['count'] == 0) {
			
			// Подготавливаем запрос в базу данных
			$stmt = $dbh->prepare('DELETE FROM Category_items WHERE id=:id;');
			$stmt->execute(array(':id'=>$id)); 

			// Выводим сообщение
			$message = ['status' => 'success'];
			echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
			
		} else {
			throw new Exception('В данной категории существуют другие категории');
		}

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Перемещаем категорию
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'move_category':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$category_id = (int) $_POST['category_id'];
		$category_select = (int) $_POST['category_select'];
		
		// Проверка на id
		if (empty($category_id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id
		if (empty($category_select)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Category_items SET p_id=:p_id WHERE id=:id;');
		$stmt->execute(array(':p_id'=>$category_select, ':id'=>$category_id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Переименовываем категорию
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'rename_category':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$category_id = (int) $_POST['category_id'];
		$name = $_POST['name'];
		
		// Проверка на id
		if (empty($category_id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id
		if (empty($name)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Category_items SET name=:name WHERE id=:id;');
		$stmt->execute(array(':name'=>$name, ':id'=>$category_id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_products':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$category = (int) $_POST['category'];
		$vendor = (int) $_POST['vendor'];
		$search = $_POST['search'];
		$archive = (int) $_POST['archive'];

		// Проверяем на переданный параметр id категории
		if (empty($category)) {
			$category = ' AND category is NULL';
		} else {
			$category = ' AND category = ' . $category;
		}
		
		// Проверяем на переданный параметр id поставщика
		if (!empty($vendor)) {
			$vendor = ' AND id_vendor = "' . $vendor . '"';
		} else {
			$vendor = '';
		}

		// Проверяем на переданный параметр поиска
		if(!empty($search)) {
			$str = $search;
			$search = ' AND (P.id LIKE "%' . $str . '%" OR vendor_code LIKE "%' . $str . '%" OR name LIKE "%' . $str . '%")';
		} else {
			$search = "";
		}

		// Проверяем на переданный параметр архивные
		if ($archive !== 1) {
			$archive = 0;
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT *,
								   (price * (100 + percent) / 100) AS price_base
							  FROM Products AS P
							 WHERE archive = ? ' . $category . $search . $vendor . ' ;');
		$sth->execute(array($archive));

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем продукцию
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_product':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT P.*,
								   V.company
							  FROM Products AS P
								   INNER JOIN
								   Vendors AS V ON V.id = P.id_vendor
							 WHERE P.id = ?');
		$sth->execute(array($id));

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_product':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$id_vendor = (int) $_POST['id_vendor'];
		$vendor_code = $_POST['vendor_code'];
		$name = $_POST['name'];
		$info = $_POST['info'];
		$in_the_package = (int) $_POST['in_the_package'];
		$price = $_POST['price'];
		$percent = (int) $_POST['percent'];
		$count = (int) $_POST['count'];
		$category = (int) $_POST['category'];
		
		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Products SET id_vendor=:id_vendor, vendor_code=:vendor_code, name=:name, info=:info, in_the_package=:in_the_package, price=:price, percent=:percent, count=:count, category=:category WHERE id=:id;');
		$stmt->execute(array(':id'=>$id, ':id_vendor'=>$id_vendor, ':vendor_code'=>$vendor_code, ':name'=>$name, ':info'=>$info, ':in_the_package'=>$in_the_package, ':price'=>$price, ':percent'=>$percent, ':count'=>$count, ':category'=>$category));
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Блокировка продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'archive_product':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$archive = (int) $_POST['archive'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на блок
		if ($archive !== 1) {
			$archive = 0;
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Products SET archive=:archive WHERE id=:id;');
		$stmt->execute(array(':archive'=>$archive, ':id'=>$id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Добавление продукции
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_product':


	// Проверяем данные на соответствие
	try {
	
		// Устанавливаем значения
		$date_added = date("Y-m-d H:i:s");
		$id_vendor = (int) $_POST['id_vendor'];
		$vendor_code = $_POST['vendor_code'];
		$name = $_POST['name'];
		$info = $_POST['info'];
		$in_the_package = (int) $_POST['in_the_package'];
		$price = $_POST['price'];
		$percent = (int) $_POST['percent'];
		$count = (int) $_POST['count'];
		$category = (int) $_POST['category'];

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Products (id_vendor, vendor_code, name, info, in_the_package, price, percent, count, category, date_added) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
		$stmt->execute(array($id_vendor, $vendor_code, $name, $info, $in_the_package, $price, $percent, $count, $category, $date_added));
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}

	
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка покупателей
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_clients':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$search = $_POST['search'];
		$block = (int) $_POST['block'];

		// Если поиск
		if (!empty($search)) {
			$str = $search;
			$search = ' AND (company LIKE "%' . $str . '%" OR phone LIKE "%' . $str . '%" OR inn LIKE "%' . $str . '%")';
		} else {
			$search = '';
		}

		// Если блокированные
		if ($block !== 1) {
			$block = 0;
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Clients WHERE block = ? ' . $search . ';');
		$sth->execute(array($block));	 

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем покупателя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_client':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT * FROM Clients WHERE id = ?');
		$sth->execute(array($id)); 

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление покупателя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_client':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$company = $_POST['company'];
		$city = $_POST['city'];
		$address = $_POST['address'];
		$people = $_POST['people'];
		$people_position = $_POST['people_position'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$discount = (int) $_POST['discount'];
		$inn = $_POST['inn'];
		$ogrn = $_POST['ogrn'];
		$bank_name = $_POST['bank_name'];
		$bank_account = $_POST['bank_account'];
		$comment = $_POST['comment'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Clients SET company=:company, city=:city, address=:address, people=:people, people_position=:people_position, phone=:phone, email=:email, discount=:discount, inn=:inn, ogrn=:ogrn, bank_name=:bank_name, bank_account=:bank_account, comment=:comment WHERE id=:id;');
		$stmt->execute(array(':company'=>$company, ':city'=>$city, ':address'=>$address, ':people'=>$people, ':people_position'=>$people_position, ':phone'=>$phone, ':email'=>$email, ':discount'=>$discount, ':inn'=>$inn, ':ogrn'=>$ogrn, ':bank_name'=>$bank_name, ':bank_account'=>$bank_account, ':comment'=>$comment, ':id'=>$id));
			
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Если выбрана функция блокировки поставщика
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'block_client':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$block = (int) $_POST['block'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}
		
		// Проверка на блок
		if ($block !== 1) {
			$block = 0;
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Clients SET block=:block WHERE id=:id;');
		$stmt->execute(array(':block'=>$block, ':id'=>$id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Добавление покупателя
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_client':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id_user = (int) $_POST['id_user'];
		$company = $_POST['company'];
		$city = $_POST['city'];
		$address = $_POST['address'];
		$people = $_POST['people'];
		$people_position = $_POST['people_position'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$discount = (int) $_POST['discount'];
		$inn = $_POST['inn'];
		$ogrn = $_POST['ogrn'];
		$bank_name = $_POST['bank_name'];
		$bank_account = $_POST['bank_account'];
		$date_register = date("Y-m-d H:i:s");

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Clients (id_user, company, city, address, people, people_position, phone, email, discount, inn, ogrn, bank_name, bank_account, date_register) VALUES (:id_user, :company, :city, :address, :people, :people_position, :phone, :email, :discount, :inn, :ogrn, :bank_name, :bank_account, :date_register);');
		$stmt->execute(array(':id_user'=>$id_user, ':company'=>$company, ':city'=>$city, ':address'=>$address, ':people'=>$people, ':people_position'=>$people_position, ':phone'=>$phone, ':email'=>$email, ':discount'=>$discount, ':inn'=>$inn, ':ogrn'=>$ogrn, ':bank_name'=>$bank_name, ':bank_account'=>$bank_account, ':date_register'=>$date_register));
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка документов
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_documents':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$client = (int) $_POST['client'];

		// Проверка на дату
		if (empty($_POST['start_date'])) {
			throw new Exception('Не выбрана стартовая дата');
		}

		// Проверка на дату
		if (empty($_POST['end_date'])) {
			throw new Exception('Не выбрана конечная дата');
		}

		// Проверка на id покупателя
		if (!empty($client)) {
			$client = ' AND id_client = "' . $client . '" ';
		} else {
			$client = '';
		}
		
		// Устанавливаем значения
		$start_date = date("Y-m-d 00:00:00", strtotime($_POST['start_date']));
		$end_date = date("Y-m-d 23:59:59", strtotime($_POST['end_date']));

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT D.*,
								   D.id AS code_document,
								   SUM( ( (S.price - (S.price * S.discount) / 100) * S.count) ) AS document_summ,
								   SUM( S.price - (S.price - (S.price * (P.percent - S.discount) / 100) * S.count ) ) AS document_profit,
								   (
									   SELECT SUM(summ)
										 FROM Cash
										WHERE id_document = D.id
								   )
								   AS summ_paid_document,
								   Count(S.id) AS count_positions,
								   SUM(S.count) AS count_products,
								   U.first_name,
								   U.last_name,
								   C.company,
								   C.city
							  FROM Documents AS D
								   LEFT JOIN
								   Sales AS S ON D.id = S.id_document
								   LEFT JOIN
								   Products AS P ON S.id_product = P.id
								   LEFT JOIN
								   Users AS U ON D.id_user = U.id
								   LEFT JOIN
								   Clients AS C ON D.id_client = C.id
								   WHERE D.date_create BETWEEN ? AND ? '.$client.'
							 GROUP BY D.id
							 ORDER BY D.date_create ASC;');
		$sth->execute(array($start_date, $end_date));	 

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Новый документ
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_document':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id_user = (int) $_POST['id_user'];
		$id_client = (int) $_POST['id_client'];
		$date_create = $_POST['date_create'];
		$date_delivery = $_POST['date_delivery'];
		$uuid = gen_uuid();

		// Проверка на id user
		if (empty($id_user)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id client
		if (empty($id_client)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на дату
		if (empty($date_create)) {
			throw new Exception('Не выбрана дата');
		}

		// Проверка на дату
		if (empty($date_delivery)) {
			throw new Exception('Не выбрана дата');
		}		

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Documents (uuid, id_user, id_client, date_create, date_delivery, uploaded) VALUES (?, ?, ?, ?, ?, ?)');
		$stmt->execute(array($uuid, $id_user, $id_client, $date_create, $date_delivery, 0));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем документ
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_document':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];
	
		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT D.*,
								   U.first_name,
								   U.last_name,
								   C.company,
								   C.people,
								   C.people_position,
								   C.phone,
								   C.city,
								   C.address,
								   C.email,
								   C.discount
							  FROM Documents AS D
								   INNER JOIN
								   Users AS U ON D.id_user = U.id
								   INNER JOIN
								   Clients AS C ON D.id_client = C.id
							 WHERE D.id = ?;');
		$sth->execute(array($id));

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление документа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_document':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$id_client = (int) $_POST['id_client'];
		$comment = $_POST['comment'];
		$date_delivery = $_POST['date_delivery'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id покупателя
		if (empty($id_client)) {
			throw new Exception('Не выбран покупатель');
		}

		// Проверка на comment дату доставки
		if (empty($date_delivery)) {
			throw new Exception('Выберите дату доставки');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Documents SET id_client=?, comment=?, date_edited=?, date_delivery=?, uploaded=? WHERE id=?;');
		$stmt->execute(array($id_client, $comment, $date_edited, $date_delivery, 0, $id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Проведение документа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'approve_document':


	// Проверяем данные на соответствие
	try {

	
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$debit_bal = $_POST['debit'];
	
		// Проверка на id покупателя
		if (empty($debit_bal)) {
			throw new Exception('Продукция в документе отсутствует.');
		}
		
		// Подготавливаем запрос в базу данных		
		// Прогоняем полученный массив продукции и списываем остатки на складе
		foreach ($debit_bal as $item) {
			$stmt = $dbh->prepare('UPDATE Products
									   SET count = (
													   SELECT count
														 FROM Products
														WHERE id = ?
												   ) - ?
									 WHERE id = ?;');
			$stmt->execute(array($item['id_product'], $item['count'], $item['id_product']));
		}
		
		// Помечеам документ как проведенный
		$stmt = $dbh->prepare('UPDATE Documents SET uploaded=1 WHERE id=?;');
		$stmt->execute(array($id)); 
		
		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление статуса документа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_delivery_documents':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$delivery = (int) $_POST['delivery'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на количество
		if (empty($delivery)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Documents SET delivery=? WHERE id=?;');
		$stmt->execute(array($delivery, $id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Удаление документа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'delete_document':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных		
		// Проверяем документ на проведенность,
		// Если он проведен, восстанавливаем остатки продукции
		$sth = $dbh->prepare('SELECT uploaded FROM Documents WHERE id = ?;');
		$sth->execute(array($id));
		$result = $sth->fetchAll();
		
		if ($result[0]['uploaded'] == 1) {
			
			// Получаем массив продукции в документе
			$sth = $dbh->prepare('SELECT id_product,
										   count
									  FROM Sales
									 WHERE id_document = ?');
			$sth->execute(array($id));
			$debit_bal = $sth->fetchAll();
			
			// Прогоняем полученный массив продукции и пополняем остатки на складе
			foreach ($debit_bal as $item) {
				$stmt = $dbh->prepare('UPDATE Products
										   SET count = (
														   SELECT count
															 FROM Products
															WHERE id = ?
													   ) + ?
										 WHERE id = ?;');
				$stmt->execute(array($item['id_product'], $item['count'], $item['id_product']));
			}
			
		}
		
		// Удаляем документ и данные связанные с ним
		$stmt = $dbh->prepare('DELETE FROM Documents WHERE id=?;');
		$stmt->execute(array($id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загружаем продукцию в документе
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_products_documents':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT S.*,
								   ( (S.price - (S.price * S.discount) / 100) * S.count) AS product_summ,
								   P.id AS code,
								   P.vendor_code,
								   P.name,
								   P.in_the_package
							  FROM Sales AS S
								   INNER JOIN
								   Products AS P ON P.id = S.id_product
							 WHERE id_document = ?;');
		$sth->execute(array($id));

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Добавление продукции в документ
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_products_document':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id_user = (int) $_POST['id_user'];
		$id_document = (int) $_POST['id_document'];
		$id_product = (int) $_POST['id_product'];
		$price = $_POST['price'];
		$count = (int) $_POST['count'];
		$discount = (int) $_POST['discount'];

		// Проверка на id пользователя
		if (empty($id_user)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id документа
		if (empty($id_document)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id продукции
		if (empty($id_product)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на цену
		if (empty($price)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на id количество
		if (empty($count)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Sales (id_user, id_document, id_product, price, count, discount) VALUES (?, ?, ?, ?, ?, ?);');
		$stmt->execute(array($id_user, $id_document, $id_product, $price, $count, $discount)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Удаление продукции в документе
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'delete_products_documents':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('DELETE FROM Sales WHERE id=?;');
		$stmt->execute(array($id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление продукции в документе
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_products_documents':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$count = (int) $_POST['count'];
		$discount = (int) $_POST['discount'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Проверка на количество
		if (empty($count)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Sales SET count=?, discount=? WHERE id=?;');
		$stmt->execute(array($count, $discount, $id));

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка денежных средств
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_cash':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$start_date = $_POST['start_date'];
		$end_date = $_POST['end_date'];
		$client = (int) $_POST['client'];
		$grouping = (int) $_POST['grouping'];
	
		// Проверка на дату
		if (empty($start_date)) {
			throw new Exception('Не выбрана стартовая дата');
		}

		// Проверка на дату
		if (empty($end_date)) {
			throw new Exception('Не выбрана конечная дата');
		}

		// Проверка на id покупателя
		if (!empty($client)) {
			$client = ' AND C.id = "'.$client.'"';
		} else {
			$client = '';
		}

		// Проверка на группировку поступлений
		if ($grouping == 1) {
			$sql_select = ' (
					   SELECT sum(summ)
						 FROM Cash
						WHERE id_document = CS.id_document AND date_paid BETWEEN ? AND ?
					   )
					   AS summ_group,';
			$group = 'id_document';
		} else {
			$sql_select = '';
			$group = 'id';
		}
		
		// Устанавливаем значения
		$start_date = date("Y-m-d 00:00:00", strtotime($start_date));
		$end_date = date("Y-m-d 23:59:59", strtotime($end_date));

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT CS.id,
									   CS.summ,
									   '.$sql_select.'
									   CS.date_paid,
									   D.date_create AS date_document,
									   D.id AS id_document,
									   U.first_name,
									   U.last_name,
									   C.company AS client,
									   C.city AS client_city
								  FROM Cash AS CS
									   INNER JOIN
									   Users AS U ON CS.id_user = U.id
									   INNER JOIN
									   Clients AS C ON D.id_client = C.id
									   INNER JOIN
									   Documents AS D ON D.id = CS.id_document
								 WHERE CS.date_paid BETWEEN ? AND ? '.$client.'
								 GROUP BY CS.'.$group.'
								 ORDER BY CS.date_paid ASC;');

		// Проверка на группировку поступлений
		if ($grouping == 1) {
			$sth->execute(array($start_date, $end_date, $start_date, $end_date));
		} else {
			$sth->execute(array($start_date, $end_date));
		} 

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Внесение платежа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'add_pay':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$date_paid = date("Y-m-d H:i:s");
		$id_user = (int) $_POST['id_user'];
		$id_document = (int) $_POST['id_document'];
		$summ = $_POST['summ'];
		$comment = $_POST['comment'];

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('INSERT INTO Cash (id_user, id_document, summ, comment, date_paid) VALUES (:id_user, :id_document, :summ, :comment, :date_paid);');
		$stmt->execute(array(':id_user'=>$id_user, ':id_document'=>$id_document, ':summ'=>$summ, ':comment'=>$comment, ':date_paid'=>$date_paid)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Открываем платеж
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'open_pay':


	// Проверяем данные на соответствие
	try {

		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT CS.*,
								   C.company,
								   C.city,
								   D.id AS document_num
							  FROM Cash AS CS
								   INNER JOIN
								   Documents AS D ON D.id = CS.id_document
								   INNER JOIN
								   Clients AS C ON C.id = D.id_client
							 WHERE CS.id = ?');
		$sth->execute(array($id)); 

		// Выводим сообщение
		$result = $sth->fetchAll();
		
		// Проверяем количество строк ответа
		if (count($result) !== 1) {
			throw new Exception('Ошибка обработки запроса');
		}
		
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Обновление платежа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'update_pay':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];
		$summ = $_POST['summ'];
		$comment = $_POST['comment'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('UPDATE Cash SET summ=:summ, comment=:comment WHERE id=:id;');
		$stmt->execute(array(':summ'=>$_POST['summ'], ':comment'=>$_POST['comment'], ':id'=>$id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Удаление платежа
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'delete_pay':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$id = (int) $_POST['id'];

		// Проверка на id
		if (empty($id)) {
			throw new Exception('Ошибка передачи данных');
		}

		// Подготавливаем запрос в базу данных
		$stmt = $dbh->prepare('DELETE FROM Cash WHERE id=:id;');
		$stmt->execute(array(':id'=>$id)); 

		// Выводим сообщение
		$message = ['status' => 'success'];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Функция загрузки для заказа поставщикам
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'ordering_provider':


	// Проверяем данные на соответствие
	try {
		
		// Проверка на дату
		if (empty($_POST['start_date'])) {
			throw new Exception('Не выбрана стартовая дата');
		}

		// Проверка на дату
		if (empty($_POST['end_date'])) {
			throw new Exception('Не выбрана конечная дата');
		}
		
		// Устанавливаем значения
		$vendor_id = (int) $_POST["vendor_id"];
		$start_date = date("Y-m-d 00:00:00", strtotime($_POST['start_date']));
		$end_date = date("Y-m-d 23:59:59", strtotime($_POST['end_date']));

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT S.id_product,
								   P.price,
								   P.vendor_code,
								   P.name,
								   SUM(S.count) AS all_count,
								   (P.price * SUM(S.count)) AS summ
							  FROM Sales AS S
								   INNER JOIN
								   Products AS P ON P.id = S.id_product
								   INNER JOIN
								   Documents AS D ON D.id = S.id_document
							 WHERE P.id_vendor = ? AND 
								   D.date_create BETWEEN ? AND ?
							 GROUP BY P.id
							 ORDER BY P.vendor_code ASC;');
		$sth->execute(array($vendor_id, $start_date, $end_date));	 

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
	

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Загрузка отчетов
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_reports':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$type_report = (int) $_POST['type_report'];
		$vendor_id = (int) $_POST['vendor_id'];
		$client_id = (int) $_POST['client_id'];
		$user_id = (int) $_POST['user_id'];
		
		// Проверка на тип отчета
		if (empty($type_report)) {
			$type_report = "GROUP BY P.id";
		} else {
			
			if ($type_report == 1) {
				$type_report = "GROUP BY C.id";
			}
			if ($type_report == 2) {
				$type_report = "GROUP BY U.id";
			}
			
		}
		
		// Проверка на дату
		if (empty($_POST['start_date'])) {
			throw new Exception('Не выбрана стартовая дата');
		}

		// Проверка на дату
		if (empty($_POST['end_date'])) {
			throw new Exception('Не выбрана конечная дата');
		}

		// Проверяем на переданный параметр uid поставщика
		if (!empty($vendor_id)) {
			$vendor = ' AND V.id = "' . $vendor_id . '"';
		} else {
			$vendor = '';
		}

		// Проверяем на переданный параметр покупателя
		if(!empty($client_id)) {
			$client = ' AND C.id = "' . $client_id . '"';
		} else {
			$client = "";
		}

		// Проверяем на переданный параметр пользователя
		if (!empty($user_id)) {
			$user = ' AND S.id_user = "' . $user_id . '"';
		} else {
			$user = "";
		}
		
		// Устанавливаем значения
		$start_date = date("Y-m-d 00:00:00", strtotime($_POST['start_date']));
		$end_date = date("Y-m-d 23:59:59", strtotime($_POST['end_date']));

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT S.id_user,
							   S.id_product,
							   S.price,
							   S.count,
							   S.discount,
							   D.date_create AS date_document,
							   SUM( (S.price - (S.price * S.discount) / 100) * S.count) AS product_summ,
							   SUM(S.count) AS all_count_products,
							   P.id AS code,
							   P.name,
							   P.vendor_code,
							   V.company AS Vendor_company,
							   C.company AS Client_company,
							   U.first_name,
							   U.last_name
						  FROM Sales AS S
							   INNER JOIN
							   Products AS P ON P.id = S.id_product
							   INNER JOIN
							   Documents AS D ON D.id = S.id_document
							   INNER JOIN
							   Vendors AS V ON V.id = P.id_vendor
							   INNER JOIN
							   Clients AS C ON C.id = D.id_client
							   INNER JOIN
							   Users AS U ON U.id = S.id_user
						 WHERE D.date_create BETWEEN ? AND ? '.$vendor . $client . $user.'
						 '.$type_report.'
						 ORDER BY product_summ DESC;');
		$sth->execute(array($start_date, $end_date));

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
// Функция загрузки для заказа поставщикам
//---------------------------------------------------------------------------------------------------------------------------------------------------------------


break;
case 'loading_statistics':


	// Проверяем данные на соответствие
	try {
		
		// Устанавливаем значения
		$start_date_month = date("Y-m-01 00:00:00");
		$end_date_month = date("Y-m-d 23:59:59");
		
		// Устанавливаем значения
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");

		// Подготавливаем запрос в базу данных
		$sth = $dbh->prepare('SELECT (
									   SELECT SUM(P.count * P.price) 
										 FROM Products AS P
								   )
								   AS summ_sklad,
								   (
									   SELECT SUM( (S1.price - (S1.price * S1.discount) / 100) * S1.count) 
										 FROM Sales AS S1
											  INNER JOIN
											  Documents AS D ON D.id = S1.id_document
										WHERE D.uploaded = 1 AND D.date_create BETWEEN ? AND ?
								   )
								   AS sales_to_day,
								   SUM( (S.price - (S.price * S.discount) / 100) * S.count) AS sales_to_month,
								   SUM( S.price - (S.price - (S.price * (P.percent - S.discount) / 100) * S.count ) ) AS month_profit,
								   (
									   SELECT COUNT(id)
										 FROM Documents
										WHERE uploaded = 1 AND date_create BETWEEN ? AND ?
								   )
								   AS akb_client,
								   (
									   SELECT SUM(C.summ) 
										 FROM Cash AS C
										WHERE C.date_paid BETWEEN ? AND ?
								   )
								   AS summ_cash_to_day
							  FROM Sales AS S
								   INNER JOIN
								   Documents AS D ON D.id = S.id_document
								   INNER JOIN
								   Products AS P ON P.id = S.id_product
							 WHERE D.uploaded = 1 AND D.date_create BETWEEN ? AND ?;');
		$sth->execute(array($start_date, $end_date, $start_date_month, $end_date_month, $start_date, $end_date, $start_date_month, $end_date_month));	 

		// Выводим сообщение
		$result = $sth->fetchAll();
		$message = [
					'status' => 'success',
					'sql' => $result
				];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	} catch(Exception $e) {

		// Выводим сообщение
		$message = ['status' => $e->getMessage()];
		echo json_encode($message, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

	}
		

default:
break;


}


	// Закрываем соединение с базой
	$dbh = null;
	

?>