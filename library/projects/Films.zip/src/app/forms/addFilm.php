<?php
namespace app\forms;

use std, gui, framework, app;


class addFilm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$id = $this->id->value;
$name = $this->NameFilm->text;
$rating = $this->rating->value;
$image = $this->image->text;
$url = $this->url->text;

// SQL-запрос для вставки данных в таблицу movies
$insertQuery = $this->database->query("INSERT INTO movies (id, name, rating, image, url) VALUES ($id, '$name', $rating, '$image', '$url')");

// Выполнение запроса
$insertQuery->update();
$this->form('MainForm')->flowPane->children->clear();
var_dump("Успешно");
    }

}
