<?php
namespace app\modules;

use php\sql\SqlException;
use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event database.open 
     */
    function doDatabaseOpen(ScriptEvent $e = null)
    {    
            $tableName = "movies";
            $database = $this->database;
    try {
        // Проверка существования таблицы
        
        $result = $database->query("SHOW TABLES LIKE '{$tableName}'")->fetch();
        
        if (empty($result)) {
            // Если таблица не существует, создаем ее
            $a = $database->query("
                CREATE TABLE {$tableName} (
                    id INT PRIMARY KEY,
                    name VARCHAR(255),
                    rating DECIMAL(3, 1),
                    image VARCHAR(255),
                    url VARCHAR(255)
                )
            ");
            $a->update(); // обновляем 
            var_dump("Таблица '{$tableName}' создана успешно.");
            
        } else {
            // Таблица уже существует
            var_dump("Таблица '{$tableName}' уже существует.");
        }
    } catch (SqlException $e) {
        // Обработка ошибки, например, вывод сообщения или выброс исключения
        var_dump("Ошибка при проверке/создании таблицы: " . $e->getMessage());
    }
    }
function loading(){

$conn = $this->database;

foreach ($conn->query('SELECT * FROM movies') as $item) {
    $item = $item->toArray();
    var_dump($item);
        $NameFilm = $item['name'];
        $Rating = $item['rating'];
        $FilmImage = $item['image'];
        
        $url = $item['url'];
        
        $panel = new UXPanel(); //создания панели
        $panel->backgroundColor = 'transparent';
        $panel->size = [210 ,346];
        $panel->minSizeSize = [210 , 346];
        $panel->maxSize = [210 , 346];
        $panel->borderColor = 'transparent';
        $img = UXImage::ofUrl($FilmImage);
        $imageView = new UXImageView($img);// создания картинки
        $imageView->height = 288;
        $imageView->width = 208;
        $LabelRating = new UXLabel();// создания текста рейтинга.
        $LabelRating->text = $Rating;
        $LabelRating->style = '-fx-background-color:#669966;-fx-background-radius: 5;  -fx-font-family: Arial Black;-fx-font-size: 12.0;-fx-font-weight: bold;';
        $LabelRating->position = [24,0];
        $LabelRating->alignment = 'CENTER';
        $LabelRating->size = [32,16];
        $LabelName = new UXLabel();// создания текста фильма
        $LabelName->position = [0, 288];
        $LabelName->size = [208 , 17];
        $LabelName->text = $NameFilm;
        $LabelName->style = '-fx-background-color:#ffffff;-fx-font-family: Arial Black;-fx-font-size: 12.0;-fx-font-weight: bold;-fx-font-style: normal;-fx-text-fill: #000000;';
        $button = new UXFlatButton();// создания кнопки
        $button->position = [0,304];
        $button->size = [208 , 40];
        $button->color = '#ffffff';
        $button->text = '         Посмотреть =>';
        $button->alignment = 'BASELINE_LEFT';
        $button->cursor = 'HAND';
        $button->hoverColor = '#b3b3b3';
        $button->on('click', function(UXEvent $e) use ($url) {// обработка нажатия на кнопку
    
    browse($url);// открываем при нажатии url сайта
});
        
        $panel->add($LabelName);
        $panel->add($button);
        $panel->add($imageView);
        $panel->add($LabelRating);
        $this->flowPane->add($panel);
}
}
}
