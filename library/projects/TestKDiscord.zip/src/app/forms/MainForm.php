<?php
namespace app\forms;

use discord\rpc\UserObject;
use discord\rpc\__KDiscord;
use discord\rpc\KDiscord;
use discord\rpc\KDiscordTypes;
use gui\Ext4JphpWindows;
use httpclient;
use Exception;
use php\desktop\Runtime;
use std, gui, framework, app;


class MainForm extends AbstractForm
{
    private $ipc;
    
    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
        try {
            if (!($this->ipc instanceof KDiscord)) {
                $this->ipc = $ipc = new KDiscord("817484458025418764");
            } else {
                $ipc = $this->ipc;
                $this->ipc->connect();
            }
            
        } catch (Exception $e) {}
        
        // событие когда произойдет подключение к серверам дискорда
        $ipc->on(KDiscordTypes::EVENT_READY, function (UserObject $obj) {
            $this->label->text = $obj->getUsername();
           
            $http = new HttpClient();
            
            $url = 'https://cdn.discordapp.com/avatars/' . $obj->getId() . '/' . $obj->getAvatar() . '.png';
            $http->getAsync($url, [], function (HttpResponse $response) {
                $mem = new MemoryStream();
                $mem->write($response->body(), $response->contentLength());
                $mem->seek(0);
                
                uiLater(function () use ($mem) {
                    $this->image->image = new UXImage($mem);
                });
            });
        });
        
        // если пользователь чтото обновит в профиле
        $ipc->on(KDiscordTypes::EVENT_CURRENT_USER_UPDATE, function (UserObject $user) {
            var_dump($user->getUsername());
        });
        
        // если произойдет ошибка
        $ipc->on(KDiscordTypes::EVENT_ERROR, function ($message) {
            Logger::error($message);
        });
        
        $ipc->setState("_____ඞ");
        $ipc->setDetails("Test discord package");
        $ipc->setLargeImage("big", "amazing");
        $ipc->setSmallImage("small");
        
        $ipc->addButton("Download", "https://youtu.be/dQw4w9WgXcQ");
        $ipc->addButton("Здесь могла быть ваша реклама", "https://google.com/");
        
        $ipc->updateActivity();
        
        waitAsync(5000, function () use ($ipc) {
            $ipc->setState("___ඞ__");
            $ipc->removeButton(KDiscordTypes::X_BUTTON_FIRST);
            $ipc->updateActivity();
        });
        
        waitAsync(10000, function () use ($ipc) {
            $ipc->setState("ඞ_____");
            $ipc->setParty(str::hash("mygame"), 1, 5);
            $ipc->setSecrets(str::hash("mygame"), str::hash("mygame1"), str::hash("mygame2"));
            $ipc->updateActivity();
        });
        
        waitAsync(15000, function () use ($ipc) {
            $ipc->disconnect();
        });
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
        $ext = new Ext4JphpWindows();
        $ext->addBorder($this, 4.0, "#6680e6");
        $ext->addShadow($this);
        
    }

    /**
     * @event image.construct 
     */
    function doImageConstruct(UXEvent $e = null)
    {    
        $this->image->clip = new UXCircle();
        $this->image->clip->radius = $this->image->width / 2;
        $this->image->clip->strokeColor = 'red';
        $this->image->clip->x = 0;
        $this->image->clip->y = 0;
    }

    /**
     * @event circle.mouseEnter 
     */
    function doCircleMouseEnter(UXMouseEvent $e = null)
    {    
        $this->circle->strokeColor = '#ff9980';
    }

    /**
     * @event circle.mouseExit 
     */
    function doCircleMouseExit(UXMouseEvent $e = null)
    {    
        $this->circle->strokeColor = '#6680e6';
    }


}
