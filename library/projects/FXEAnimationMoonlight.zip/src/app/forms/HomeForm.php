<?php
namespace app\forms;

use Exception;
use std, gui, framework, app;
use php\framework\FXEAnimationMoonlight;

class HomeForm extends AbstractForm
{
public $FXEAnimationMoonlight;
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        $this->FXEAnimationMoonlight = new FXEAnimationMoonlight();
        // создаем объект класса.
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        if ($this->radioGroup->selectedIndex == 0){
            
            $Mode = 'Fast';
        }elseif($this->radioGroup->selectedIndex == 1) {
            $Mode = 'Medium';
        }elseif($this->radioGroup->selectedIndex == 2) {
            $Mode = 'Slow';
        }
        
        $FirstColor = $this->colorPicker->value->getWebValue();
        
        $SecondColor =  $this->colorPickerAlt->value->getWebValue();
        
        $Colors = [
        
        0=>$FirstColor,
        
        1 =>$SecondColor
        
        ];
            
        $this->FXEAnimationMoonlight->MoonlightAnimationStart('hbox','HomeForm' ,$Mode, $Colors);
        
        $e->sender->enabled = false;
        
    }

    /**
     * @event radioGroup.action 
     */
    function doRadioGroupAction(UXEvent $e = null)
    {    
        if ($this->radioGroup->selectedIndex == 0){
            $this->FXEAnimationMoonlight->Mode = 'Fast';
            
        }elseif($this->radioGroup->selectedIndex == 1) {
            $this->FXEAnimationMoonlight->Mode = 'Medium';
            
        }elseif($this->radioGroup->selectedIndex == 2) {
            $this->FXEAnimationMoonlight->Mode = 'Slow';
            
        }
        

    }

    /**
     * @event colorPicker.action 
     */
    function doColorPickerAction(UXEvent $e = null)
    {    
        $FirstColor = $this->colorPicker->value->getWebValue();
        
        $SecondColor =  $this->colorPickerAlt->value->getWebValue();
        
        $Colors = [
        
        0=>$FirstColor,
        
        1 =>$SecondColor
        
        ];
        
        $this->FXEAnimationMoonlight->Colors = $Colors;
            
    }

    /**
     * @event colorPickerAlt.action 
     */
    function doColorPickerAltAction(UXEvent $e = null)
    {    
        $FirstColor = $this->colorPicker->value->getWebValue();
        
        $SecondColor =  $this->colorPickerAlt->value->getWebValue();
        
        $Colors = [
        
        0=>$FirstColor,
        
        1=>$SecondColor
        
        ];
        
        $this->FXEAnimationMoonlight->Colors = $Colors;
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->FXEAnimationMoonlight->StopAnimationMoonlight();
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    

try {
 $this->FXEAnimationMoonlight->MoonlightAnimationStartCurrent();// стартуеем
} catch (Exception $e) {
    $this->toast($e->getMessage());

    }
}

}
