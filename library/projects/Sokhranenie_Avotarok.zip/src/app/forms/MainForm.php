<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
      
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $id = $this->editAlt->text;

        $query = $this->database->query("SELECT img FROM images WHERE id = $id");
        $result = $query->fetch();
        
        if ($result) {
            $imgbase64 = $result->get('img');
            var_dump($imgbase64);
            $imgdata = base64_decode($imgbase64);
            Stream::putContents('img.png', $imgdata);
            Element::loadContentAsync($this->image, 'img.png', function () use ($e, $event) {
            });
            
        } else {
            $this->toast("Запись с ID $id не найдена.");

            
        }
    }


}
