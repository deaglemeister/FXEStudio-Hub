<?php
namespace app\modules;


use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event construct 
     */
    function doConstruct(ScriptEvent $e = null)
    {    
$createTableQuery = $this->database->query("
    CREATE TABLE IF NOT EXISTS images (
        id INTEGER PRIMARY KEY,
        img LONGBLOB
    )
");

$createTableQuery->update();
}

    /**
     * @event fileChooser.action 
     */
    function doFileChooserAction(ScriptEvent $e = null)
    {    
        if ($this->label->text == null){
            $this->toast('Ошибка,файл не выбран');

            
        }
        else {
            if ($this->edit->text == null){
                $this->toast('Укажите id в поле ввода и попробуйте еще раз!');

            }
            else {
                $id = $this->edit->text;
                $img = file_get_contents($this->label->text);
                $imgbase64 = base64_encode($img);
                $query = $this->database->query("INSERT INTO images (id, img) VALUES ($id, '$imgbase64')");
                $query->update();
                $this->toast("Успешно! Используйте id  $id  ,чтобы найти нужное изображение");

            }
        }
    }

}
