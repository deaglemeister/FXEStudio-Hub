<?php
namespace app\forms;

use discord\rpc\User;
use discord\rpc\DiscordRPC;
use std, gui, framework, app;


class HomeForm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    

            $appId = $this->appid->text; // ID приложения что вы создали до этого
$discord = new DiscordRPC($appId);

// заголовок
$discord->setState($this->tittleDS->text);

// Подзагловок
$discord->setDetails($this->descDS->text);

// Иконка
$discord->setBigImage($this->IDimg->text);

// нужен чтобы отображалось сколько времени вы провели в приложении
$discord->setStartTimestamp((Time::now())->getTime());



$discord->updateState();

}





    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
    $this->toast("Начните с создания нового приложения для действия статуса вашей программы.");
    browse("https://discord.com/developers/applications");
    }

    /**
     * @event tittleDS.keyUp 
     */
    function doTittleDSKeyUp(UXKeyEvent $e = null)
    {    
        Element::setText($this->tittle, uiText($e->sender));
    }

    /**
     * @event descDS.keyUp 
     */
    function doDescDSKeyUp(UXKeyEvent $e = null)
    {    
        Element::setText($this->desc, uiText($e->sender));
    }

