<?php
namespace app\forms;

use std, gui, framework, app;


class changeValues extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        global $names_key;
        foreach ($names_key as $field) {
            $object = new UXLabel();
            $object->text = $field;
            $object->style = "-fx-font-family: Consolas;
            -fx-font-size: 16.0;
            -fx-font-weight: normal;
            -fx-font-style: normal;";
            $object->autosize = true;
            $this->dfahsuo->add($object);
            
            global $value_key;
            $object = new UXTextField();
            $object->size = [384, 24];
            $object->id = $field;
            $object->text = $value_key[$field];
            $this->jfdkas->add($object);
        }
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        $tree = $this->form("MainForm")->tree;
        $db = $tree->focusedItem->value;
        global $names_key;
        
        $this->database->query("use ".$tree->focusedItem->parent->value)->update();
        foreach ($names_key as $field) {
            $this->database->query("Update ".$db." SET ".$field." = '".$this->$field->text.
            "' where ".array_keys($this->form("MainForm")->table->selectedItem)[0].
            " = ".$this->form("MainForm")->table->selectedItem[array_keys($this->form("MainForm")->table->selectedItem)[0]])->update();
        }
        $this->hide();
    }

}
