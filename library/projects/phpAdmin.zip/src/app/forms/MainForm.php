<?php
namespace app\forms;

use php\gui\UXTabPaneWrapper;
use php\sql\SqlStatement;
use php\sql\SqlResult;
use std, gui, framework, app;


class MainForm extends AbstractForm
{

    public function addDBToTable(SqlResult $record) {
    
        $root = $this->tree->root;
        $db = new UXTreeItem($record->toArray()["Database"]);
        $root->children->add($db);
        $this->database->query("use ".$record->toArray()["Database"])->update();
        $quer = $this->database->query("show tables");
        
        foreach ($quer as $result) {
            $db->children->add(new UXTreeItem($result->toArray()["Tables_in_".$record->toArray()["Database"]]));
        }        
    }
    
    public function addDBSToTable(SqlStatement $records)
    {
        foreach ($records as $record) {
            $this->addDBToTable($record);
        }
    }

    public function addUserToTable(SqlResult $record)
    {
        $this->table->items->add($record->toArray());
    }
    
    /**
     * Добавляет сразу всех пользователей в таблицу.
     */
    public function addUsersToTable(SqlStatement $records)
    {
        foreach ($records as $record) {
            $this->addUserToTable($record);
        }
    }

    public function refreshTableMain(){
        $tree = $this->tree;
        if($tree->getTreeItemLevel($tree->focusedItem) == 2) {
            $this->table->columns->clear();
            $this->database->query("use ".$tree->focusedItem->parent->value)->update();
            $this->table->items->clear();
            $qer = $this->database->query("describe ".$tree->focusedItem->value);
            foreach ($qer as $result) {
                $columns = new UXTableColumn();
                $columns->id = $result->toArray()["Field"];
                $columns->text = $result->toArray()["Field"];
                $columns->minWidth = 10;
                $columns->maxWidth = 10000;
                $columns->width = 80;
                $this->table->columns->add($columns);
            }
            $qer = $this->database->query("select * from ".$tree->focusedItem->value);
            $this->addUsersToTable($qer);
        }
    }

    /**
     * @event tree.click-Left 
     */
    function doTreeClickLeft(UXMouseEvent $e = null)
    {    
           $this->refreshTableMain();
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $this->tree->root = new UXTreeItem("Базы данных"); 
        $root = $this->tree->root;
        $quer = $this->database->query("show databases");
        $this->addDBSToTable($quer);
    }

    /**
     * @event table.construct 
     */
    function doTableConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null)
    {    
            $this->refreshTableMain();
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {
        if($this->table->selectedItem){
            $tree = $this->tree;
            $name_key = array_keys($this->table->selectedItem)[0];
            $this->database->query("delete from ".$tree->focusedItem->value." where ".$name_key." = ".$this->table->selectedItem[$name_key])->update();
            $this->refreshTableMain();
        } else {
            alert("Не выбрана строка");
        }
    }

    /**
     * @event button6.click-Left 
     */
    function doButton6ClickLeft(UXMouseEvent $e = null)
    {
        $tree = $this->tree;
        if($tree->getTreeItemLevel($tree->focusedItem) == 2) {
            $this->database->query("delete from ".$tree->focusedItem->value)->update();
            $this->refreshTableMain();
        } else {
            alert("Не выбрана таблица");
        }
    }

    /**
     * @event button7.click-Left 
     */
    function doButton7ClickLeft(UXMouseEvent $e = null)
    {    
        $this->database->query($this->textArea->text)->update();
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {
        if($this->table->selectedItem) {
            global $names_key;
            $names_key = array_keys($this->table->selectedItem);
            global $value_key;
            $value_key = $this->table->selectedItem;
            $form = app()->getNewForm('changeValues');
            $form->showAndWait();
            $this->refreshTableMain();
        } else {
            alert("Строка не выбрана");
        }
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
       if($this->table->selectedItem) {
            global $names_key;
            $names_key = array_keys($this->table->selectedItem);
            $form = app()->getNewForm('newValue');
            $form->showAndWait();
            $this->refreshTableMain();
        } else {
            alert("Строка не выбрана");
        }
    }




}
