<?php
namespace app\forms;

use std, gui, framework, app;


class newValue extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {
        // Подготовка к запросу
        global $names_key;
        $tree = $this->form("MainForm")->tree;
        $db = $tree->focusedItem->value;
        foreach ($names_key as $field) $fieldss = $fieldss.", ".$field;
        $fields = substr($fieldss, 2);
        foreach ($names_key as $key) $values = $values."?,";
        $values = substr($values, 0, -1);
        $arr = [];
        $i = 0;
        foreach ($names_key as $key){
            $arr[$i] = $this->$key->text;
            $i++;
        }
        
        // Формируем запрос
        $this->database->query("use ".$tree->focusedItem->parent->value)->update();
        $this->database->query("INSERT INTO ".$db." (".$fields.") values(".$values.")", $arr)->update();
        $this->hide();
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
     global $names_key;
        foreach ($names_key as $field) {
            $object = new UXLabel();
            $object->text = $field;
            $object->style = "-fx-font-family: Consolas;
            -fx-font-size: 16.0;
            -fx-font-weight: normal;
            -fx-font-style: normal;";
            $object->autosize = true;
            $this->dfahsuo->add($object);
            
            $object = new UXTextField();
            $object->size = [384, 24];
            $object->id = $field;
            $this->jfdkas->add($object);
        }
    }

}
