<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{
    function UI_IMAGE_BORDER($image, $radius) {   
            $rect = new UXRectangle;
            $rect->width = $image->width;
            $rect->height = $image->height;
            $rect->arcWidth = $radius*2;
            $rect->arcHeight = $radius*2;
            $image->clip = $rect;
            $circledImage = $image->snapshot();
            $image->clip = NULL;
            $rect->free();
            $image->image = $circledImage;
            return $image;
        }
}