<?php
namespace app\forms;

use std, gui, framework, app;


class HomeForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
      $this->UI_IMAGE_BORDER($this->image, 6); // Задаём фотографии радиус в появление формы
      $this->UI_IMAGE_BORDER($this->imageAlt, 12); // Задаём фотографии радиус 12 в появдение формы
      $this->UI_IMAGE_BORDER($this->image3, 99); // Задаём фотографии радиус 99 в появление формы
      
      //Не забываем подлкючить функцию, она находится в MainModule
    }

}

