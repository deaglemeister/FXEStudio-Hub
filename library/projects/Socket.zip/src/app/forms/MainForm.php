<?php
namespace app\forms;

use php\io\IOException;
use php\io\Stream;
use php\io\FileStream;
use std, gui, framework, app;


class MainForm extends AbstractForm
{
    public $thread;
    
    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        try {
            $SocketClient = new Socket;
            $SocketClient->connect('192.168.1.179', '1054');
            
            if($this->fileChooser->execute()) {
                $fp = fopen($this->fileChooser->file, 'r');
                
                while(!feof($fp)) {
                    $data = fread($fp, 1024);
                    $SocketClient->getOutput()->write($data, strlen($data));
                }
                
                fclose($fp);
                $SocketClient->close();
            }
        }
        catch(SocketException $e) {
            $this->addLogs(
                $e->getMessage()
            );
        }
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        $this->socketStart();
    }

    function socketStart() {
        $this->thread = new Thread(function() {
            $SocketServer = new ServerSocket('1054');
            
            while($Accept = $SocketServer->accept()) {
                $fp = fopen('test.dat', 'w');
                
                while(true) {
                    $RequestData = $Accept->getInput()->read(1024);
                    
                    if($RequestData === false || strlen($RequestData) === 0) {
                        break;
                    }
                    
                    if($RequestData !== null) {
                        fwrite($fp, $RequestData, strlen($RequestData));
                    }
                }
                
                fclose($fp);
            }
        });
        
        $this->thread->start();
    }
    
    function addLogs($message) {
        return file_put_contents('logs.ini', $message . "\n", FILE_APPEND);
    }
}
