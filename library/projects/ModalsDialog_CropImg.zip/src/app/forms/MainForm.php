<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{
    
    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия окна кропа изображения
    #----------------------------------------------------------------------------------------------------------------------------------------------------
    
    function show_crop($file) {
    
        # Создаём панель выделения
        $crop_pane = new UXPane;
        $crop_pane->visible = false;
        $crop_pane->classes->add("crop-pane");
        
        # Загружаем изображение
        /** @var UXImageArea $img **/
        $img = $this->setImage($file, 16, 16, false);
        $img->classes->add('image');
        $img->stretch = 1;
        $img->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        
        # Панель для изображения
        $anchor = new UXAnchorPane;
        $anchor->classes->add("image-anchor");
        $anchor->add($img);
        $anchor->add($crop_pane);
        $anchor->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        
        # Верхняя панель
        $top_pane = new UXHBox;
        $top_pane->classes->add("top-pane");
        $label_top_pane = new UXLabel("Загрузка новой фотографии");
        $label_top_pane->classes->addAll(["font-bold", "font-h3"]);
        $top_pane->add($label_top_pane);
        
        $label_inf = new UXLabel("Друзьям будет проще узнать Вас, если Вы загрузите свою настоящую фотографию.");
        $label_inf->classes->addAll(["font-gray"]);
        
        $inf_pane = new UXVBox([$label_inf]);
        $inf_pane->classes->add("inf-pane");
        
        # Нижняя панель
        $bottom_pane = new UXHBox;
        $bottom_pane->classes->add("bottom-pane");
        
        $cancel_button = new UXButton("Закрыть");
        $cancel_button->classes->addAll(["button-cancel", "button-yellow"]);
        
        $save_button = new UXButton("Сохранить");
        $save_button->classes->addAll(["button-save", "button-accent"]);
        $save_button->on('click', function () use ($img, $anchor, $crop_pane, $bottom_pane, $cancel_button, $label_inf, $save_button) {
        
            # Получаем изображение
            $crop = $this->get_cropped_image();
            
            # Проверяем размер выбранной области
            if ($crop == false) {
                $save_button->enabled = false;
                $this->toast("Выбранная область меньше минимальной");
            } else {
                
                $crop_pane->visible = false;
                $img->image = $crop;
                
                # Сохраняем
                $avatar_path = fs::abs('./').'/123.jpg';
                $img->image->save($avatar_path);
                $avatar = File::of($avatar_path);
                
                # Отображаем кнопки
                $bottom_pane->children->clear();
                $bottom_pane->add($cancel_button);
                
            }
            
        });
        
        $bottom_pane->add($cancel_button);
        
        # Финальный box
        $box = new UXVBox([$top_pane, $inf_pane, $anchor, $bottom_pane]);
        $box->classes->add("image-box");
        $box->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        
        $this->set_settings(true, true, 1, [50, 50]);
        $this->register($anchor, $img, $crop_pane, function ($valid_image) use ($save_button, $cancel_button, $bottom_pane) {
            $bottom_pane->children->clear();
            if ($valid_image) {
                $bottom_pane->add($save_button);
                $save_button->enabled = true;
            }
            $bottom_pane->add($cancel_button);
        }, function ($valid_save) use ($save_button) {
            $save_button->enabled = $valid_save;
        });
        
        # Контент
        $content = new UXVBox([$box]);
        $content->classes->add("crop-content");
        $content->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        $content->on('click', function($e) {
            $e->consume();
        });
        UXVBox::setVgrow($box, 'ALWAYS');
        UXVBox::setVgrow($anchor, 'ALWAYS');
        UXVBox::setVgrow($content, 'ALWAYS');
        
        # Параметры модального окна
        $modal = [
                'fitToWidth' => true,
                'fitToHeight' => true,
                'blur' => $this->split,
                'content' => $content,
                'close_overlay' => true
                ];
        # Отображаем окно      
        $this->modal_dialog($this, $modal, function ($e) use ($img, $anchor, $cancel_button) {
        
            # Модальное окно открылось
            if ($e['open'] == true) {
            
                # Если картинка больше чем контейнер, добавим немного блюра
                if (($img->image->width > $anchor->width) or ($img->image->height > $anchor->height)) {
                    if ($img->effects->count == 0) {
                        $img->effects->add(new UXGaussianBlurEffect(1.5));
                    }
                }
                
                # Закрываем модальное окно при нажатии на кнопку Закрыть
                $cancel_button->on('action', function() use ($e) {
                    $close_modal = ['modal' => $e['modal'], 'content' => $e['content'], 'blur' => $e['blur']];
                    $this->modal_close($close_modal);
                    $this->clear();
                });
                                      
            }
                  
        });
        
    }
    
    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'title' => 'Заголовок сообщения', # Заголовок окна
            'message' => 'Текст Вашего сообщения', # Сообщение
            'close_overlay' => true, # Закрывать при клике мыши на overlay
            'buttons' => [['text' => 'Да', 'style' => 'button-red'], ['text' => 'Отмена', 'style' => 'button-accent', 'close' => true]]
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Да') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        
        # Имя автора сообщения
        $author = new UXLabel('Илья Муромец');
        $author->classes->add("font-bold");
        
        # Создаем сообщение
        $text = new UXLabel('Теперь существует одна модульная функция которая позволяет отображать любой контент с оверлеем (размытием и затемнением заднего плана).  Создается массив с параметрами и вызывается функция открытия модального окна. Если в функцию не передан параметр content, то берутся стандартные title, message, buttons для отображения диалога.');
        $text->wrapText = true;
        $text->classes->addAll(["message"]);
        
        # Кнопка удаления сообщения
        $delete_mess = new UXButton('Удалить сообщение');
        $delete_mess->on('click', function ($e) use ($this) {
                
            # Если кликнули правой кнопкой мышки
            if ($e->button == 'PRIMARY') {
                
                # Параметры модального окна
                $modal = [
                    'fitToWidth' => true, # Во всю длину
                    'fitToHeight' => true, # Во всю ширину
                    'blur' => $this->flowPane, # Объект для размытия
                    'title' => 'Удалить сообщение', # Заголовок окна
                    'message' => 'Вы действительно хотите удалить сообщение?', # Сообщение
                    'close_overlay' => true, # Закрывать при клике мыши на overlay
                    'buttons' => [['text' => 'Удалить', 'style' => 'button-red'], ['text' => 'Нет, отмена', 'style' => 'button-accent', 'close' => true]]
                    ];
                # Отображаем окно      
                app()->module("modal")->modal_dialog($this, $modal);
            }
            
        });
        
        # Дата сообщения
        $textDate = new UXLabel('17.09.2020');
        $textDate->classes->add("font-white-gray");
        $pane_textDate = new UXHBox([$textDate]);
        
        # Поместим объекты в горизонтальный бокс
        $pane1 = new UXHBox();
        $pane1->add($author);
        $pane1->add($pane_textDate);
        $pane1->spacing = 7;
        $pane1->alignment = "TOP_LEFT";
        
        # Собираем слои и проверяем на сообщение и аттач
        $title = new UXVBox();
        $title->add($pane1);
        $title->alignment = "TOP_LEFT";
        
        $title->add($text);
        
        # Собираем финальный бокс
        $box = new UXVBox([$title, $delete_mess]);
        $box->spacing = 5;
        $box->padding = [0, 0, 0, 0];
        $box->classes->add("message-item");
        $box->on('click', function($e) {
            $e->consume();
        })
        
        
        # Параметры модального окна
        $modal = [
                'fitToWidth' => true, # Во всю длину
                'fitToHeight' => true, # Во всю ширину
                'blur' => $this->flowPane, # Объект для размытия
                'content' => $box, # Контент
                'close_overlay' => true # Закрывать при клике мыши на overlay
                ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, null);
        
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        
        # Загружаем изображение
        $img = new UXImageArea();
        $img->centered = true;
        $img->proportional = true;
        $img->stretch = $stretch;
        $img->smartStretch = $stretch;
        $img->image = new UXImage('res://.data/img/preview.jpg');
        
        $img->classes->add('image');
        $img->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        
        # Контейнер для изображения
        $anchor = new UXAnchorPane;
        $anchor->classes->add("anchor");
        $anchor->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        $anchor->add($img);
        
        # Бокс информации и скачивания изображения
        $anchor_box_param = new UXAnchorPane;
        $anchor_box_param->classes->add("anchor");
        $box_param = new UXHBox;
        $box_param->classes->add("box-param");
        
        # Кнопка скачать оригинал
        $label_download = new UXLabel("скачать оригинал");
        $label_download->on('click', function($e) use ($box_param) {
        
            # Начинаем скачивание изображения
            $attach_progress = new UXProgressBar;
            $attach_progress->classes->add("progress-bar");
            $attach_progress->visible = true;
            $box_param->add($attach_progress);
            $e->consume();
            
        })
        
        $box_param->add($label_download);
        $anchor_box_param->add($box_param);
        
        $content = new UXVBox([$anchor, $anchor_box_param]);
        $content->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        UXVBox::setVgrow($anchor, 'ALWAYS');
        UXVBox::setVgrow($content, 'ALWAYS');
        
        # Параметры модального окна
        $modal = [
                'fitToWidth' => true, # Во всю длину
                'fitToHeight' => true, # Во всю ширину
                'blur' => $this->flowPane, # Объект для размытия
                'content' => $content, # Контент
                'close_overlay' => true # Закрывать при клике мыши на overlay
                ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, null);
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        
        #---------------------------------------------------------------------------------
        
        # Создаем левое выезжающее меню пользователя
        $user_profile = new UXVBox;
        $user_profile->classes->add('user-profile');
        $user_profile->anchors = ['left' => 0,'right' => 0];
        
        # Проверяем на аватарку
        $user_avatar = $this->setBorderRadius($this->setImage('res://.data/img/no_avatar.png', 60, 60), 60);
        
        $lm_user_name = new UXLabel("Владимир Букреев");
        $lm_user_name->classes->addAll(['name', 'font-gray']);
        $user_profile->add($user_avatar);
        $user_profile->add($lm_user_name);
        
        # Ссылки меню
        $user_profile_links = new UXVBox;
        $user_profile_links->classes->add('links');
        $user_profile_links->anchors = ['left' => 0,'right' => 0];
        
        $li_create_dialog = new UXLabel("Создать диалог");
        $li_create_dialog->classes->addAll(['link']);
        $li_create_dialog->graphic = $this->setImage('res://.data/img/user.png', 16, 16);
        $li_create_dialog->graphicTextGap = 8;
        $li_create_group_chat = new UXLabel("Создать групповой чат");
        $li_create_group_chat->classes->addAll(['link']);
        $li_create_group_chat->graphic = $this->setImage('res://.data/img/users.png', 16, 16);
        $li_create_group_chat->graphicTextGap = 8;
        $li_create_channel = new UXLabel("Создать сообщество");
        $li_create_channel->classes->addAll(['link']);
        $li_create_channel->graphic = $this->setImage('res://.data/img/application-icon-large.png', 16, 16);
        $li_create_channel->graphicTextGap = 8;
        $li_users = new UXLabel("Пользователи");
        $li_users->classes->addAll(['link']);
        $li_users->graphic = $this->setImage('res://.data/img/magnifier-left.png', 16, 16);
        $li_users->graphicTextGap = 8;
        $li_favorites = new UXLabel("Избранное");
        $li_favorites->classes->addAll(['link']);
        $li_favorites->graphic = $this->setImage('res://.data/img/star.png', 16, 16);
        $li_favorites->graphicTextGap = 8;
        $user_profile_links->add($li_create_dialog);
        $user_profile_links->add($li_create_group_chat);
        $user_profile_links->add($li_create_channel);
        $user_profile_links->add($li_users);
        $user_profile_links->add($li_favorites);
        
        # inf
        $user_profile_inf = new UXVBox;
        $user_profile_inf->classes->add('inf');
        $user_profile_inf->anchors = ['left' => 0,'right' => 0];
        
        $li_user_profile_inf = new UXLabel('ver 6.0');
        $li_user_profile_inf->classes->addAll(['item', 'font-white-gray']);
        $user_profile_inf->add($li_user_profile_inf);
        
        # space
        $left_menu_programm_space = new UXVBox;
        UXVBox::setVgrow($left_menu_programm_space, 'ALWAYS');
        
        # Content
        $left_menu_programm_content = new UXVBox;
        $left_menu_programm_content->anchors = ['left' => 0, 'right' => 0, 'top' => 0, 'bottom' => 0];
        $left_menu_programm_content->classes->add('content');
        UXVBox::setVgrow($left_menu_programm_content, 'ALWAYS');
        
        $left_menu_programm = new UXScrollPane;
        $left_menu_programm->classes->add('left-menu-programm');
        $left_menu_programm->fitToHeight = true;
        $left_menu_programm->fitToWidth = true;
        $left_menu_programm->content = $left_menu_programm_content;
        $left_menu_programm->on('click', function($e) {
            $e->consume();
        });
        
        $left_menu_programm_content->add($user_profile);
        $left_menu_programm_content->add($user_profile_links);
        $left_menu_programm_content->add($user_profile_inf);
        $left_menu_programm_content->add($left_menu_programm_space);
        
        # Параметры модального окна
        $modal = [
            'fitToWidth' => false,
            'fitToHeight' => true,
            'blur' => $this->flowPane,
            'close_overlay' => true,
            'padding' => [0,0,0,0],
            'content' => $left_menu_programm,
            'contentFitToHeight' => true
            ];
        # Отображаем окно      
        $this->modal_dialog($this, $modal);
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'title' => 'Прозрачность', # Заголовок окна
            'close_overlay' => false, # Закрывать при клике мыши на overlay
            'opacity_overlay' => "00",
            'buttons' => [['text' => 'Круто', 'style' => 'button-yellow'], ['text' => 'Закрыть', 'close' => true]]
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Круто') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'title' => 'Отступы', # Заголовок окна
            'message' => 'Текст Вашего сообщения', # Сообщение
            'color_overlay' => "#ff5252",
            'close_overlay' => false, # Закрывать при клике мыши на overlay
            'buttons' => [['text' => 'Да', 'style' => 'button-red'], ['text' => 'Отмена', 'style' => 'button-accent', 'close' => true]]
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Да') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {
    
        $content = new UXVBox;
        $content->backgroundColor = "#fff";
    
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'padding' => [15,15,15,15],
            'contentFitToHeight' => true,
            'content' => $content,
            'close_overlay' => true, # Закрывать при клике мыши на overlay
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Да') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'title' => 'Заголовок сообщения', # Заголовок окна
            'message' => 'Текст Вашего сообщения', # Сообщение
            'close_overlay' => true, # Закрывать при клике мыши на overlay
            'contentFitToHeight' => true,
            'buttons' => [['text' => 'Да', 'style' => 'button-red'], ['text' => 'Отмена', 'style' => 'button-accent', 'close' => true]]
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Да') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция открытия модального окна
    #----------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * @event button9.action 
     */
    function doButton9Action(UXEvent $e = null)
    {
        # Параметры модального окна
        $modal = [
            'fitToWidth' => true, # Во всю длину
            'fitToHeight' => true, # Во всю ширину
            'blur' => $this->flowPane, # Объект для размытия
            'title' => 'Заголовок сообщения', # Заголовок окна
            'message' => 'Текст Вашего сообщения', # Сообщение
            'close_overlay' => true, # Закрывать при клике мыши на overlay
            'contentFitToHeight' => true,
            'padding' => [5,5,5,5],
            'color_overlay' => "#5181b8",
            'opacity_overlay' => "99",
            'buttons' => [['text' => 'Да', 'style' => 'button-red'], ['text' => 'Отмена', 'style' => 'button-accent', 'close' => true]]
            ];
        # Отображаем окно      
        app()->module("modal")->modal_dialog($this, $modal, function($e) use ($this) {
            # Если выбран ответ
            if ($e == 'Да') {
                alert('Вы выбрали '.$e);
            }
        });
    }

    /**
     * @event button10.action 
     */
    function doButton10Action(UXEvent $e = null)
    {    
        $this->show_crop('res://.data/img/preview.jpg');
    }


}
