<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

   #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Передаем подготовленное изображение
    #----------------------------------------------------------------------------------------------------------------------------------------------------
    function setImage($img, $w, $h, $stretch = true)
    {         
        $icon = new UXImageArea();
        $icon->size = [$w, $h];
        $icon->centered = true;
        $icon->proportional = true;
        $icon->stretch = $stretch;
        $icon->smartStretch = $stretch;
        $icon->image = new UXImage($img);
        return $icon;
    }
    
    #----------------------------------------------------------------------------------------------------------------------------------------------------
    # Функция закругления картинки
    #----------------------------------------------------------------------------------------------------------------------------------------------------   
    
    function setBorderRadius($image, $radius) {
    
        #Создаем прямоугольник с размерами как у изображения    
        $rect = new UXRectangle;
        $rect->width = $image->width;
        $rect->height = $image->height;
        
        #Устанавливаем скругление углов
        $rect->arcWidth = $radius*2;
        $rect->arcHeight = $radius*2;

        #Теперь фокус! "Обрезаем" элемент по форме круглого прямоугольника и скриним его
        $image->clip = $rect;
        $circledImage = $image->snapshot();

        #Убираем прямоугольник
        $image->clip = NULL;
        $rect->free();

        #Устанавливаем заскриненное круглое изображение
        $image->image = $circledImage;
        
        return $image;
        
    }

}