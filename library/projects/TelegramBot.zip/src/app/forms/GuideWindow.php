<?php
namespace app\forms;

use std, gui, framework, app;


class GuideWindow extends AbstractForm
{

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }




}
