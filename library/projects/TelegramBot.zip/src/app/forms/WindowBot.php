<?php
namespace app\forms;

use telegram\TelegramBotApi;
use std, gui, framework, app;


class WindowBot extends AbstractForm
{

    function SMS() {
             $this->notice = new UXTrayNotification("Сообщение отправлено!", "Можете проверить его вашем канале/чате!","SUCCESS");
       $this->notice->animationType = "SLIDE";
       $this->notice->show();
    }

    /**
     * @event sendBtn.action 
     */
    function doSendBtnAction(UXEvent $e = null)
    {    
    
      $this->SMS();
    
    $bot_token = $this->tokenid->text; // Токен вашего бота
    
       $api = new TelegramBotApi($bot_token); // Подключаем пакет TelegramBotApi
    
    $ChatID = $this->chatid->text; //  Айди вашего чата, найти его можно через гайд, только запустите проект :)
    $msgText = $this->msgText->text; // Сообщение бота
    
     

$botInfo = $api->getMe()->query(); // Получить данные о боте

$message = $api->sendMessage()->chat_id($ChatID)->text($msgText)->query(); // Отправить текстовое сообщение
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {//https://api.telegram.org/bot<TOKEN>/getChat?chat_id=@<CHANNEL_USERNAME>

 $bot_token = $this->tokenid->text; // Токен вашего бота
 $id_channel = $this->channelID->text; // Токен вашего бота


               $dialog = UXDialog::confirm("Хотите перейти по этому адресу? \n https://api.telegram.org/bot$bot_token/getChat?chat_id=@$CHANNEL_USERNAME");
        if($dialog){
        $TG = "https://api.telegram.org/bot$bot_token/getChat?chat_id=@$id_channel";
        browse($TG);
        }else{
            $e->consume();
            
        }
   } 
   
   function GuideWindow($MSG = "") 
   {
       $GW = new Guide;
       $GW->msg->text = $MSG;
       $GW->show();
   }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
     
    }

}
