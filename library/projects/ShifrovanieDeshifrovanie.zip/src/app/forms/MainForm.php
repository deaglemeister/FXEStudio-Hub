<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    private $cipher; // Переменная для хранения экземпляра XorCipher

    /**
     * Метод инициализации формы
     */
    public function init() {
        $this->cipher = new XorCipher(); // Инициализация экземпляра XorCipher
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        // Ваш ключ
        $key = $this->edit3->text;

        // Ваш текст для шифрования
        $textToEncrypt = $this->edit->text;
        var_dump($textToEncrypt);
        // Шифрование текста
        $encrypted = $this->cipher->encrypt($textToEncrypt, $key);

        // Вывод результата
        $this->edit5->text = $encrypted;
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        // Ваш ключ
        $key = $this->edit4->text;

        // Ваш зашифрованный текст (значение из editAlt)
        $base64encryptedText = $this->editAlt->text;

        // Расшифровка текста
        $decryptedText = $this->cipher->decrypt($base64encryptedText, $key);

        // Вывод результата
        
        
       // $normalText = str::decode($decryptedText, 'windows-1251');
        var_dump($decryptedText);
        $this->edit6->text = $decryptedText;
    }

}

class XorCipher {

    public function encrypt($text, $key) {
        $result = '';
        $keyLength = strlen($key);

        for ($i = 0; $i < strlen($text); $i++) {
            $result .= $text[$i] ^ $key[$i % $keyLength];
        }
        var_dump($result);
        $result = base64_encode($result);
        return $result;
    }

    public function decrypt($text, $key) {
        $result = '';
        $keyLength = strlen($key);
        $text = base64_decode($text);

        for ($i = 0; $i < strlen($text); $i++) {
            $result .= $text[$i] ^ $key[$i % $keyLength];
        }

        return $result;
    }
}