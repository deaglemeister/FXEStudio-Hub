<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

}