<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->panelAlt->classesString = "bars bars-accent";
        $this->panel3->classesString = "bars bars-warning";
        
        $this->panel->classesString = "bars bg-white";
        $this->panelAlt->classesString = "bars bars-accent bg-gray";
        $this->panel3->classesString = "bars bars-warning bg-dark";
    }

}
