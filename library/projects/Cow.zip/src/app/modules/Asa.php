<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class Asa extends AbstractModule
{

}