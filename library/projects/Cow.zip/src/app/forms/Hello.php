<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class Hello extends AbstractForm
{

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->ini->set("name", $this->name->text);
        
        // 1 - Мужыг 2- Девченка    maleFamale - Ключ
        if ($this->combobox->selected == "Мужыг"){
            $this->ini->set("maleFamale", 1);
        }else{
             $this->ini->set("maleFamale", 2);
        }
        
        if ($this->combobox->selectedIndex == "-1"){
            $this->toast("Пол нужен обязательно");
        }else{
            $this->loadForm('MainForm');
        }
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->toast("Имя нужно, чтобы просто одобразить \n  твой никнейм в игре, кроме \n  тебя его никто не увидит, а пол, чтобы \n обращяться к тебе в мужском или женском роде");
    }

}
