<?php
namespace app\forms;

use app\forms\MainForm;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXEvent; 


class GameOver extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
    
   
    
    
    
    
      $this->label->text = 'Вы дошли до: '.$this->form(MainForm)->label3->text.'';
    
    if ($this->ini->get("Value") == "0"){
         $this->label4->text = "Ровным счетом ничего";
    }else{
         $this->label4->text = $this->ini->get("Value");
    }
      if ($this->ini->get("Value") < $this->form(MainForm)->label3->text){
           $this->ini->set("Value", $this->form(MainForm)->label3->text);
           $this->labelAlt->text = "ВЫ УСТАНОВИЛИ НОВЫЙ РЕКОРД";
      }else{
          $this->toast('Вы не установили нового рекорда, в прошлый раз вы поймали корову '.$this->ini->get("Value").' раз');
      }
      
      if ($this->ini->get("maleFamale") == 1){
          $this->label3->text = "А в прошлый раз ты смог сделать";
      }else{
           $this->label3->text = "А в прошлый раз ты смогла сделать";
      }
       
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->toast("Впадлу было обновлять форму, нуужно убрать клоны с MainForm И запустить Timer Заного, а остальноые удалить и будет все заного \n Сейчас просто перезапусти игру");
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->ini->set("Value", 0);
        $this->form(MainForm)->toast("Вы сбросили рекорд");
        $this->loadForm('MainForm');
    }

}
