<?php
namespace game\modules;

use std, gui, framework, game;


class AppModule extends AbstractModule
{

    /**
     * @event action 
     */
    function doAction(ScriptEvent $e = null)
    {    
        UXFont::load(Stream::of("res://.data/pixel.ttf"));
        $GLOBALS['sound'] = 1;
    }

}
