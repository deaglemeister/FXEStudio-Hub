<?php
namespace game\modules;

use std, gui, framework, game;


class MainModule extends AbstractModule
{

}