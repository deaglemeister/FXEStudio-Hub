<?php
namespace game\forms;

use std, gui, framework, game;


class menu extends AbstractForm
{


    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        Score::set('health',3);
        Score::set('score',0);
        $GLOBALS['level'] = 1;
        app()->form('MainForm')->game->phys->scene = null;
        if ($GLOBALS['died']){$this->hint->visible = 1;$this->hint->text = "Вы умерли :(";waitAsync('3s',function (){$GLOBALS['died'] = 0;});}
        if ($GLOBALS['end']){$this->hint->visible = 1;$this->hint->text = "Уровни кончились :)";waitAsync('3s',function (){$GLOBALS['end'] = 0;});}
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        $this->loadForm('MainForm');
        $this->free();
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        $this->men->visible = $this->settings->visible;
        $this->settings->visible = !$this->men->visible;
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {    
        $GLOBALS['sound'] = !$GLOBALS['sound'];
        if ($GLOBALS['sound']){
            $e->sender->text = "ЗВУКИ:ВКЛ";
        }else{
            $e->sender->text = "ЗВУКИ:ВЫКЛ";
        }
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $this->men->visible = $this->settings->visible;
        $this->settings->visible = !$this->men->visible;
    }

    /**
     * @event slider.mouseDrag 
     */
    function doSliderMouseDrag(UXMouseEvent $e = null)
    {    
        app()->module('MainModule')->player->volume = $e->sender->value / 100;
    }

    /**
     * @event slider.construct 
     */
    function doSliderConstruct(UXEvent $e = null)
    {    
        $e->sender->value = app()->module('MainModule')->player->volume * 100;
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        app()->shutdown();
    }







}
