<?php
namespace game\forms;

use std, gui, framework, game;


class level2 extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $GLOBALS['start'] = [256,736];
        Score::set('rings',0);
        $GLOBALS['level'] = 2;
        $GLOBALS['level_rings'] = 7;
        $GLOBALS['check'] = [];
        app()->form('MainForm')->hidePreloader();
    }


}
