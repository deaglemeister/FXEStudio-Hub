<?php
namespace game\forms;

use std, gui, framework, game;


class level1 extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $GLOBALS['start'] = [80,48];
        Score::set('rings',0);
        $GLOBALS['level'] = 1;
        $GLOBALS['level_rings'] = 6;
        $GLOBALS['check'] = [];
        app()->form('MainForm')->hidePreloader();
    }



}
