<?php
namespace game\forms;

use std, gui, framework, game;


class MainForm extends AbstractForm
{


    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        app()->form('MainForm')->showPreloader("Загрузка...");
        $GLOBALS['dif'] = 1;
        Score::set('health',3);
        Score::set('score',0);
        $GLOBALS['level'] = 1;
        $GLOBALS['levels'] = 3;
        $GLOBALS['speed'] = 12;
        $GLOBALS['speed_up'] = 0;
        app()->form('MainForm')->game->phys->loadScene("level".$GLOBALS['level']);
    }


    /**
     * @event label3.step 
     */
    function doLabel3Step(UXEvent $e = null)
    {
        $e->sender->text = "LEVEL ".$GLOBALS['level'];
    }


    /**
     * @event label3.mouseUp-Middle 
     */
    function doLabel3MouseUpMiddle(UXMouseEvent $e = null)
    {    
        $GLOBALS['level']++;
            if ($GLOBALS['level'] > $GLOBALS['levels']){
                app()->form('MainForm')->loadForm('menu');$this->free();
            }else{
                app()->form('MainForm')->game->phys->loadScene("level".$GLOBALS['level']);
            }
    }

    /**
     * @event label.step 
     */
    function doLabelStep(UXEvent $e = null)
    {
        $e->sender->text = "X".Score::get('health');
    }

    /**
     * @event label4.step 
     */
    function doLabel4Step(UXEvent $e = null)
    {
        $e->sender->text = Score::get('rings')."/".$GLOBALS['level_rings'];
    }

    /**
     * @event labelAlt.step 
     */
    function doLabelAltStep(UXEvent $e = null)
    {
        $e->sender->text = Score::get('score');
    }

    /**
     * @event keyDown-Esc 
     */
    function doKeyDownEsc(UXKeyEvent $e = null)
    {    
        app()->form('MainForm')->loadForm('menu');$this->free();
    }







}
