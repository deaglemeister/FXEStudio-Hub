<?php
namespace game\forms;

use std, gui, framework, game;


class settings extends AbstractForm
{


    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->loadForm('menu');$this->free();
    }



}
