<?php
namespace game\forms;

use php\gui\framework\event\KeydownEventAdapter;
use game\SpriteManager;
use game\Jumping;
use std, gui, framework, game;


class proto extends AbstractForm
{
    /**
     * @event player.collision-floor 
     */
    function doPlayerCollisionfloor(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;}
    }

    /**
     * @event player.collision-floor8 
     */
    function doPlayerCollisionfloor8(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;}
    }

    /**
     * @event player.collision-floor16 
     */
    function doPlayerCollisionfloor16(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;}
    }

    /**
     * @event player.collision-floor32 
     */
    function doPlayerCollisionfloor32(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;} 
    }

    /**
     * @event player.collision-step_right 
     */
    function doPlayerCollisionstep_right(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;}
    }
    /**
     * @event player.collision-step_left 
     */
    function doPlayerCollisionstep_left(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$GLOBALS['jump'] = 0;}
    }


    /**
     * @event player.globalKeyPress-A 
     */
    function doPlayerGlobalKeyPressA(UXKeyEvent $event = null)
    {    
        $event->sender->phys->hspeed = $GLOBALS['speed']*-1;
    }
    /**
     * @event player.globalKeyPress-D 
     */
    function doPlayerGlobalKeyPressD(UXKeyEvent $event = null)
    {    
        $event->sender->phys->hspeed = $GLOBALS['speed'];
    }
    /**
     * @event player.globalKeyUp-A 
     */
    function doPlayerGlobalKeyUpA(UXKeyEvent $event = null)
    {    
        $event->sender->phys->hspeed = 0;
    }
    /**
     * @event player.globalKeyUp-D 
     */
    function doPlayerGlobalKeyUpD(UXKeyEvent $event = null)
    {    
        $event->sender->phys->hspeed = 0;
    }

    /**
     * @event player.globalKeyPress-Space 
     */
    function doPlayerGlobalKeyPressSpace(UXKeyEvent $event = null)
    {    
        if (!$GLOBALS['jump']){
            $GLOBALS['jump'] = 1;
            $event->sender->phys->vspeed = -20;
        }
    }

    /**
     * @event player.collision-ship 
     */
    function doPlayerCollisionship(UXCollisionEvent $event = null)
    {    
        if ($GLOBALS['sound']){$this->player->open("res://.data/sound/die.wav");}
        $old = $event->target->position;
        $event->target->position = [-100,-100];
        if ($GLOBALS['check']){
            Logger::info("Checkpoint: ".implode(',',$GLOBALS['check']));
            Jumping::to($event->sender, $GLOBALS['check'][0], $GLOBALS['check'][1]);
        }else{
            Logger::info("Start: ".implode(',',$GLOBALS['start']));
            Jumping::to($event->sender, $GLOBALS['start'][0],$GLOBALS['start'][1]);
        }
        Score::inc('health', -1);
        $event->target->position = $old;
        if (Score::get('health') <= 0){              
            $GLOBALS['died'] = 1;     
            app()->form('MainForm')->loadForm('menu');
            app()->form('MainForm')->free();
        }
        
    }

    /**
     * @event player.collision-check 
     */
    function doPlayerCollisioncheck(UXCollisionEvent $event = null)
    {    
       if ($GLOBALS['sound']){$this->player->open("res://.data/sound/pick.wav");}
       $ch =$event->target->position;$event->target->position = [-100,-100];uiLater(function () use($event,$ch){$GLOBALS['check'] = $ch;Score::inc('score',500);Logger::info("Collected checkpoint: ".implode(',',$GLOBALS['check']));});       
        
    }

    /**
     * @event player.collision-ring 
     */
    function doPlayerCollisionring(UXCollisionEvent $event = null)
    {    
       if ($GLOBALS['sound']){$this->player->open("res://.data/sound/ring.wav");}
        $event->target->position = [-100,-100];uiLater(function () use($event){Score::inc('score',500);Score::inc('rings',1);});
    }

    /**
     * @event player.collision-ring2
     */
    function doPlayerCollisionring2(UXCollisionEvent $event = null)
    {    
       if ($GLOBALS['sound']){$this->player->open("res://.data/sound/ring.wav");}
        $event->target->position = [-100,-100];uiLater(function () use($event){Score::inc('score',500);Score::inc('rings',1);});
    }

    /**
     * @event player.collision-health 
     */
    function doPlayerCollisionhealth(UXCollisionEvent $event = null)
    {    
    
       if ($GLOBALS['sound']){$this->player->open("res://.data/sound/pick.wav");}
        $event->target->position = [-100,-100];uiLater(function () use($event){Score::inc('health',1);Score::inc('score',1000);});
        
    }

    /**
     * @event enemy.collision-wall 
     */
    function doEnemyCollisionwall(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }
    
    /**
     * @event enemy.collision-wall8_90 
     */
    function doEnemyCollisionwall8_90(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *=  -1;
    }
    
    /**
     * @event enemy.collision-wall16_90 
     */
    function doEnemyCollisionwall16_90(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }
    
    /**
     * @event enemy.collision-wall32_90 
     */
    function doEnemyCollisionwall32_90(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
        
    }

    /**
     * @event enemy.collision-floor 
     */
    function doEnemyCollisionfloor(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }
    /**
     * @event enemy.collision-floor8
     */
    function doEnemyCollisionfloor8(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }
    /**
     * @event enemy.collision-floor16
     */
    function doEnemyCollisionfloor16(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }
    /**
     * @event enemy.collision-floor32
     */
    function doEnemyCollisionfloor32(UXCollisionEvent $event = null)
    {    
        $event->sender->phys->gravityY *= -1;
    }

    /**
     * @event player.collision-enemy 
     */
    function doPlayerCollisionenemy(UXCollisionEvent $event = null)
    {    
        $this->doPlayerCollisionship($event);
    }

    /**
     * @event player.collision-next 
     */
    function doPlayerCollisionnext(UXCollisionEvent $event = null)
    {    
        if (Score::get('rings') >= $GLOBALS['level_rings']){
            $GLOBALS['level']++;
            if ($GLOBALS['level'] > $GLOBALS['levels']){
                $event->sender->free();$GLOBALS['end'] = 1;app()->form('MainForm')->loadForm('menu');app()->form('MainForm')->free();
            }else{
                app()->form('MainForm')->game->phys->loadScene("level".$GLOBALS['level']);
            }
        }else{
            Collision::bounce($event->sender, $event->normal, 2);
        }
    }

    /**
     * @event player.collision-water 
     */
    function doPlayerCollisionwater(UXCollisionEvent $event = null)
    {    
        if ($GLOBALS['big']){
            $event->sender->phys->vspeed = -5;
           # Collision::bounce($event->sender, $event->normal, 0.75);
        }
       # $GLOBALS['jump'] = 0; 
        #Collision::bounce($event->sender, $event->normal, 0.6);
    }

    /**
     * @event player.collision-small 
     */
    function doPlayerCollisionsmall(UXCollisionEvent $e = null)
    {    
        if ($GLOBALS['big']){
            $GLOBALS['big'] = 0;
            $e->sender->size = [32,32];
            $e->sender->sprite = SpriteManager::current()->fetch("player");
            $e->sender->y += 32;
        }
    }

    /**
     * @event player.collision-big 
     */
    function doPlayerCollisionbig(UXCollisionEvent $e = null)
    {
        if (!$GLOBALS['big']){
            $GLOBALS['big'] = 1;
            $e->sender->size = [48,48];
            $e->sender->sprite = SpriteManager::current()->fetch("bigball");
            $e->sender->y += -32;
        }
    }

    /**
     * @event player.collision-small_ring 
     */
    function doPlayerCollisionsmall_ring(UXCollisionEvent $event = null)
    {    
        if (!$GLOBALS['big']){if ($GLOBALS['sound']){$this->player->open("res://.data/sound/ring.wav");}$event->target->position = [-100,-100];uiLater(function () use($event){Score::inc('score',500);Score::inc('rings',1);});}
    }

    /**
     * @event player.collision-small_ring_90 
     */
    function doPlayerCollisionsmall_ring_90(UXCollisionEvent $event = null)
    {    
        if (!$GLOBALS['big']){if ($GLOBALS['sound']){$this->player->open("res://.data/sound/ring.wav");}$event->target->position = [-100,-100];uiLater(function () use($event){Score::inc('score',500);Score::inc('rings',1);});}
    }

    /**
     * @event enemy.construct 
     */
    function doEnemyConstruct(UXEvent $event = null)
    {    
        $event->sender->phys->gravity = [0.0, floatval(6*$GLOBALS['dif'])];
    }

    /**
     * @event player.collision-bat 
     */
    function doPlayerCollisionbat(UXCollisionEvent $event = null)
    {    
        #$GLOBALS['jump'] = 0;
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){$event->sender->phys->vspeed = -25;}
    }

    /**
     * @event player.construct 
     */
    function doPlayerConstruct(UXEvent $event = null)
    {    
        $event->sender->phys->gravity = [0.0, 28.0];
    }

    /**
     * @event player.collision-speed 
     */
    function doPlayerCollisionspeed(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){
            if (!$GLOBALS['speed_up']){
                $GLOBALS['speed_up'] = 1;
                $GLOBALS['speed'] += 10;
                waitAsync('5s',function (){
                    if ($GLOBALS['speed_up']){
                        $GLOBALS['speed'] -= 10;
                        $GLOBALS['speed_up'] = 0;
                    }
                });
            }
        }
    }

    /**
     * @event player.collision-test 
     */
    function doPlayerCollisiontest(UXCollisionEvent $event = null)
    {    
        if ($event->sender->y <= ($event->target->y+($event->target->height/2))){
            $GLOBALS['inside']= 1;    
        }else{
            $GLOBALS['inside']= 0;
        }
    }

    /**
     * @event player.collision-TEST2 
     */
    function doPlayerCollisionTEST2(UXCollisionEvent $event = null)
    {    
        $GLOBALS['inside']= 0;
    }

    /**
     * @event menu_player.construct 
     */
    function doMenu_playerConstruct(UXEvent $event = null)
    {    
        $event->sender->phys->gravity = [0.0, 28.0];
        $event->sender->phys->hspeed = rand(-20,20);
    }


    /**
     * @event menu_player.collision-menu_player 
     */
    function doMenu_playerCollisionmenu_player(UXCollisionEvent $event = null)
    {    
        
    }

    /**
     * @event menu_player.click-Left 
     */
    function doMenu_playerClickLeft(UXMouseEvent $event = null)
    {    
        $event->sender->phys->vspeed=0;
        $event->sender->phys->hspeed=0;
    }

    /**
     * @event menu_player.collision-wall16 
     */
    function doMenu_playerCollisionwall16(UXCollisionEvent $event = null)
    {    
        
    }

    /**
     * @event menu_player.collision-floor16 
     */
    function doMenu_playerCollisionfloor16(UXCollisionEvent $event = null)
    {    
        
    }






















































}
