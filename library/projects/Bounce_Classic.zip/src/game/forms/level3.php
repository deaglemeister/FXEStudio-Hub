<?php
namespace game\forms;

use game\SpriteManager;
use std, gui, framework, game;


class level3 extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $GLOBALS['start'] = [1664,64];
        Score::set('rings',0);
        $GLOBALS['level'] = 3;
        $GLOBALS['big'] = 1;
        $this->player->size = [48,48];
        $this->player->sprite = SpriteManager::current()->fetch("bigball");
        $this->player->y += -32;
        $GLOBALS['level_rings'] = 9;
        $GLOBALS['check'] = [];
        app()->form('MainForm')->hidePreloader();
    }


}
