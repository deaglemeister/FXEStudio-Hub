<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event timer.action 
     */
    function doTimerAction(ScriptEvent $e = null)
    {    
        
       
        if($this->FXEAnimationGradientFlow->isStart()){ //или Status
            $this->label->text = 'Запущен? - Да';
            $this->buttonAlt->enabled = true;
        }else{
            $this->label->text = 'Запущен? - Нет';
            $this->buttonAlt->enabled = false;
           
          
            
       
    }

}
}
