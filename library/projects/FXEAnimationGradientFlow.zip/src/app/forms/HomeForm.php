<?php
namespace app\forms;
use php\framework\FXEAnimationGradientFlow;

use Exception;
use std, gui, framework, app;

class HomeForm extends AbstractForm
{
public $FXEAnimationMoonlight;
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        
        $this->FXEAnimationGradientFlow = new FXEAnimationGradientFlow();
        
        // создаем объект класса.
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        if ($this->radioGroup->selectedIndex == 0){
            
            $Mode = 'Fast';
        }elseif($this->radioGroup->selectedIndex == 1) {
            $Mode = 'Medium';
        }elseif($this->radioGroup->selectedIndex == 2) {
            $Mode = 'Slow';
        }
        
        $Color = $this->colorPicker->value->getWebValue();
        $this->FXEAnimationGradientFlow->startAnimation('panel','HomeForm' ,$Mode, $Color,'backgroundColor',function()use(){
            
            
            $this->button->enabled = true;
            $this->buttonAlt->enabled = false;
                      
            var_dump('Анимация закончена!');
        
        });
        
        $e->sender->enabled = false;
        
    }

    /**
     * @event radioGroup.action 
     */
    function doRadioGroupAction(UXEvent $e = null)
    {    
        if ($this->radioGroup->selectedIndex == 0){
            $this->FXEAnimationGradientFlow->Mode = 'Fast';
            
        }elseif($this->radioGroup->selectedIndex == 1) {
            $this->FXEAnimationGradientFlow->Mode = 'Medium';
            
        }elseif($this->radioGroup->selectedIndex == 2) {
            $this->FXEAnimationGradientFlow->Mode = 'Slow';
            
        }
        

    }



    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->FXEAnimationGradientFlow->stopAnimation();
        $this->button->enabled = true;
    }


}
