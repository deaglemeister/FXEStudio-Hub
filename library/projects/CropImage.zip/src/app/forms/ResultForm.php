<?php
namespace app\forms;

use php\io\IOException;
use std, gui, framework, app;


class ResultForm extends AbstractForm
{
    /**
     * @var UXFileChooser
     */
    protected $fileChooser;
    
    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null){
        if(!$this->fileChooser){
            $this->fileChooser = new UXFileChooser;
        }
        $file = $this->fileChooser->showSaveDialog($this);
        $this->showPreloader('Идёт сохранение...');
        $im = $this->image->image;
        new Thread(function()use($im,$file){
            try{
                $im->save($file);
                $mess = "Изображени сохранено в {$file}";
            }
            catch(IOException $e){
                $mess = "Ошибка при сохранении {$file}";
            }
            uiLater(function()use($mess){
                $this->hidePreloader();
                $this->toast($mess);
            });
        })->start();
    }
}