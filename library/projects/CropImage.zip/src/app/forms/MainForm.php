<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{
    protected $startX;
    protected $startY;

    /**
     * @var UXPane
     */
    protected $pane;
    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null){
    
        // Создаём панель выделения
        $this->pane = new UXPane;
        $this->pane->visible = false;
        $this->pane->classes->add("crop_pane");
        $this->pane->backgroundColor = UXColor::rgb(0, 0, 0, 0.5);
        $this->image_box->add($this->pane);
    }

    /**
     * @event image.mouseDrag 
     */
    function doImageMouseDrag(UXMouseEvent $e = null){
        
        if($e->button != 'PRIMARY'){
            return;
        }
        
        // Вычисляем ширину и высоту панели
        $w = $e->position[0] - $this->startX;
        $h = $e->position[1] - $this->startY;
        
        // Если ширина меньше 0, нужны доп. расчёты
        if($w < 0){
            $this->pane->position[0] = $e->position[0];
            $w = $this->startX - $e->position[0];
        }
        
        // То же с высотой
        if($h < 0){
            $this->pane->position[1] = $e->position[1];
            $h = $this->startY - $e->position[1];
        }
        $this->pane->size = [$w, $h];
    
    }

    /**
     * @event image.mouseDown 
     */
    function doImageMouseDown(UXMouseEvent $e = null){    
        
        if($e->button != 'PRIMARY'){
            return;
        }
        $this->pane->position = [$e->position[0], $e->position[1]];
        
        // Запоминаем начальную позицию выделения
        $this->startX = $e->position[0];
        $this->startY = $e->position[1];
        $this->pane->size = [0, 0];
        $this->pane->visible = true;
    }

    /**
     * @event image.mouseUp 
     */
    function doImageMouseUp(UXMouseEvent $e = null){    
        
        if($e->button != 'PRIMARY'){
            return;
        }
        $this->pane->visible = false;
        
        // Получаем координаты выделенной области
        list($x, $y, $w, $h) = [$this->pane->position[0], $this->pane->position[1], $this->pane->width, $this->pane->height];
        if ($w == 0 || $h == 0) {
            return;
        }
        $im = $this->image->image;    
        
        
        
        
        #------------------------------------------------------------------------
        
        # Получение размера оригинального изображения
        $width =  $this->image->image->width;
        $height = $this->image->image->height;
        $ratio = $width / $height;
        
        # Размер объекта изображения
        $obj_width = $this->image->width;
        $obj_height = round($obj_width/$ratio);
        $this->image->height = $obj_height;
        
        var_dump($width.'x'.$height);
        var_dump($obj_width.'x'.$obj_height);
        
        $xFactor = $width / $obj_width;
        $yFactor = $height / $obj_height;
        
        $x = round($x*$xFactor);
        $y = round($y*$yFactor);
        
        $w = round($w*$xFactor);
        $h = round($h*$yFactor);
        
        #------------------------------------------------------------------------
        
        
        
        
        // Обрезаем изображение
        $im = $this->crop($this->image->image, $x, $y, $w, $h);
        
        $form = new ResultForm;
        $form->image->image = $im;
        $form->show();
    
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {       
        $box = new UXPanel;
        $box->id = "image_box";
        $box->anchors = ['left' => 10, 'top' => 10, 'right' => 10, 'bottom' => 10];
        $this->image->anchors = ['left' => 0, 'top' => 0, 'right' => 0, 'bottom' => 0];
        $box->add($this->image);
        $this->vbox->add($box);
        $this->vbox->anchors = ['left' => 10, 'top' => 10, 'right' => 10, 'bottom' => 10];
    }


    /**
     * @return UXImage
     */
    function crop(UXImage $img, $x, $y, $w, $h){
        
        $canvas = new UXCanvas;
        $canvas->size = [$w, $h];
        $gc = $canvas->gc();
        $gc->drawImage($img, $x, $y, $w, $h, 0, 0, $w, $h);
        return $canvas->snapshot();
    
    }
}
